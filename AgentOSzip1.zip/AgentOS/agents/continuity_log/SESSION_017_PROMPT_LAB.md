# Session 017: Prompt Lab (Version-Controlled Prompt Engineering)
**Project:** AgentOS | **Component:** `prompt/lab` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Core Features

| Feature | Description |
|---------|-------------|
| **Prompt Files** | `.prompt` files with frontmatter (model, temp, tools, vars) |
| **Variables** | `{{project_name}}`, `{{file:src/main.rs}}`, `{{date}}`, `{{user_skill}}` |
| **Versioning** | Git history per prompt — `git log prompts/coding/review.prompt` |
| **Testing** | `agentos prompt test review.prompt --inputs fixtures/` — runs against test cases |
| **A/B Testing** | `agentos prompt ab test review.v1.prompt review.v2.prompt --runs 10` |
| **Registry** | `agentos prompt install @agentos/code-review` — community prompts |

---

## 2. Prompt File Format (`.prompt`)

```yaml
---
name: "Code Review"
version: "2.1.0"
model: "claude-3-5-sonnet"
temperature: 0.2
tools: ["github__read_file", "github__create_review"]
variables:
  - name: "pr_number"
    type: "number"
    required: true
  - name: "focus"
    type: "select"
    options: ["security", "performance", "style", "all"]
    default: "all"
---

You are a senior engineer reviewing PR #{{pr_number}}.

Focus: {{focus}}

Repository context:
{{#github__read_file path="README.md"}}
{{/github__read_file}}

Changes:
{{#github__get_pr_diff number=pr_number}}
{{/github__get_pr_diff}}

Provide review in this format:
## Summary
## Issues (by severity)
## Suggestions
## Approval: [APPROVE | REQUEST_CHANGES | COMMENT]
```

---

## 3. Prompt Engine (Rust)

```rust
// src/prompt/engine.rs
use serde::{Serialize, Deserialize};
use specta::Type;
use std::collections::HashMap;
use tera::Tera;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct PromptTemplate {
    pub name: String,
    pub version: String,
    pub model: Option<String>,
    pub temperature: Option<f32>,
    pub tools: Vec<String>,
    pub variables: Vec<PromptVariable>,
    pub content: String,  // Tera template
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct PromptVariable {
    pub name: String,
    pub type_: VariableType,  // string | number | boolean | select | file | secret
    pub required: bool,
    pub default: Option<Value>,
    pub options: Vec<String>,  // for select
    pub description: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum VariableType { String, Number, Boolean, Select, File, Secret }

pub struct PromptEngine {
    tera: Tera,
    variable_resolvers: HashMap<String, Box<dyn VariableResolver>>,
}

impl PromptEngine {
    pub fn new() -> Result<Self> {
        let mut tera = Tera::default();
        tera.autoescape_on(vec![]);
        // Register custom filters: github__read_file, github__get_pr_diff, file:, date:, etc.
        Ok(Self { tera, variable_resolvers: HashMap::new() })
    }
    
    pub async fn render(&self, template: &PromptTemplate, inputs: HashMap<String, Value>) -> Result<AssembledPrompt> {
        // 1. Validate inputs against template variables
        // 2. Resolve special variables (file:, github__, date:, etc.)
        // 3. Render Tera template
        // 4. Return AssembledPrompt (Session 003)
    }
    
    pub fn register_resolver(&mut self, name: String, resolver: Box<dyn VariableResolver>) {
        self.variable_resolvers.insert(name, resolver);
    }
}

#[async_trait]
pub trait VariableResolver: Send + Sync {
    async fn resolve(&self, name: &str, args: &Value, context: &PromptContext) -> Result<Value>;
}

// Built-in resolvers:
// - file:path → reads file content
// - github__read_file:path → calls GitHub MCP
// - github__get_pr_diff:number → calls GitHub MCP
// - date:format → current date
// - env:name → environment variable (whitelisted)
// - secret:name → OS Keychain lookup
```

---

## 4. Versioning & Git Integration

```rust
// src/prompt/versioning.rs
pub struct PromptVersioning {
    git: GitRepo,
    prompts_dir: PathBuf,
}

impl PromptVersioning {
    pub fn history(&self, prompt_name: &str) -> Result<Vec<PromptVersion>> {
        // git log --oneline prompts/{name}.prompt
    }
    
    pub fn diff(&self, prompt_name: &str, from: &str, to: &str) -> Result<String> {
        // git diff from:prompts/{name}.prompt to:prompts/{name}.prompt
    }
    
    pub fn checkout(&self, prompt_name: &str, version: &str) -> Result<PromptTemplate> {
        // git show {version}:prompts/{name}.prompt
    }
    
    pub fn create_version(&self, prompt: &PromptTemplate, message: &str) -> Result<String> {
        // Write file, git add, git commit, return commit hash
    }
}
```

---

## 5. Testing Framework

```rust
// src/prompt/testing.rs
#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct PromptTestCase {
    pub name: String,
    pub inputs: HashMap<String, Value>,
    pub expected: TestExpectation,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum TestExpectation {
    Contains { text: String },
    MatchesRegex { pattern: String },
    JsonSchema { schema: Value },
    Custom { script: String },  // JS eval in sandbox
    SemanticSimilarity { target: String, threshold: f32 },
}

pub struct PromptTester {
    engine: PromptEngine,
    runner: TestRunner,
}

impl PromptTester {
    pub async fn run_test(&self, template: &PromptTemplate, case: &PromptTestCase) -> TestResult {
        let prompt = self.engine.render(template, case.inputs.clone()).await?;
        let response = self.runner.execute(&prompt).await?;
        TestResult {
            passed: self.evaluate(&response, &case.expected),
            response,
            expected: case.expected,
        }
    }
    
    pub async fn run_suite(&self, template: &PromptTemplate, cases: &[PromptTestCase]) -> TestSuiteResult {
        let mut results = Vec::new();
        for case in cases {
            results.push(self.run_test(template, case).await?);
        }
        TestSuiteResult { results, passed: results.iter().filter(|r| r.passed).count() }
    }
}
```

---

## 5. A/B Testing

```rust
// src/prompt/ab_test.rs
pub struct ABTester {
    engine: PromptEngine,
    runner: TestRunner,
}

impl ABTester {
    pub async fn test(
        &self, 
        template_a: &PromptTemplate, 
        template_b: &PromptTemplate, 
        cases: &[PromptTestCase],
        runs_per_case: u32
    ) -> ABTestResult {
        let mut results_a = Vec::new();
        let mut results_b = Vec::new();
        
        for _ in 0..runs_per_case {
            for case in cases {
                let prompt_a = self.engine.render(template_a, case.inputs.clone()).await?;
                let prompt_b = self.engine.render(template_b, case.inputs.clone()).await?;
                
                let (resp_a, resp_b) = tokio::join!(
                    self.runner.execute(&prompt_a),
                    self.runner.execute(&prompt_b)
                );
                
                results_a.push((case.name.clone(), resp_a?));
                results_b.push((case.name.clone(), resp_b?));
            }
        }
        
        // Statistical analysis (t-test, confidence intervals)
        ABTestResult { results_a, results_b, significance: self.calculate_significance(&results_a, &results_b) }
    }
}
```

---

## 6. Registry & CLI

```bash
# Browse
agentos prompt search "code review"

# Install
agentos prompt install code-reviewer@v2.1.0

# Test
agentos prompt test review.prompt --inputs fixtures/

# A/B Test
agentos prompt ab test review.v1.prompt review.v2.prompt --runs 10

# Publish
agentos prompt publish ./my-prompt --registry official
```

### Registry Structure

```
prompts/
├── official/
│   ├── code-reviewer@2.1.0/
│   │   ├── manifest.json
│   │   ├── review.prompt
│   │   └── test_cases/
│   └── ...
├── community/
└── local/
```

---

## 7. Frontend (Svelte 5)

```svelte
<!-- PromptLab.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let templates = $state<PromptTemplate[]>([]);
  let current = $state<PromptTemplate | null>(null);
  let testResults = $state<TestResult[]>([]);
  let mode = $state<'edit' | 'test' | 'ab' | 'history'>('edit');
  
  async function loadTemplates() {
    templates = await invoke('list_prompt_templates', {});
  }
  
  async function testCurrent() {
    if (!current) return;
    testResults = await invoke('test_prompt', { template: current, cases: fixtures });
  }
  
  async function abTest() {
    const [a, b] = selectedTemplates;
    testResults = await invoke('ab_test_prompts', { a, b, cases: fixtures, runs: 10 });
  }
</script>

<div class="prompt-lab">
  <div class="sidebar">
    <PromptTemplateList templates={templates} onSelect={t => current = t} />
  </div>
  
  <div class="editor-pane">
    {#if mode === 'edit'}
      <PromptEditor template={current} onSave={saveTemplate} />
    {:else if mode === 'test'}
      <PromptTestRunner template={current} results={testResults} onRun={testCurrent} />
    {:else if mode === 'ab'}
      <ABTestRunner results={testResults} onRun={abTest} />
    {:else if mode === 'history'}
      <PromptHistory template={current} />
    {/if}
  </div>
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/prompt/`.