# Session 002: Database Schema Design (SQLite)
**Project:** AgentOS | **Component:** `db/schema`
**Date:** 2026-08-20
**Status:** ✅ Completed — Canonical Schema v1.0, Ready for `sqlx`/`rusqlite`/TypeScript generation

---

## 1. Design Principles

1. **Single File, Portable:** One `workspace.db` per "Workspace" (folder). Backups = copy file.
2. **ULIDs > UUIDs:** `01ARZ3NDEKTSV4RRFFQ69G5FAV` — sortable, case-insensitive, no hyphens, 26 chars. Perfect for "Created At" sorting without extra index.
3. **JSON1 Extension Heavy:** SQLite's `jsonb` functions are fast. Store flexible metadata (model params, tool calls, provider specifics) as `JSONB` blobs.
4. **Vec0 / LanceDB Separation:** Vectors live outside SQLite (LanceDB files alongside `.db`). Schema stores only `embedding_id` + `model_dim` pointers.
5. **Referral/Affiliate First-Class:** Dedicated tables for provider configs and routing rules.

---

## 2. Complete DDL (Canonical)

```sql
-- PRAGMAS
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;
PRAGMA temp_store = MEMORY;
PRAGMA mmap_size = 268435456;
PRAGMA page_size = 4096;
PRAGMA busy_timeout = 5000;

-- WORKSPACES & PROJECTS
CREATE TABLE workspaces (
    id              TEXT PRIMARY KEY,           -- ULID
    name            TEXT NOT NULL,
    path            TEXT NOT NULL UNIQUE,
    created_at      INTEGER NOT NULL,
    updated_at      INTEGER NOT NULL,
    settings_json   TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE projects (
    id              TEXT PRIMARY KEY,           -- ULID
    workspace_id    TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    parent_id       TEXT REFERENCES projects(id) ON DELETE SET NULL,
    name            TEXT NOT NULL,
    description     TEXT,
    system_prompt   TEXT,
    rag_enabled     INTEGER NOT NULL DEFAULT 1,
    rag_top_k       INTEGER NOT NULL DEFAULT 4,
    rag_threshold   REAL NOT NULL DEFAULT 0.72,
    routing_mode    TEXT NOT NULL DEFAULT 'balanced', -- cost|quality|speed|referral|balanced
    created_at      INTEGER NOT NULL,
    updated_at      INTEGER NOT NULL,
    metadata_json   TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX idx_projects_workspace ON projects(workspace_id);
CREATE INDEX idx_projects_parent ON projects(parent_id);

-- THREADS (Conversations)
CREATE TABLE threads (
    id                      TEXT PRIMARY KEY,   -- ULID
    project_id              TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    title                   TEXT NOT NULL DEFAULT 'New Chat',
    summary_text            TEXT,
    summary_token_estimate  INTEGER DEFAULT 0,
    parent_thread_id        TEXT REFERENCES threads(id) ON DELETE SET NULL,
    branch_point_msg_id     TEXT,
    is_archived             INTEGER NOT NULL DEFAULT 0,
    created_at              INTEGER NOT NULL,
    updated_at              INTEGER NOT NULL,
    metadata_json           TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX idx_threads_project ON threads(project_id);
CREATE INDEX idx_threads_branch ON threads(parent_thread_id);

-- MESSAGES (Core Unit)
CREATE TABLE messages (
    id                  TEXT PRIMARY KEY,       -- ULID
    thread_id           TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    role                TEXT NOT NULL CHECK (role IN ('user','assistant','system','tool','summary')),
    content_json        TEXT NOT NULL,          -- {type: "text", text: "..."} | {type: "image", url: "...", detail: "high"}
    model_id            TEXT,
    provider_id         TEXT,
    tool_calls_json     TEXT,
    tool_call_id        TEXT,
    prompt_tokens       INTEGER DEFAULT 0,
    completion_tokens   INTEGER DEFAULT 0,
    total_tokens        INTEGER GENERATED ALWAYS AS (prompt_tokens + completion_tokens) STORED,
    cost_usd            REAL DEFAULT 0.0,
    latency_ms          INTEGER,
    status              TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('streaming','completed','error','aborted')),
    error_json          TEXT,
    sequence            INTEGER NOT NULL,
    created_at          INTEGER NOT NULL,
    metadata_json       TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX idx_messages_thread_seq ON messages(thread_id, sequence);
CREATE INDEX idx_messages_tool_call ON messages(tool_call_id);
CREATE INDEX idx_messages_model ON messages(model_id);

-- ARTIFACTS (Files, Code, Images, Structured Data)
CREATE TABLE artifacts (
    id                      TEXT PRIMARY KEY,   -- ULID
    message_id              TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    thread_id               TEXT NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    project_id              TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    type                    TEXT NOT NULL,      -- file|code|image|json|csv|mermaid|sql|diff
    title                   TEXT,
    filename                TEXT,
    language                TEXT,
    storage_type            TEXT NOT NULL DEFAULT 'inline' CHECK (storage_type IN ('inline','external')),
    content_text            TEXT,
    content_blob            BLOB,
    file_path               TEXT,
    size_bytes              INTEGER NOT NULL DEFAULT 0,
    mime_type               TEXT,
    version                 INTEGER NOT NULL DEFAULT 1,
    parent_artifact_id      TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
    created_at              INTEGER NOT NULL,
    metadata_json           TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX idx_artifacts_message ON artifacts(message_id);
CREATE INDEX idx_artifacts_thread ON artifacts(thread_id);
CREATE INDEX idx_artifacts_project ON artifacts(project_id);

-- EMBEDDINGS POINTERS (Vectors in LanceDB/Vec0)
CREATE TABLE embeddings (
    id                  TEXT PRIMARY KEY,       -- ULID (matches LanceDB row ID)
    source_type         TEXT NOT NULL CHECK (source_type IN ('message','artifact','project_note','file')),
    source_id           TEXT NOT NULL,
    project_id          TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    chunk_index         INTEGER NOT NULL DEFAULT 0,
    chunk_total         INTEGER NOT NULL DEFAULT 1,
    token_count         INTEGER NOT NULL,
    embedding_model     TEXT NOT NULL,          -- nomic-embed-text, text-embedding-3-small, bge-m3
    dim                 INTEGER NOT NULL,       -- 768, 1536, 1024
    lancedb_table       TEXT NOT NULL DEFAULT 'default',
    created_at          INTEGER NOT NULL
);
CREATE UNIQUE INDEX idx_embeddings_source_chunk ON embeddings(source_type, source_id, chunk_index);
CREATE INDEX idx_embeddings_project ON embeddings(project_id);

-- PROVIDERS & MODELS (Registry)
CREATE TABLE providers (
    id                  TEXT PRIMARY KEY,       -- ULID/Slug: openai, anthropic, ollama, openrouter, groq
    name                TEXT NOT NULL UNIQUE,
    type                TEXT NOT NULL CHECK (type IN ('cloud','local','gateway')),
    api_base_url        TEXT NOT NULL,
    auth_type           TEXT NOT NULL CHECK (auth_type IN ('bearer','api_key','none','oauth')),
    referral_code       TEXT,
    referral_url        TEXT,
    referral_notes      TEXT,
    supports_streaming  INTEGER NOT NULL DEFAULT 1,
    supports_tools      INTEGER NOT NULL DEFAULT 1,
    supports_vision     INTEGER NOT NULL DEFAULT 0,
    supports_json_mode  INTEGER NOT NULL DEFAULT 0,
    rpm_limit           INTEGER,
    tpm_limit           INTEGER,
    is_enabled          INTEGER NOT NULL DEFAULT 1,
    is_healthy          INTEGER NOT NULL DEFAULT 1,
    last_health_check   INTEGER,
    created_at          INTEGER NOT NULL,
    updated_at          INTEGER NOT NULL,
    config_json         TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE models (
    id                      TEXT PRIMARY KEY,   -- ULID
    provider_id             TEXT NOT NULL REFERENCES providers(id) ON DELETE CASCADE,
    api_name                TEXT NOT NULL,      -- gpt-4o, llama3.1:70b, claude-3-5-sonnet-latest
    display_name            TEXT NOT NULL,
    context_window          INTEGER NOT NULL,
    max_output              INTEGER NOT NULL,
    supports_tools          INTEGER NOT NULL DEFAULT 1,
    supports_vision         INTEGER NOT NULL DEFAULT 0,
    supports_json           INTEGER NOT NULL DEFAULT 0,
    supports_system_prompt  INTEGER NOT NULL DEFAULT 1,
    input_price_usd         REAL,
    output_price_usd        REAL,
    cache_read_price_usd    REAL,
    cache_write_price_usd   REAL,
    quality_score           REAL DEFAULT 7.0,
    speed_score             REAL DEFAULT 5.0,
    coding_score            REAL DEFAULT 7.0,
    reasoning_score         REAL DEFAULT 7.0,
    tags_json               TEXT NOT NULL DEFAULT '[]',
    is_active               INTEGER NOT NULL DEFAULT 1,
    is_deprecated           INTEGER NOT NULL DEFAULT 0,
    local_size_gb           REAL,
    local_ram_gb            REAL,
    local_filename          TEXT,
    created_at              INTEGER NOT NULL,
    updated_at              INTEGER NOT NULL,
    metadata_json           TEXT NOT NULL DEFAULT '{}',
    UNIQUE(provider_id, api_name)
);
CREATE INDEX idx_models_provider ON models(provider_id);

-- ROUTING RULES (Optimization Engine Config)
CREATE TABLE routing_rules (
    id                      TEXT PRIMARY KEY,   -- ULID
    project_id              TEXT REFERENCES projects(id) ON DELETE CASCADE, -- NULL = Global
    name                    TEXT NOT NULL,
    description             TEXT,
    priority                INTEGER NOT NULL DEFAULT 100,
    is_enabled              INTEGER NOT NULL DEFAULT 1,
    conditions_json         TEXT NOT NULL DEFAULT '{}',  -- {task_type, max_cost_per_1k, privacy, min_quality, prefer_referral}
    target_model_id         TEXT REFERENCES models(id) ON DELETE SET NULL,
    target_provider_id      TEXT REFERENCES providers(id) ON DELETE SET NULL,
    fallback_chain_json     TEXT NOT NULL DEFAULT '[]',
    created_at              INTEGER NOT NULL,
    updated_at              INTEGER NOT NULL
);
CREATE INDEX idx_routing_rules_project ON routing_rules(project_id);

-- USAGE & COST TRACKING (Analytics & Referral ROI)
CREATE TABLE usage_events (
    id                      TEXT PRIMARY KEY,   -- ULID
    timestamp               INTEGER NOT NULL,
    project_id              TEXT REFERENCES projects(id) ON DELETE SET NULL,
    thread_id               TEXT REFERENCES threads(id) ON DELETE SET NULL,
    message_id              TEXT REFERENCES messages(id) ON DELETE SET NULL,
    provider_id             TEXT NOT NULL REFERENCES providers(id),
    model_id                TEXT NOT NULL REFERENCES models(id),
    prompt_tokens           INTEGER NOT NULL,
    completion_tokens       INTEGER NOT NULL,
    cache_read_tokens       INTEGER DEFAULT 0,
    cache_write_tokens      INTEGER DEFAULT 0,
    cost_usd                REAL NOT NULL,
    ttft_ms                 INTEGER,
    total_latency_ms        INTEGER,
    referral_applied        INTEGER NOT NULL DEFAULT 0,
    referral_value_usd      REAL DEFAULT 0.0,
    task_type               TEXT,
    routing_rule_id         TEXT REFERENCES routing_rules(id) ON DELETE SET NULL,
    is_local                INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_usage_time ON usage_events(timestamp DESC);
CREATE INDEX idx_usage_project ON usage_events(project_id, timestamp);
CREATE INDEX idx_usage_provider ON usage_events(provider_id, timestamp);
CREATE INDEX idx_usage_referral ON usage_events(referral_applied, timestamp);

-- USER SETTINGS
CREATE TABLE user_settings (
    key             TEXT PRIMARY KEY,
    value_json      TEXT NOT NULL,
    updated_at      INTEGER NOT NULL
);

-- TRIGGERS (auto updated_at)
CREATE TRIGGER trg_workspaces_updated AFTER UPDATE ON workspaces BEGIN UPDATE workspaces SET updated_at = strftime('%s','now')*1000 WHERE id = NEW.id; END;
CREATE TRIGGER trg_projects_updated AFTER UPDATE ON projects BEGIN UPDATE projects SET updated_at = strftime('%s','now')*1000 WHERE id = NEW.id; END;
CREATE TRIGGER trg_threads_updated AFTER UPDATE ON threads BEGIN UPDATE threads SET updated_at = strftime('%s','now')*1000 WHERE id = NEW.id; END;
CREATE TRIGGER trg_providers_updated AFTER UPDATE ON providers BEGIN UPDATE providers SET updated_at = strftime('%s','now')*1000 WHERE id = NEW.id; END;
CREATE TRIGGER trg_models_updated AFTER UPDATE ON models BEGIN UPDATE models SET updated_at = strftime('%s','now')*1000 WHERE id = NEW.id; END;
CREATE TRIGGER trg_routing_rules_updated AFTER UPDATE ON routing_rules BEGIN UPDATE routing_rules SET updated_at = strftime('%s','now')*1000 WHERE id = NEW.id; END;

-- VIEWS
CREATE VIEW v_project_costs AS
SELECT p.id, p.name, COALESCE(SUM(u.cost_usd),0) as total_cost_usd, COALESCE(SUM(u.prompt_tokens+u.completion_tokens),0) as total_tokens, COUNT(DISTINCT u.thread_id) as thread_count, MAX(u.timestamp) as last_activity
FROM projects p LEFT JOIN usage_events u ON u.project_id = p.id GROUP BY p.id, p.name;

CREATE VIEW v_model_performance AS
SELECT m.id, m.display_name, prov.name as provider_name, COUNT(*) as request_count, AVG(u.total_latency_ms) as avg_latency_ms, AVG(u.ttft_ms) as avg_ttft_ms, SUM(u.cost_usd) as total_cost_usd, AVG(u.cost_usd) as avg_cost_per_request, SUM(CASE WHEN u.referral_applied=1 THEN 1 ELSE 0 END) as referral_requests
FROM usage_events u JOIN models m ON m.id=u.model_id JOIN providers prov ON prov.id=u.provider_id
WHERE u.timestamp > (strftime('%s','now')-30*24*3600)*1000
GROUP BY m.id, m.display_name, prov.name HAVING request_count > 5 ORDER BY avg_latency_ms ASC;

-- SEED DATA (Essential Providers)
INSERT INTO providers (id,name,type,api_base_url,auth_type,referral_code,referral_url,supports_vision,supports_tools,supports_json_mode,config_json) VALUES
('01ARZ3NDEKTSV4RRFFQ69G5FAV','OpenAI','cloud','https://api.openai.com/v1','bearer',NULL,NULL,1,1,1,'{}'),
('01ARZ3NDEKTSV4RRFFQ69G5FAW','Anthropic','cloud','https://api.anthropic.com/v1','bearer',NULL,NULL,1,1,1,'{"header_anthropic_version":"2023-06-01"}'),
('01ARZ3NDEKTSV4RRFFQ69G5FAX','OpenRouter','gateway','https://openrouter.ai/api/v1','bearer','YOUR_REF_CODE','https://openrouter.ai/signup?ref=YOUR_REF_CODE',1,1,1,'{}'),
('01ARZ3NDEKTSV4RRFFQ69G5FAY','Groq','cloud','https://api.groq.com/openai/v1','bearer','YOUR_GROQ_REF','https://console.groq.com/signup?ref=YOUR_GROQ_REF',0,1,1,'{}'),
('01ARZ3NDEKTSV4RRFFQ69G5FAZ','Ollama','local','http://localhost:11434/v1','none',NULL,NULL,0,1,0,'{"auto_detect":true}');

INSERT INTO models (id,provider_id,api_name,display_name,context_window,max_output,input_price_usd,output_price_usd,quality_score,speed_score,coding_score,tags_json,is_active) VALUES
('01ARZ3NDEKTSV4RRFFQ69G5FB0','01ARZ3NDEKTSV4RRFFQ69G5FAV','gpt-4o','GPT-4o',128000,16384,2.50,10.00,9.5,7.0,9.5,'["flagship","vision","tools","json"]',1),
('01ARZ3NDEKTSV4RRFFQ69G5FB1','01ARZ3NDEKTSV4RRFFQ69G5FAV','gpt-4o-mini','GPT-4o Mini',128000,16384,0.15,0.60,8.0,9.0,8.5,'["cheap","fast","vision","tools","json"]',1),
('01ARZ3NDEKTSV4RRFFQ69G5FB2','01ARZ3NDEKTSV4RRFFQ69G5FAW','claude-3-5-sonnet-20241022','Claude 3.5 Sonnet',200000,8192,3.00,15.00,9.8,6.0,9.9,'["flagship","vision","tools","json","long-context"]',1),
('01ARZ3NDEKTSV4RRFFQ69G5FB3','01ARZ3NDEKTSV4RRFFQ69G5FAW','claude-3-5-haiku-20241022','Claude 3.5 Haiku',200000,8192,0.80,4.00,8.5,8.5,9.0,'["cheap","fast","vision","tools","json","long-context"]',1),
('01ARZ3NDEKTSV4RRFFQ69G5FB4','01ARZ3NDEKTSV4RRFFQ69G5FAY','llama-3.1-70b-versatile','Llama 3.1 70B (Groq)',131072,8192,0.59,0.79,8.8,10.0,9.0,'["referral","fast","free-tier","coding","tools"]',1),
('01ARZ3NDEKTSV4RRFFQ69G5FB5','01ARZ3NDEKTSV4RRFFQ69G5FAY','llama-3.1-8b-instant','Llama 3.1 8B Instant (Groq)',131072,8192,0.05,0.08,7.0,10.0,7.5,'["referral","fastest","free-tier","tools"]',1),
('01ARZ3NDEKTSV4RRFFQ69G5FB6','01ARZ3NDEKTSV4RRFFQ69G5FAZ','llama3.1:70b','Llama 3.1 70B (Local)',131072,4096,NULL,NULL,8.5,4.0,8.8,'["local","free","private","coding","heavy"]',1),
('01ARZ3NDEKTSV4RRFFQ69G5FB7','01ARZ3NDEKTSV4RRFFQ69G5FAZ','qwen2.5-coder:32b','Qwen 2.5 Coder 32B (Local)',32768,4096,NULL,NULL,8.0,5.0,9.5,'["local","free","private","coding","specialist"]',1);

-- Global Routing Rule: Prefer Referral for Coding if Quality >= 8.5
INSERT INTO routing_rules (id,project_id,name,priority,conditions_json,target_provider_id,fallback_chain_json) VALUES
('01ARZ3NDEKTSV4RRFFQ69G5FC0',NULL,'Referral Coding Optimizer',10,'{"task_type":"coding","min_quality":8.5,"prefer_referral":true}','01ARZ3NDEKTSV4RRFFQ69G5FAY','["01ARZ3NDEKTSV4RRFFQ69G5FB2","01ARZ3NDEKTSV4RRFFQ69G5FB0"]');
```

---

## 3. Rust / TypeScript Types (Zero-Cost Bindings)

**Rust (`sqlx` + `serde`)** — `sqlx::FromRow` derives automatically. Run `cargo install sqlx-cli && sqlx prepare`.

**TypeScript (Frontend/IPC)** — Shared types for Tauri commands. Includes `ULID`, `Project`, `Message`, `Provider`, `Model`, `RoutingRule`, `UsageEvent`.

---

## 4. Migration Strategy

```
migrations/
├── 20260820_0001_initial_schema.sql      -- Core tables
├── 20260820_0002_artifacts.sql           -- Artifacts & Embeddings
├── 2060820_0003_providers_models.sql     -- Registry + Seed
├── 20260820_0004_routing_rules.sql       -- Optimization Engine
├── 20260820_0005_usage_analytics.sql     -- Cost/Referral tracking
└── 20260820_0006_views_triggers.sql      -- Views, Triggers, Indexes
```

---

## 5. Critical Implementation Notes

| Concern | Decision |
|---|---|
| **ULID Generation** | Rust: `ulid::Ulid::new()`, TS: `ulid` npm. Sortable by time. |
| **JSONB in SQLite** | Use `->>`/`->` operators. `json_extract(metadata_json, '$.tags')`. |
| **Vector Search** | **Not in SQLite.** Use `lancedb` crate / `sqlite-vec`. `embeddings` table = catalog only. |
| **Cost Calculation** | Calculate `cost_usd` in Rust backend at ingestion using `models` pricing snapshot. Store in `usage_events`. |
| **Referral Attribution** | `usage_events.referral_applied` = 1 if `providers.referral_code` non-null at request time. Enables ROI dashboard. |
| **Local Model Discovery** | Background task: `ollama list` → Upsert `models` with `input_price_usd = NULL`. |
| **Encryption** | **API Keys NEVER in DB.** OS Keychain (`keyring` crate / `tauri-plugin-store`). DB holds only `provider_id` ref. |

---

> **Accepted as Canonical.** Any schema changes require new session + Owner approval.