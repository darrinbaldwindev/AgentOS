# Session 006: Tauri IPC Contract (The "Frontend-Backend Bridge")
**Project:** AgentOS | **Component:** `ipc` (Rust Sidecar ↔ TypeScript Frontend)
**Date:** 2026-08-20
**Status:** ✅ Completed — Type-Safe Commands v1.0, Using `specta` + `ts-bindgen`

---

## 1. Design Principles

- **Zero Boilerplate:** Rust structs → TypeScript types automatically via `specta` + `ts-bindgen`
- **Streaming First:** `tauri::ipc::Channel` for Server-Sent Events (SSE) like streaming to frontend
- **Error Transparency:** `AppError` enum serialized to TS, matches `ProviderError` variants
- **Single Source of Truth:** All types defined in Rust, frontend consumes generated `.d.ts`

---

## 2. Core Types (Shared via `specta`)

```rust
// src/ipc/types.rs
use specta::Type;
use serde::{Serialize, Deserialize};
use crate::db::{Project, Thread, Message, Model, Provider, UsageEvent};
use crate::context::{AssemblyRequest, AssembledPrompt};
use crate::router::{Router, RoutingContext, RoutingDecision};

pub type ULID = String;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct CreateProjectPayload {
    pub workspace_id: ULID,
    pub parent_id: Option<ULID>,
    pub name: String,
    pub description: Option<String>,
    pub system_prompt: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct UserMessageInput {
    pub text: String,
    pub files: Vec<FileInput>,      // { name, mime_type, base64_or_path }
    pub artifact_refs: Vec<ULID>,   // Pinned artifact IDs
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SendMessageRequest {
    pub thread_id: ULID,
    pub project_id: ULID,
    pub content: UserMessageInput,
    pub params: Option<GenerationParams>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct RoutingContextInput {
    pub task_type: Option<String>,
    pub project_id: ULID,
    pub user_prefs: UserRoutingPrefsInput,
    pub estimated_tokens: TokenEstimateInput,
    pub privacy_level: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ProviderConfigInput {
    pub name: String,
    pub r#type: String, // cloud|local|gateway
    pub api_base_url: String,
    pub auth_type: String,
    pub referral_code: Option<String>,
    pub config_json: serde_json::Value,
}
```

---

## 3. Tauri Commands (`src/ipc/commands.rs`)

```rust
use tauri::{command, ipc::Channel, State};
use specta::Type;
use crate::AppState; // { db, registry, router, assembler, sandbox }

// WORKSPACE / PROJECT
#[command]
#[specta::type]
pub async fn create_workspace(state: State<'_, AppState>, name: String, path: String) -> Result<Workspace, AppError> { ... }

#[command]
#[specta::type]
pub async fn list_projects(state: State<'_, AppState>, workspace_id: ULID) -> Result<Vec<Project>, AppError> { ... }

#[command]
#[specta::type]
pub async fn create_project(state: State<'_, AppState>, payload: CreateProjectPayload) -> Result<Project, AppError> { ... }

// CHAT / STREAMING (Critical Path)
#[command]
#[specta::type]
pub async fn send_message(
    state: State<'_, AppState>,
    channel: Channel<StreamChunk>,
    request: SendMessageRequest
) -> Result<Message, AppError> {
    let req = request.0; // Unwrap specta tuple

    // 1. Route
    let decision = state.router.route(RoutingContext::from(&req)).await;

    // 2. Assemble Context
    let assembled = state.assembler.assemble(AssemblyRequest {
        thread_id: req.thread_id,
        project_id: req.project_id,
        user_message: req.content,
        overrides: Some(AssemblyOverrides {
            model_id: Some(decision.model_id),
            provider_hint: Some(decision.provider_id),
        }),
    }).await?;

    // 3. Get Provider
    let provider = state.registry.get_for_model(&decision.model_id).await?;
    let model = state.db.get_model(&decision.model_id).await?;

    // 4. Stream
    let mut stream = provider.stream_chat(&model, assembled, req.params).await?;
    let mut full_response = String::new();
    let mut tool_calls = Vec::new();
    let mut final_usage = None;

    while let Some(chunk_result) = stream.next().await {
        let chunk = chunk_result.map_err(AppError::Provider)?;
        if let Some(c) = &chunk.content { full_response.push_str(c); }
        if let Some(tc) = &chunk.tool_calls { tool_calls.extend(tc.clone()); }
        if let Some(u) = &chunk.usage { final_usage = Some(u.clone()); }
        channel.send(chunk).map_err(|_| AppError::ChannelClosed)?;
    }

    // 5. Persist Assistant Message + Usage Event
    let msg = save_assistant_message(req.thread_id, &full_response, tool_calls, final_usage, &decision).await?;
    Ok(msg)
}

// RAG / ARTIFACTS
#[command]
#[specta::type]
pub async fn index_project_files(state: State<'_, AppState>, project_id: ULID, paths: Vec<String>) -> Result<IndexResult, AppError> { ... }

#[command]
#[specta::type]
pub async fn upload_artifact(state: State<'_, AppState>, thread_id: ULID, file: ArtifactUpload) -> Result<Artifact, AppError> { ... }

// PROVIDER / MODEL MANAGEMENT
#[command]
#[specta::type]
pub async fn list_providers(state: State<'_, AppState>) -> Result<Vec<Provider>, AppError> { ... }

#[command]
#[specta::type]
pub async fn add_provider(state: State<'_, AppState>, config: ProviderConfigInput) -> Result<Provider, AppError> {
    // 1. Validate connection (health_check)
    // 2. Save to DB (API Key → Keychain, Config → DB)
    // 3. Fetch models & upsert
    // 4. Register in Registry
}

#[command]
#[specta::type]
pub async fn refresh_models(state: State<'_, AppState>, provider_id: ULID) -> Result<Vec<Model>, AppError> { ... }

// ROUTING / REFERRAL
#[command]
#[specta::type]
pub async fn get_routing_decision(state: State<'_, AppState>, ctx: RoutingContextInput) -> Result<RoutingDecision, AppError> { ... }

#[command]
#[specta::type]
pub async fn get_referral_dashboard(state: State<'_, AppState>, workspace_id: ULID) -> Result<ReferralDashboard, AppError> { ... }

// SETTINGS / KEYCHAIN
#[command]
#[specta::type]
pub async fn set_api_key(state: State<'_, AppState>, provider_id: ULID, key: String) -> Result<(), AppError> {
    // Write to OS Keychain (tauri-plugin-store / keyring)
}

#[command]
#[specta::type]
pub async fn test_provider_connection(state: State<'_, AppState>, provider_id: ULID) -> Result<HealthStatus, AppError> { ... }
```

---

## 4. Generated TypeScript (`bindings.ts` — Auto-generated)

```typescript
// Frontend uses this EXACTLY:
import { invoke } from '@tauri-apps/api/core';
import { Channel } from '@tauri-apps/api/core';

interface SendMessageRequest {
  threadId: string;
  projectId: string;
  content: UserMessageInput;
  params?: GenerationParams;
}

// Usage in React/Svelte Component:
function useChatStream(threadId: string, projectId: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [streaming, setStreaming] = useState(false);

  const send = async (text: string) => {
    setStreaming(true);
    const channel = new Channel<StreamChunk>();
    channel.onmessage = (chunk) => updateStreamingMessage(chunk);
    channel.onclose = () => setStreaming(false);
    try {
      await invoke('send_message', { channel, request: { threadId, projectId, content: { text } } });
    } catch (e) { handleError(e); }
  };
  return { send, streaming };
}
```

---

## 5. Build Integration

```toml
# Cargo.toml
[dependencies]
tauri = { version = "2", features = ["ipc-channel"] }
specta = { version = "0.8", features = ["tauri"] }
serde = { version = "1.0", features = ["derive"] }
tokio = { version = "1", features = ["full"] }
tokio-stream = "0.1"
futures = "0.3"

[build-dependencies]
ts-bindgen = "0.1" # or use tauri-plugin-specta
```

```json
// package.json
{
  "scripts": {
    "gen:bindings": "cargo run --bin gen_bindings",
    "dev": "npm run gen:bindings && tauri dev"
  }
}
```

---

## 6. Error Handling (Unified)

```rust
// src/ipc/error.rs
#[derive(Debug, thiserror::Error, Serialize, Type)]
pub enum AppError {
    #[error("Database: {0}")] Database(String),
    #[error("Provider: {0}")] Provider(#[from] ProviderError),
    #[error("Context Assembly: {0}")] ContextAssembly(String),
    #[error("Routing: {0}")] Routing(String),
    #[error("Sandbox: {0}")] Sandbox(String),
    #[error("IPC Channel closed")] ChannelClosed,
    #[error("Serialization: {0}")] Serialization(String),
    #[error("Not found: {0}")] NotFound(String),
    #[error("Permission denied: {0}")] PermissionDenied(String),
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/ipc/`. Frontend consumes generated types.