# Session 011: Sandbox Execution Engine (Native Code Execution)
**Project:** AgentOS | **Component:** `sandbox/manager` (Rust Sidecar)
**Date:** 2026-08-20
**Status:** 🟡 Spec Complete — Ready for Implementation (No Pilot Dependency)

---

## 1. Design Goals

- **Replace TypingMind's Pyodide (WASM)** with real process isolation
- **Support:** Python, Node.js, Deno, Bun, Rust, Bash, SQL
- **Real dependencies:** `pip install torch`, `npm install playwright`, `cargo add serde`
- **Git integration:** Sandbox has `git` → agents can clone/commit/push
- **Persistence:** Optional sandbox state survival across turns
- **Security:** Default deny, explicit allow (network, fs, env)

---

## 2. Sandbox Backend Abstraction

```rust
// src/sandbox/manager.rs
use async_trait::async_trait;
use serde::{Serialize, Deserialize};
use specta::Type;
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum SandboxBackend {
    LocalJail { profile: SandboxProfile },           // Default: bwrap/firejail
    MicroVm { image: String },                       // Opt-in: gVisor/Firecracker
    Container { image: String, volumes: Vec<Mount> }, // If Docker present
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SandboxProfile {
    pub allow_network: bool,                         // Default: false
    pub allow_fs_read: Vec<PathBuf>,                 // Project folder only
    pub allow_fs_write: Vec<PathBuf>,                // .artifacts/ folder only
    pub max_cpu_secs: u32,                           // 30
    pub max_ram_mb: u32,                             // 512
    pub max_pids: u32,                               // 50
    pub env_whitelist: Vec<String>,                  // ["PATH", "HOME", "GITHUB_TOKEN", "PYTHONPATH"]
    pub seccomp_profile: Option<String>,             // Custom seccomp (Linux)
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum Language { 
    Python, Node, Deno, Bun, Rust, Bash, Sql 
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct FileInput {
    pub name: String,
    pub content: String,        // Base64 or text
    pub mime_type: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ExecutionResult {
    pub stdout: String,
    pub stderr: String,
    pub exit_code: i32,
    pub duration_ms: u64,
    pub artifacts: Vec<ArtifactOutput>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ArtifactOutput {
    pub path: String,           // Relative to /workspace
    pub size_bytes: u64,
    pub mime_type: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SandboxState {
    pub working_dir: String,
    pub env: HashMap<String, String>,
    pub installed_packages: HashMap<Language, Vec<String>>,
    pub git_status: Option<GitStatus>,
}

#[async_trait]
pub trait Sandbox: Send + Sync {
    async fn execute(&self, lang: Language, code: String, files: Vec<FileInput>) -> Result<ExecutionResult, SandboxError>;
    async fn install_package(&self, lang: Language, pkg: String) -> Result<(), SandboxError>;
    async fn snapshot(&self) -> Result<SandboxState, SandboxError>;
    async fn restore(&self, state: SandboxState) -> Result<(), SandboxError>;
    async fn health_check(&self) -> Result<SandboxHealth, SandboxError>;
}
```

---

## 3. LocalJail Implementation (bwrap/firejail)

### Linux: bubblewrap (bwrap) — Most Portable
```rust
// src/sandbox/bwrap.rs
pub struct BwrapSandbox {
    profile: SandboxProfile,
    workspace_dir: PathBuf,      // Project root
    artifacts_dir: PathBuf,      // Project/.artifacts
}

impl Sandbox for BwrapSandbox {
    async fn execute(&self, lang: Language, code: String, files: Vec<FileInput>) -> Result<ExecutionResult, SandboxError> {
        // 1. Write code + files to temp dir under workspace
        // 2. Build bwrap args:
        //    --ro-bind /usr /usr
        //    --ro-bind /lib /lib
        //    --proc /proc
        //    --dev /dev
        //    --bind {workspace} /workspace
        //    --bind {artifacts} /workspace/.artifacts
        //    --unshare-net (if !allow_network)
        //    --unshare-pids
        //    --cap-drop ALL
        //    --seccomp <profile> (if provided)
        //    --die-with-parent
        //    -- /usr/bin/python3 /workspace/script.py
        // 3. Spawn with timeout, capture stdout/stderr
        // 4. Collect artifacts from /workspace/.artifacts
    }
    
    async fn install_package(&self, lang: Language, pkg: String) -> Result<(), SandboxError> {
        // Run pip/npm/cargo inside sandbox with network temporarily allowed
        // Persist to sandbox-specific cache dir
    }
}
```

### macOS: seatbelt (sandbox-exec) or firejail (brew)
### Windows: Job Objects + AppContainer (via `windows` crate)

**Fallback Priority:** `bwrap` → `firejail` → `seatbelt` → `Job Objects` → **Error: No sandbox backend available**

---

## 4. Language Runtimes & Package Management

| Language | Binary | Package Cmd | Cache Dir | Version Detection |
|---|---|---|---|---|
| **Python** | `python3` / `python` | `pip install {pkg}` | `~/.cache/agentos/pip` | `python --version` |
| **Node** | `node` | `npm install {pkg}` | `~/.cache/agentos/npm` | `node --version` |
| **Deno** | `deno` | `deno install {pkg}` | `DENO_DIR` | `deno --version` |
| **Bun** | `bun` | `bun add {pkg}` | `~/.bun` | `bun --version` |
| **Rust** | `cargo` | `cargo add {pkg}` | `~/.cargo` | `rustc --version` |
| **Bash** | `bash` | N/A | N/A | `bash --version` |
| **SQL** | `sqlite3` / `duckdb` | N/A | N/A | `sqlite3 --version` |

**Package Persistence:** Each sandbox gets a persistent cache dir (`~/.cache/agentos/sandboxes/{sandbox_id}/`) so installs survive restarts.

---

## 5. Artifact I/O Pattern

```
Host (Project)                    Sandbox (/workspace)
├── .artifacts/                   ├── .artifacts/ (bind mount)
│   ├── chart.png                 │   ├── chart.png
│   └── data.csv                  │   └── data.csv
├── src/                          ├── src/ (ro bind)
│   └── main.py                   │   └── main.py
└── data/                         ├── data/ (ro bind)
    └── input.json                │   └── input.json
```

**Flow:**
1. User pins artifact in chat → `FileInput` sent to sandbox
2. Sandbox writes to `/workspace/.artifacts/{uuid}.ext`
3. On completion, sandbox returns `ArtifactOutput[]`
4. Coordinator creates `Artifact` DB records, links to message

---

## 6. Git Integration (Native)

```rust
impl Sandbox for BwrapSandbox {
    // Git is available inside sandbox (installed in base image)
    // Agent can run:
    //   git clone https://github.com/user/repo.git /workspace/repo
    //   git -C /workspace/repo add . && git commit -m "msg"
    //   git -C /workspace/repo push origin main
    // 
    // Auth: GITHUB_TOKEN passed via env_whitelist → MCP GitHub server provides token
}
```

---

## 7. Time Travel Debugging (Snapshot/Restore)

```rust
// Frontend: "Rewind to turn 3" button
async fn rewind_sandbox(&self, turn: u32) -> Result<(), Error> {
    let state = self.sandbox.snapshot().await?;  // Save current
    self.sandbox_history.insert(current_turn, state);
    
    if let Some(historical) = self.sandbox_history.get(&turn) {
        self.sandbox.restore(historical.clone()).await?;
        self.current_turn = turn;
    }
}
```

---

## 8. Resource Limits & Monitoring

```rust
#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SandboxHealth {
    pub backend: String,
    pub available: bool,
    pub cpu_usage_pct: f32,
    pub ram_usage_mb: u64,
    pub active_processes: u32,
    pub disk_usage_mb: u64,
}

// Enforced via:
// - bwrap: --rlimit-cpu, --rlimit-as, --rlimit-nproc
// - cgroups v2 (if available): memory.max, cpu.max, pids.max
// - Timeout: tokio::time::timeout(Duration::from_secs(profile.max_cpu_secs))
```

---

## 9. Frontend UX

```svelte
<!-- SandboxConsole.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  export let language: Language;
  let code = $state('');
  let output = $state<ExecutionResult | null>(null);
  let running = $state(false);
  
  async function run() {
    running = true;
    output = null;
    try {
      output = await invoke('execute_sandbox_code', { 
        language, 
        code, 
        files: pinnedArtifacts 
      });
    } catch (e) {
      output = { stdout: '', stderr: e.toString(), exit_code: -1, duration_ms: 0, artifacts: [] };
    }
    running = false;
  }
  
  async function installPkg(pkg: string) {
    await invoke('install_sandbox_package', { language, pkg });
    notify(`Installed ${pkg}`);
  }
</script>

<div class="sandbox-console">
  <select bind:value={language}>
    <option value="Python">Python</option>
    <option value="Node">Node.js</option>
    <option value="Rust">Rust</option>
    <option value="Bash">Bash</option>
  </select>
  
  <textarea bind:value={code} placeholder="Write code..." />
  
  <div class="actions">
    <button onclick={run} disabled={running}>
      {running ? 'Running...' : '▶ Run'}
    </button>
    <input type="text" placeholder="package name" 
      onkeydown={e => e.key === 'Enter' && installPkg(e.currentTarget.value)} />
  </div>
  
  {#if output}
    <pre class={output.exit_code === 0 ? 'success' : 'error'}>
      {output.stdout}
      {output.stderr}
    </pre>
    {#if output.artifacts.length}
      <div class="artifacts">
        {#each output.artifacts as art}
          <ArtifactLink path={art.path} />
        {/each}
      </div>
    {/if}
  {/if}
</div>
```

---

## 10. IPC Commands

```rust
// src/ipc/sandbox_commands.rs
#[command]
#[specta::type]
pub async fn execute_sandbox_code(
    state: State<'_, AppState>,
    language: Language,
    code: String,
    files: Vec<FileInput>
) -> Result<ExecutionResult, AppError> {
    state.sandbox.execute(language, code, files).await.map_err(AppError::Sandbox)
}

#[command]
#[specta::type]
pub async fn install_sandbox_package(
    state: State<'_, AppState>,
    language: Language,
    pkg: String
) -> Result<(), AppError> {
    state.sandbox.install_package(language, pkg).await.map_err(AppError::Sandbox)
}

#[command]
#[specta::type]
pub async fn snapshot_sandbox(state: State<'_, AppState>) -> Result<SandboxState, AppError> {
    state.sandbox.snapshot().await.map_err(AppError::Sandbox)
}

#[command]
#[specta::type]
pub async fn restore_sandbox(state: State<'_, AppState>, state: SandboxState) -> Result<(), AppError> {
    state.sandbox.restore(state).await.map_err(AppError::Sandbox)
}

#[command]
#[specta::type]
pub async fn get_sandbox_health(state: State<'_, AppState>) -> Result<SandboxHealth, AppError> {
    state.sandbox.health_check().await.map_err(AppError::Sandbox)
}
```

---

> **Ready for Implementation.** No dependency on Researcher pilot. Core `BwrapSandbox` can be built first.