# Session 015: Usage Dashboard (Context Budget + Referral Earnings + Cost Savings)
**Project:** AgentOS | **Component:** `dashboard/usage` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Dashboard Panels

| Panel | Metrics | Visualization | Update Frequency |
|-------|---------|---------------|------------------|
| **Context Budget Bar** | System / Recent / RAG / Artifacts / Summary / User Input tokens | Stacked horizontal bar (Session 003) | Per message |
| **Referral Earnings** | Total credits/$ earned, per-provider breakdown, trend, projected monthly | Bar chart + sparklines | Real-time on referral_applied |
| **Cost Savings** | vs. Cursor ($20/mo), vs. Copilot ($10/mo), vs. Direct API list prices | Comparison cards | Daily rollup |
| **Model Usage** | Tokens per model, cost per model, latency per model, quality score | Stacked area chart | Per message |
| **Agent Loop Efficiency** | Steps per task, success rate, cost per task, avg latency | Funnel + metrics | Per agent run |
| **RAG Health** | Indexed MB, query latency, hit rate, staleness, chunk count | Gauge + trend | On index/reindex |

---

## 2. Referral Earnings Calculation

```rust
// src/dashboard/referral_tracker.rs
use serde::{Serialize, Deserialize};
use specta::Type;
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ReferralEarnings {
    pub total_usd: f64,
    pub total_credits: HashMap<String, f64>, // provider -> credits
    pub by_provider: Vec<ProviderEarnings>,
    pub projected_monthly: f64,
    pub referral_velocity: f64, // referrals per week
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ProviderEarnings {
    pub provider: String,
    pub referrals: u32,
    pub credits_earned: f64,
    pub usd_value: f64,
    pub program_type: ReferralType, // CreditShare | Cash | Hybrid
    pub avg_value_per_referral: f64,
    pub next_milestone: Option<Milestone>,
    pub trend: Trend, // Up | Down | Stable
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum ReferralType { CreditShare, Cash, Hybrid }

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct Milestone {
    pub referrals_needed: u32,
    pub reward: String,
    pub estimated_date: Option<i64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum Trend { Up, Down, Stable }

impl ReferralTracker {
    pub fn calculate(&self, usage_events: &[UsageEvent], registry: &Registry) -> ReferralEarnings {
        // 1. Filter events with referral_applied = true
        // 2. Group by provider
        // 3. Apply program terms:
        //    - Perplexity: $10/mo * referrals * months_active (capped 12)
        //    - Taskade: 50% * referred_user_spend
        //    - OpenRouter: 20% * referred_user_spend (if program restored)
        //    - Gumloop: 25% * referred_user_spend (12 mo)
        //    - Lindy: 30-40% * referred_user_spend (1-2 yr)
        // 4. Project forward based on current referral velocity
    }
}
```

---

## 3. Cost Savings vs. Competitors

```rust
#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SavingsReport {
    pub agentos_cost_usd: f64,
    pub cursor_equivalent_usd: f64,    // $20/mo flat
    pub copilot_equivalent_usd: f64,   // $10/mo flat
    pub direct_api_equivalent_usd: f64, // Same usage at list prices
    pub savings_vs_cursor_pct: f32,
    pub savings_vs_copilot_pct: f32,
    pub referral_offset_usd: f64,       // Money earned back
    pub net_cost_usd: f64,              // agentos_cost - referral_offset
    pub breakdown: SavingsBreakdown,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SavingsBreakdown {
    pub local_model_savings: f64,
    pub referral_earnings: f64,
    pub smart_routing_savings: f64,
    pub prompt_caching_savings: f64,
    pub total_savings: f64,
}

impl SavingsCalculator {
    pub fn calculate(&self, usage: &[UsageEvent], entitlements: &Entitlements) -> SavingsReport {
        let agentos_cost = usage.iter().map(|u| u.cost_usd).sum::<f64>();
        let cursor_equiv = 20.0; // $20/mo flat
        let copilot_equiv = 10.0; // $10/mo flat
        
        // Direct API equivalent: same token usage at list prices (no routing optimization)
        let direct_api = usage.iter().map(|u| {
            let model = self.registry.get_model(&u.model_id).unwrap();
            (u.prompt_tokens as f64 * model.input_price_usd.unwrap_or(0.0) / 1_000_000.0) +
            (u.completion_tokens as f64 * model.output_price_usd.unwrap_or(0.0) / 1_000_000.0)
        }).sum::<f64>();
        
        let referral_offset = self.referral_tracker.calculate(usage, &self.registry).total_usd;
        let net_cost = agentos_cost - referral_offset;
        
        SavingsReport {
            agentos_cost_usd: agentos_cost,
            cursor_equivalent_usd: cursor_equiv,
            copilot_equivalent_usd: copilot_equiv,
            direct_api_equivalent_usd: direct_api,
            savings_vs_cursor_pct: ((cursor_equiv - net_cost) / cursor_equiv * 100.0).max(0.0),
            savings_vs_copilot_pct: ((copilot_equiv - net_cost) / copilot_equiv * 100.0).max(0.0),
            referral_offset_usd: referral_offset,
            net_cost_usd: net_cost,
            breakdown: self.calculate_breakdown(usage),
        }
    }
}
```

---

## 4. Frontend (Svelte 5 + Chart.js)

```svelte
<!-- UsageDashboard.svelte -->
<script lang="ts">
  import { onMount } from 'svelte';
  import { invoke } from '@tauri-apps/api/core';
  import { Chart, registerables } from 'chart.js';
  Chart.register(...registerables);
  
  let dashboard = $state<UsageDashboard>();
  let period = $state<'7d' | '30d' | '90d' | 'all'>('30d');
  let charts = $state<Map<string, Chart>>(new Map());
  
  async function load() {
    dashboard = await invoke('get_usage_dashboard', { period });
    renderCharts();
  }
  
  function renderCharts() {
    if (!dashboard) return;
    
    // Referral Earnings Chart
    renderBarChart('referral-chart', dashboard.referral.by_provider.map(p => p.provider), 
      dashboard.referral.by_provider.map(p => p.usd_value));
    
    // Model Usage Area Chart
    renderAreaChart('model-usage-chart', dashboard.model_usage);
    
    // Cost Savings Comparison
    renderComparisonChart('savings-chart', dashboard.savings);
    
    // Agent Loop Funnel
    renderFunnelChart('agent-funnel', dashboard.agent_loops);
  }
  
  onMount(load);
  
  $: period && load();
</script>

<div class="dashboard-grid">
  <!-- Context Budget Bar (always visible) -->
  <ContextBudgetBar budget={dashboard?.current_context_budget} />
  
  <!-- Referral Earnings -->
  <Card title="Referral Earnings" value={dashboard?.referral?.total_usd?.toFixed(2)} 
        subtitle={`${dashboard?.referral?.referrals} referrals • ${dashboard?.referral?.projected_monthly?.toFixed(2)}/mo projected`}>
    <canvas id="referral-chart"></canvas>
    <ProviderEarningsTable data={dashboard?.referral?.by_provider} />
  </Card>
  
  <!-- Cost Savings -->
  <Card title="Monthly Cost" value={dashboard?.savings?.net_cost_usd?.toFixed(2)} 
        subtitle="vs Cursor: ${dashboard?.savings?.cursor_equivalent_usd?.toFixed(2)} • vs Copilot: ${dashboard?.savings?.copilot_equivalent_usd?.toFixed(2)}">
    <canvas id="savings-chart"></canvas>
    <SavingsBreakdown savings={dashboard?.savings} />
  </Card>
  
  <!-- Model Usage -->
  <Card title="Model Usage (30d)" full-width>
    <canvas id="model-usage-chart"></canvas>
  </Card>
  
  <!-- Agent Loop Efficiency -->
  <Card title="Agent Loops" value={dashboard?.agent_loops?.success_rate?.toFixed(1)}% 
        subtitle={`${dashboard?.agent_loops?.total_runs} runs • ${dashboard?.agent_loops?.avg_steps} avg steps`}>
    <canvas id="agent-funnel"></canvas>
  </Card>
  
  <!-- RAG Health -->
  <Card title="RAG Health" value={`${dashboard?.rag_health?.indexed_mb} MB`} 
        subtitle={`Hit rate: ${dashboard?.rag_health?.hit_rate_pct}% • Latency: ${dashboard?.rag_health?.avg_latency_ms}ms`}>
    <RAGHealthGauges health={dashboard?.rag_health} />
  </Card>
</div>

<select bind:value={period} class="period-selector">
  <option value="7d">Last 7 Days</option>
  <option value="30d">Last 30 Days</option>
  <option value="90d">Last 90 Days</option>
  <option value="all">All Time</option>
</select>
```

---

## 5. IPC Commands

```rust
// src/ipc/dashboard_commands.rs
#[command]
#[specta::type]
pub async fn get_usage_dashboard(
    state: State<'_, AppState>, 
    period: DashboardPeriod
) -> Result<UsageDashboard, AppError> {
    let usage = state.db.get_usage_events(period).await?;
    let entitlements = state.license_validator.current_entitlements();
    
    let referral = state.referral_tracker.calculate(&usage, &state.registry);
    let savings = state.savings_calculator.calculate(&usage, &entitlements);
    let model_usage = state.analytics.model_usage_summary(&usage);
    let agent_loops = state.analytics.agent_loop_efficiency(&usage);
    let rag_health = state.rag.get_health().await?;
    let current_context = state.context_assembler.get_last_budget()?;
    
    Ok(UsageDashboard {
        current_context_budget: current_context,
        referral,
        savings,
        model_usage,
        agent_loops,
        rag_health,
        period,
    })
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum DashboardPeriod { Last7Days, Last30Days, Last90Days, All }

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct UsageDashboard {
    pub current_context_budget: TokenBudget,
    pub referral: ReferralEarnings,
    pub savings: SavingsReport,
    pub model_usage: Vec<ModelUsageSummary>,
    pub agent_loops: AgentLoopEfficiency,
    pub rag_health: RAGHealth,
    pub period: DashboardPeriod,
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/dashboard/` + frontend components.