# Session 008: MCP-First Tools & Sandbox (The "Quality Connections" Architecture)
**Project:** AgentOS | **Components:** `mcp/client`, `sandbox/manager`, `registry/manager`
**Date:** 2026-08-20
**Status:** ✅ Completed — Architecture Spec v1.0, Replaces TypingMind Plugins/WASM

---

## 1. Why MCP (Model Context Protocol)?

TypingMind uses **WASM plugins (Pyodide)** — slow, no C-extensions, no native binaries.
**MCP gives us:**
- Standardized interface: `tools/list`, `tools/call` (JSON-RPC 2.0 over stdio/SSE)
- **Real sandboxes:** Python with `numpy/pandas/playwright`, Node with `npm`, Rust with `cargo`
- **Process isolation:** Crashes don't kill the app
- **Auth encapsulation:** OAuth/tokens live inside MCP server, not core app
- **Discovery:** `mcp list` → user sees capabilities, not APIs

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    AGENTOS SIDECAR (Rust)                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
│  │ MCP Registry │  │ MCP Client   │  │ Sandbox Manager  │  │
│  │ (Verified    │  │ (stdio/SSE/  │  │ (bwrap/firejail/ │  │
│  │  + Custom)   │  │  Streamable) │  │  Docker)         │  │
│  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘  │
│         │                 │                     │           │
│         ▼                 ▼                     ▼           │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              TOOL SET AGGREGATOR                      │  │
│  │  Merges tools from 10+ MCP servers into one          │  │
│  │  `tools` list for LLM. Handles name collisions.      │  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. MCP Registry: Curated, Not Open

**Three Tiers — User Assurance Built-In:**

| Tier | Name | Criteria | Examples |
|---|---|---|---|
| **Tier 1: Verified** | Built-in, Referral-linked, Audited by us | Official MCP server exists, referral program verified, tested | `github-official` (our ref), `perplexity-search` (affiliate), `sqlite-analyzer`, `filesystem-secure`, `code-executor-python` |
| **Tier 2: Community** | Signed by known devs, user opts in | Community MCP server, maintainer verified | `brave-search`, `notion-api`, `linear-api` |
| **Tier 3: Experimental** | User adds custom `stdio` command or `http` URL | No verification, user assumes risk | `manus-mcp` (browser automation), custom internal tools |

**UI Representation:**
```tsx
<ToolCard 
  tier="verified" 
  badge="Referral Active" 
  source="github.com/agentos/registry" 
  lastAudit="2026-08-15"
  capabilities={['repo_read', 'issue_write', 'code_search']}
/>
<ToolCard 
  tier="community" 
  warning="Unverified Publisher" 
  source="github.com/random-user/mcp-manus"
/>
```

---

## 4. MCP Client Implementation (`src/mcp/client.rs`)

```rust
use async_trait::async_trait;
use rmcp::transport::{StdioTransport, SseTransport, StreamableHttpTransport};
use rmcp::{ServerInfo, Tool};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum McpTransportConfig {
    Stdio { command: String, args: Vec<String>, env: HashMap<String, String> },
    Sse { url: String, headers: HashMap<String, String> },
    StreamableHttp { url: String, headers: HashMap<String, String> },
}

#[async_trait]
pub trait McpClient: Send + Sync {
    async fn connect(&mut self) -> Result<(), McpError>;
    async fn list_tools(&self) -> Result<Vec<Tool>, McpError>;
    async fn call_tool(&self, name: &str, args: serde_json::Value) -> Result<ToolResult, McpError>;
    async fn disconnect(&mut self) -> Result<(), McpError>;
    fn server_info(&self) -> &ServerInfo;
    fn transport(&self) -> &McpTransportConfig;
}

// Implementations:
// - StdioMcpClient: spawns process, communicates via stdin/stdout (JSON-RPC)
// - SseMcpClient: connects to SSE endpoint (long-lived HTTP)
// - StreamableHttpMcpClient: new MCP Streamable HTTP transport
```

---

## 5. Registry Manager (`src/registry/manager.rs`)

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RegistryEntry {
    pub id: String,                    // "github-official"
    pub name: String,                  // "GitHub (Official)"
    pub tier: QualityTier,             // Verified | Community | Experimental
    pub transport: McpTransportConfig,
    pub capabilities: Vec<String>,     // ["repo_read", "issue_write", "code_search"]
    pub referral: Option<ReferralInfo>, // { type: "oauth_app", client_id: "...", signup_url: "..." }
    pub last_audit: Option<String>,    // ISO date
    pub auto_start: bool,              // Connect on app launch
}

pub struct RegistryManager {
    entries: HashMap<String, RegistryEntry>,
    clients: HashMap<String, Box<dyn McpClient>>,
    builtin_path: PathBuf,             // registry_builtin.json (signed)
    user_path: PathBuf,                // registry_user.json
}

impl RegistryManager {
    pub async fn load() -> Self {
        // 1. Load builtin (verified, signed)
        // 2. Load user custom (merged, user wins on conflict)
        // 3. Validate signatures on builtin
    }

    pub async fn connect_all(&mut self) -> Vec<ConnectionResult> {
        // Connect to all `auto_start: true` servers
        // Return results for UI status badges
    }

    pub fn get_tool_set(&self) -> ToolSet {
        // Aggregate tools from all connected clients
        // Handle name collisions: prefix with server_id (github__create_issue)
    }
}
```

---

## 6. Sandbox: Native Execution (Not WASM)

**TypingMind:** Pyodide (WASM) — no `numpy`, no `playwright`, slow.
**AgentOS:** Real process jail via `bwrap` (bubblewrap) / `firejail` / Windows Job Objects.

```rust
// src/sandbox/manager.rs
#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum SandboxBackend {
    LocalJail { profile: SandboxProfile },      // Default: bwrap/firejail
    MicroVm { image: String },                  // Opt-in: gVisor/Firecracker
    Container { image: String, volumes: Vec<Mount> }, // If Docker present
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SandboxProfile {
    pub allow_network: bool,                    // Default: false
    pub allow_fs_read: Vec<PathBuf>,            // Project folder only
    pub allow_fs_write: Vec<PathBuf>,           // .artifacts/ folder only
    pub max_cpu_secs: u32,                      // 30
    pub max_ram_mb: u32,                        // 512
    pub env_whitelist: Vec<String>,             // ["PATH", "HOME", "GITHUB_TOKEN"]
}

#[async_trait]
pub trait Sandbox: Send + Sync {
    async fn execute(&self, lang: Language, code: String, files: Vec<FileInput>) -> Result<ExecutionResult, SandboxError>;
    async fn install_package(&self, lang: Language, pkg: String) -> Result<(), SandboxError>;
    async fn snapshot(&self) -> Result<SandboxState, SandboxError>; // For "Time Travel" debugging
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum Language { Python, Node, Deno, Bun, Rust, Bash, Sql }

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ExecutionResult {
    pub stdout: String,
    pub stderr: String,
    pub exit_code: i32,
    pub duration_ms: u64,
    pub artifacts: Vec<ArtifactOutput>, // Files written to /workspace
}
```

**Why this beats TypingMind:**
- `pip install torch`, `playwright install chromium`, `cargo build` — **real dependencies**
- Git integration: sandbox **has git** → agent can `clone`, `commit`, `push` (via GitHub MCP token)
- Persistence: sandbox state survives across chat turns (optional)

---

## 7. GitHub & Perplexity: The "Killer Integrations"

### GitHub MCP Server (Tier 1: Verified + Referral)
- **Fork:** `github/github-mcp-server` → Add our OAuth App `client_id`
- **Referral Mechanism:** OAuth App Manifest → User installs → We get `installation_id` → Track usage → GitHub Partner credits
- **Tools:** `create_issue`, `create_pr`, `search_code`, `read_file`, `write_file`, `run_workflow`
- **Install Flow:** User clicks "Connect GitHub" → OAuth → Token in Keychain → MCP Server spawns → Tools appear in chat

### Perplexity MCP Server (Tier 1: Verified + Affiliate)
- **If Official API:** Wrap their REST API
- **If No API:** Controlled browser automation (Playwright in Sandbox) — **only if user provides session**
- **Referral:** `?ref=agentos` on signup links generated by tool
- **Tools:** `search`, `deep_research`, `ask_followup`

### Manus: No API Yet → Placeholder + Alternative
- **Option A (Browser Automation):** User pastes cookies → Sandbox runs Playwright → Drives Manus UI. **Fragile, security risk.**
- **Option B (Placeholder):** `manus-mcp` stub: "Manus API not public. Join waitlist: [link]."
- **Option C (Alternative - RECOMMENDED):** Integrate **OpenHands / SWE-agent / AutoGen** via MCP **today**. These ARE open-source Manus equivalents. Run in our Sandbox.
- **Decision:** **Option C + Option B.** OpenHands gives users real autonomous coding agents now. Manus support arrives free when API launches.

---

## 8. Tool Calling Loop (Agent Side)

```rust
// In Provider stream_chat implementation
async fn stream_chat_with_tools(&self, model: &Model, prompt: AssembledPrompt, params: GenerationParams, tool_set: &ToolSet) {
    loop {
        let stream = self.raw_stream_chat(model, prompt.clone(), params.clone()).await?;
        let mut tool_calls = Vec::new();
        
        for await chunk in stream {
            if let Some(tc) = chunk.tool_calls { tool_calls.extend(tc); }
            yield chunk; // Forward to frontend
            
            if chunk.finish_reason == Some("tool_calls") {
                // Execute tools
                for call in tool_calls {
                    let result = tool_set.call(&call.name, call.arguments).await?;
                    prompt.messages.push(ApiMessage::tool_result(call.id, result));
                }
                // Continue loop with tool results injected
            } else {
                break; // Done
            }
        }
    }
}
```

---

## 9. Referral Integration in Registry Schema

```sql
-- ADD to providers/tools table
ALTER TABLE mcp_servers ADD COLUMN referral_type TEXT CHECK (referral_type IN ('oauth_app', 'api_key_suffix', 'signup_url', 'none'));
ALTER TABLE mcp_servers ADD COLUMN referral_payload TEXT; -- JSON: { "oauth_client_id": "xxx", "signup_url": "..." }
ALTER TABLE mcp_servers ADD COLUMN quality_tier TEXT CHECK (quality_tier IN ('verified', 'community', 'experimental')) DEFAULT 'experimental';
ALTER TABLE mcp_servers ADD COLUMN last_audit_date INTEGER;
```

---

## 10. Strategic Decision: MCP-First Means No WASM Plugin System

**We do not build a WASM plugin runtime.** 
- All tools → MCP servers (stdio for local, SSE/HTTP for remote)
- Sandbox → Native code execution (Python/Node/Rust)
- This is a **hard architectural boundary**. No Pyodide, no QuickJS, no Wasmtime for plugins.

---

> **Accepted as Canonical.** Implementation proceeds in `src/mcp/`, `src/sandbox/`, `src/registry/`.