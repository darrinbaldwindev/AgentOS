# Session 003: Context Assembly Pipeline (The "Continuity Engine")
**Project:** AgentOS | **Component:** `context-assembler` (Rust Sidecar Core)
**Date:** 2026-08-20
**Status:** ✅ Completed — Algorithm Spec v1.0, Ready for Implementation

---

## 1. Core Problem: "Context ≠ History"

Raw history is noise. **Context is a curated, token-budgeted prompt prefix.**
Pipeline: `Raw History → Semantic Chunks → Budget Allocation → Prompt Construction`.

---

## 2. Data Structures (Rust)

```rust
// src/context/assembler.rs
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize)]
pub struct AssembledPrompt {
    pub system: String,                          // Fully rendered system prompt
    pub messages: Vec<ApiMessage>,               // OpenAI/Anthropic compatible
    pub token_estimate: TokenBudget,             // Breakdown for UI "Context Bar"
    pub warnings: Vec<ContextWarning>,           // "Truncated 12 messages", "RAG hit low score"
}

#[derive(Debug, Clone, Deserialize)]
pub struct AssemblyRequest {
    pub thread_id: ULID,
    pub project_id: ULID,
    pub user_message: UserMessageInput,
    pub overrides: Option<AssemblyOverrides>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ContextConfig {
    pub max_context_tokens: u32,                 // e.g., 100,000
    pub reserved_output_tokens: u32,             // e.g., 8,192
    pub system_prompt_reserve_pct: f32,          // 0.10 (10%)
    pub weight_recent: f32,                      // 0.50
    pub weight_summary: f32,                     // 0.20
    pub weight_rag: f32,                         // 0.20
    pub weight_artifacts: f32,                   // 0.10
    pub rag_enabled: bool,
    pub rag_top_k: usize,
    pub rag_min_score: f32,
    pub rag_chunk_tokens: u32,
    pub max_pinned_artifacts: usize,             // 5
    pub artifact_token_limit: u32,               // 2,000 per artifact
    pub summarize_threshold: u32,                // Trigger at 50 msgs
    pub summary_model_id: Option<String>,        // Cheap model (Haiku, 8B local)
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct TokenBudget {
    pub total_limit: u32,
    pub reserved_output: u32,
    pub available_for_context: u32,
    pub allocated: BudgetAllocation,
    pub used: BudgetAllocation,
    pub remaining: i32,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct BudgetAllocation {
    pub system: u32, pub recent: u32, pub summary: u32,
    pub rag: u32, pub artifacts: u32, pub user_input: u32,
}

#[derive(Debug, Clone, Serialize)]
pub enum ContextWarning {
    Truncated { section: String, dropped_tokens: u32, dropped_count: usize },
    RagLowRelevance { query: String, best_score: f32 },
    ArtifactTooLarge { artifact_id: ULID, tokens: u32, limit: u32 },
    SystemPromptOverflow { tokens: u32, limit: u32 },
}
```

---

## 3. Assembly Algorithm (Deterministic Steps)

```rust
impl ContextAssembler {
    pub async fn assemble(&self, req: AssemblyRequest) -> Result<AssembledPrompt, AssemblerError> {
        // STEP 0: Load config & model limits
        let config = self.load_project_config(req.project_id).await?;
        let model_limits = self.get_model_limits(req.overrides.model_id).await?;
        let hard_limit = model_limits.context_window.min(config.max_context_tokens);
        let output_reserve = config.reserved_output_tokens.min(model_limits.max_output);
        let context_budget = hard_limit.saturating_sub(output_reserve);

        // STEP 1: Render System Prompt (Highest Priority)
        let system_prompt = self.render_system_prompt(req.project_id, &config).await?;
        let system_tokens = self.tokenizer.count(&system_prompt);
        if system_tokens > (context_budget as f32 * 0.5) as u32 {
            return Err(AssemblerError::SystemPromptTooLarge(system_tokens));
        }

        // STEP 2: Fetch Raw History (Recent Window)
        let (recent_msgs, older_exist) = self.fetch_recent_window(
            req.thread_id,
            (context_budget as f32 * config.weight_recent) as u32,
            config.summarize_threshold
        ).await?;

        // STEP 3: Rolling Summary (Background/Async)
        let summary_block = if older_exist {
            self.get_or_generate_summary(req.thread_id, &config).await?
        } else { None };

        // STEP 4: RAG Retrieval (Parallel)
        let rag_chunks = if config.rag_enabled {
            self.retrieve_rag_chunks(
                &req.user_message.text, req.project_id,
                config.rag_top_k, config.rag_min_score,
                (context_budget as f32 * config.weight_rag) as u32
            ).await?
        } else { vec![] };

        // STEP 5: Pinned Artifacts / File Refs
        let artifact_blocks = self.resolve_artifacts(
            &req.user_message, req.project_id,
            config.max_pinned_artifacts, config.artifact_token_limit
        ).await?;

        // STEP 6: Token Accounting & Greedy Packing
        // Priority: System(100) > User_Input(99) > Recent(90) > Artifacts(80) > RAG(70) > Summary(60)
        let mut chunks = vec![
            Chunk { content: system_prompt, tokens: system_tokens, priority: 100, source: "system" },
            Chunk { content: req.user_message.to_api_format(), tokens: user_tokens, priority: 99, source: "user" },
        ];
        chunks.extend(recent_msgs.into_iter().map(|m| Chunk::from_msg(m, 90)));
        chunks.extend(artifact_blocks.into_iter().map(|a| Chunk::from_artifact(a, 80)));
        chunks.extend(rag_chunks.into_iter().map(|r| Chunk::from_rag(r, 70)));
        if let Some(s) = summary_block { chunks.push(Chunk::from_summary(s, 60)); }

        // THE PACKER (Priority-ordered knapsack)
        let (packed_chunks, warnings) = self.pack_into_budget(chunks, context_budget, &config);

        // STEP 7: Final Formatting
        let api_messages = self.format_for_provider(packed_chunks, req.overrides.provider_hint);

        Ok(AssembledPrompt {
            system: system_prompt,
            messages: api_messages,
            token_estimate: self.calculate_final_budget(&packed_chunks, context_budget),
            warnings,
        })
    }
}
```

---

## 4. Critical Sub-Systems

### A. Tokenizer Abstraction (Model-Aware)
```rust
#[async_trait]
pub trait Tokenizer: Send + Sync {
    fn count(&self, text: &str) -> u32;
    fn count_messages(&self, msgs: &[ApiMessage]) -> u32;
    fn truncate(&self, text: &str, max_tokens: u32) -> String;
}
// Implementations: Tiktoken (cl100k_base, o200k_base), AnthropicTokenizer, GemmaTokenizer, QwenTokenizer
```

### B. Rolling Summarization (Background Job)
- **Trigger:** `thread.message_count % summarize_threshold == 0` (e.g., every 20 messages)
- **Process:** Send messages `[summary_cutoff .. latest - recent_window]` to **Cheap Summarizer Model** (`summary_model_id`)
- **Prompt:** *"Summarize focusing on: Decisions made, Code artifacts produced, Open questions, User preferences revealed. Output < 500 tokens."*
- **Store:** `threads.summary_text` + `threads.summary_token_estimate`

### C. RAG Injection Format (Standardized)
```markdown
<!-- RAG_CONTEXT_START: project_docs (score: 0.87) -->
**Source:** `src/db/schema.sql` (Lines 45-120)
**Relevance:** 0.87
**Content:**
```sql
CREATE TABLE messages (...);
```
<!-- RAG_CONTEXT_END -->
```
*Models understand XML/Markdown delimiters. Includes citation metadata for frontend "Sources" panel.*

### D. Anthropic Prompt Caching Support
```rust
if provider == "anthropic" && chunk.tokens > 1024 {
    // Inject `cache_control: { "type": "ephemeral" }` on System Prompt & Large RAG blocks
    // Requires `anthropic-beta: prompt-caching-2024-07-31` header
}
```

---

## 5. Frontend UX: The "Context Budget Bar"

```tsx
<div class="budget-bar">
  <div class="segments">
    <Segment color="purple" width={pct(budget.allocated.system)} title="System Prompt" />
    <Segment color="blue" width={pct(budget.allocated.recent)} title="Recent Chat" />
    <Segment color="green" width={pct(budget.allocated.rag)} title="Knowledge Base" />
    <Segment color="orange" width={pct(budget.allocated.artifacts)} title="Pinned Files" />
    <Segment color="gray" width={pct(budget.allocated.summary)} title="Summary" />
    <Segment color="red" width={pct(budget.used.user_input)} title="Your Message" />
  </div>
  <div class="meta">
    {budget.remaining > 0 
      ? `🟢 ${budget.remaining.toLocaleString()} tokens free` 
      : `🔴 ${(-budget.remaining).toLocaleString()} tokens over (auto-truncated)`
    }
    {warnings.map(w => <Toast key={w} variant="warning">{w.message}</Toast>)}
  </div>
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/context/assembler.rs`.