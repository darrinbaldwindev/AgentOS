# Session 001: Foundation & Architecture
**Project:** AgentOS (Codename: Continuum)
**Date:** 2026-08-20
**Participants:** Human (Owner), architect-prime (Coordinator)
**Status:** ✅ Completed — Canonical Decisions Recorded

---

## 1. Product Vision

**One-Liner:** *The universal frontend for AI agents that remembers everything, routes tasks to the optimal model (API or Local), and pays for itself via smart referral routing.*

**Core Problem:** Users juggle ChatGPT, Claude, Cursor, Perplexity, local LLMs (Ollama/LM Studio), and API keys. They lose context when switching, overpay for tokens, and don't know which model is best for a specific task.

**Target Personas:**
1. **Power Users / Devs** — Model routing, local privacy, prompt versioning, API key management
2. **Agencies / Consultants** — Client separation, billing tracking, "best model for job" automation
3. **AI Enthusiasts** — Try new models (Groq, Together, Local) without 10 browser tabs

---

## 2. Core Architecture: The Continuity Engine

### A. Universal Context Protocol (UCP)
- **Data Model:** `Project` → `Threads` → `Messages` → `Artifacts` (Code, Files, Images, Structured Data/JSON)
- **Vectorization:** Auto-embed every message/artifact into local vector DB (LanceDB, Chroma, SQLite-Vec) for RAG over own history
- **Context Window Management:** Rolling Summary + Recent Raw + Relevant RAG hits
- **User-facing:** Context Budget Bar (tokens/cost) per request

### B. Agent/Assistant Definition Layer
- **System Prompts as Code:** Version controlled (Git-like), templated (Jinja2/Liquid), parameterized (`{{user_name}}`, `{{project_goal}}`)
- **Tool/Function Registry:** Define tools once (MCP servers, OpenAPI specs, custom Python/JS functions), attach to any Agent
- **Model Routing Rules (Optimization Layer):**
  - `IF task == "coding" AND budget == "low" → Route to DeepSeek-Coder (Local) OR Groq Llama3`
  - `IF task == "legal_analysis" → Route to Claude 3.5 Sonnet (API)`

---

## 3. Polyglot Integration Layer

| Provider Type | Examples | Integration Strategy |
|---|---|---|
| **Cloud APIs** | OpenAI, Anthropic, Google, Mistral, Groq, Together, Fireworks, Cohere | Standardized OpenAI-compatible interface + Native SDKs for unique features (Anthropic Prompt Caching, OpenAI Structured Outputs) |
| **Local Inference** | Ollama, LM Studio, Jan, llama.cpp, KoboldCPP | Auto-detect running local servers. Manage model downloads. GPU/Metal/ROCm detection for hardware acceleration badges |
| **Agentic Runtimes** | LangGraph, AutoGen, CrewAI, Pydantic-AI | "Import Agent": Paste GitHub URL → Read requirements → Spin up Docker → Expose as internal tool |

**Unified Streaming:** SSE/WebSockets from backend → every provider feels like native streaming chat.

---

## 4. Referral & Optimization Engine (Monetization)

### A. Model Marketplace View
- Task Benchmarks: "Python Refactoring: DeepSeek-V3 (API) = $0.02/1k tokens, 92% quality | Local Llama 3.1 70b = Free, 88% quality | GPT-4o = $0.15, 95% quality"
- Historical Spend Tracking: "You spent $14.20 on coding last month. Switching 50% to Local/Referral saves ~$8/mo"

### B. Referral Integration Logic
1. **Affiliate Link Manager:** Secure vault for ref links (OpenRouter, Together, Groq, Venice, etc.)
2. **Smart Router "Referral Mode":** User toggles "Optimize for Cost/Referral". Router prefers referral providers when latency/quality parity exists.
3. **Transparency:** Show user: *"Routed via Groq (Your referral link applied - supports dev). Latency: 120ms."*
4. **Referral Analytics Dashboard:** Clicks, Sign-ups, Credits Earned, Estimated $ Value

### C. "Optimized for [Provider]" Badges
- Pre-built System Prompts tuned for specific model quirks (Claude prefers XML tags, Gemini needs strict JSON schema, Llama 3 needs specific chat template)
- Auto-apply when user selects that provider

---

## 5. Tech Stack Decisions (ACCEPTED)

| Layer | Decision | Rationale |
|---|---|---|
| **Frontend** | **Tauri v2 (Rust + Svelte 5)** | Small binary, native OS access (GPU, FS, Keychain), mobile support coming strong. Better than Electron for local LLM binary bundling. |
| **Backend (Sidecar)** | **Rust (Axum/Actix) or Go** | Runs inside Tauri sidecar. Handles streaming, local vector DB, Ollama management, secure key storage (OS Keychain), MCP server hosting. |
| **Local Vector DB** | **LanceDB** or **SQLite-Vec** | Embedded, zero-config, fast enough for personal knowledge bases. |
| **Agent Runtime** | **Pydantic-AI** (Python) or **Rig** (Rust) | Type-safe, model-agnostic, great tool support. Run Python via `pyo3` in Rust sidecar or as microservice. |
| **State/Config** | **SQLite (sqlx / rusqlite)** | Single file, portable, backs up with the project folder. |
| **Settings/Secrets** | **OS Keychain/Keytar** | Never store API keys in plain text SQLite. |

---

## 6. MVP Scope (v0.1 - Walk Phase)

**Must Haves:**
1. Multi-Provider Chat: OpenAI, Anthropic, Ollama, OpenRouter (100+ models + referral links natively)
2. Project/Thread Hierarchy: Sidebar with nested folders
3. Persistent System Prompts: Per-project & Global
4. Local RAG: "Index this folder" → Chat with codebase/docs
5. Cost Tracker: Input/Output tokens × current pricing = Estimated Cost per message/project
6. Export/Import: Portable `.agentproj` file (SQLite + Manifest)

**Killer Feature v0.2: Model Roulette / A/B Testing**
- Send same prompt to 3 models side-by-side. Compare latency, cost, quality. Save winner as "Default for Coding".

---

## 7. Go-to-Market & Growth Loops

1. **BYOK + Local First:** "Your data never leaves your machine unless you click 'Cloud'."
2. **Open Source Core:** Context Engine + Provider Abstraction as MIT/Apache 2.0. Monetize Pro UI / Cloud Sync / Referral Optimizer / Team Features.
3. **Content Marketing:** "How I cut my AI bill 80% using Local Models + Smart Routing" (case study using app).
4. **Affiliate Arbitrage:** Referral credits → Give users "Free Credits" inside app for milestones (e.g., "Index 1GB of docs → Get $5 OpenRouter credit via my link").

---

## 8. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| Model API Changes (Breaking) | Abstract heavily. Use `vercel/ai` provider adapters. Automated integration tests nightly. |
| Context Window Explosion | Hard token limits per project tier. Aggressive Summarization Agent. "Context Pruning" UI. |
| Local LLM Support Hell | Support **Ollama only for v1**. It standardizes the chaos. Add LM Studio/Jan later via OpenAI-compat API. |
| Referral Terms of Service | **Read fine print.** Some forbid "incentivized installs" or automated routing for profit. Frame as *"User Choice: 'Route via my preferred provider'"* not *"We auto-route for kickbacks."* |
| Binary Size | Tauri sidecar downloads `llama.cpp` / `ollama` binary on first run (opt-in), don't bundle 4GB in installer. |

---

## 9. Strategic Forks Requiring Owner Decision

| Fork | Options | Current Lean | Notes |
|---|---|---|---|
| **Frontend Framework** | React + TS vs **Svelte 5 + TS** vs SolidJS | **Svelte 5** | Best DX for Tauri. Tiny bundles, compiled reactivity, `shadcn-svelte` exists. |
| **Referral Ethics** | A: Transparent Smart Router (Default ON) vs **B: Explicit Opt-In per Provider** vs C: Referral Marketplace Tab | **B** | Safest legal. User must enable: `[ ] Route via Referral Partners`. Router ignores referral codes unless ON. |
| **Sync / Multi-Device** | **Pure Local v1** (SQLite file in user folder) vs CRDT/Yjs vs ElectricSQL/Supabase vs Custom Cloud | **Pure Local v1** | "Quality Connections" + "Sandbox" + "MCP" + "Router" is huge scope. Sync is separate product. Escape hatch: user puts SQLite in iCloud/OneDrive/Syncthing. |

---

## 10. Next Actions (Recorded for Continuity)

1. ✅ Session 002: Database Schema Design (DDL, Rust/TS types, migrations)
2. ✅ Session 003: Context Assembly Pipeline (Algorithm, Tokenizer, Summarization, RAG injection)
3. ✅ Session 004: Provider Abstraction Layer (Trait, implementations, registry)
4. ✅ Session 005: Routing Engine Algorithm (Heuristic scoring, task classification, referral bonus)
4. ✅ Session 006: Tauri IPC Contract (specta + ts-bindgen, streaming commands)
5. ✅ Session 007: Local LLM Management (Ollama detection, hardware profiling, quantization)
6. ✅ Session 008: MCP-First Tools & Sandbox (MCP client, native sandbox, GitHub/Perplexity integration)
7. ✅ Session 009: AI Coordination Kit Adoption (Charter, Ledger, Researcher role, Task 001)
8. 🟡 **Pilot Exchange:** Researcher verifying 5 Tier-1 affiliate programs (in progress)
9. ⏳ Session 010: MCP Core & Registry Implementation
10. ⏳ Session 011: Sandbox Execution Engine
11. ⏳ Session 012: GitHub/Perplexity MCP Servers + Agent Loop

---

> **Note:** This session establishes the canonical foundation. All subsequent sessions reference these decisions. Changes require new session entry with Owner approval.