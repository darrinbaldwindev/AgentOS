# Session 019: Voice Interface (Local-First)
**Project:** AgentOS | **Component:** `voice/interface` (Rust Sidecar + whisper.cpp + piper)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Stack

| Component | Technology | Why |
|-----------|------------|-----|
| **STT** | `whisper.cpp` (quantized models) | Local, fast, 99% accuracy, 100+ languages |
| **TTS** | `piper` (ONNX voices) | Local, natural, multi-lang, low latency |
| **Wake Word** | `porcupine` (Picovoice) | "Hey AgentOS" — offline, custom keywords |
| **VAD** | `silero-vad` | Voice activity detection, low CPU |

---

## 2. Architecture

```rust
// src/voice/interface.rs
use serde::{Serialize, Deserialize};
use specta::Type;
use tokio::sync::mpsc;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct VoiceConfig {
    pub stt_model: String,           // "base.en", "small.en", "medium.en"
    pub tts_voice: String,           // "en_US-lessac-medium", "en_GB-northern_english_male"
    pub wake_word: String,           // "hey_agentos" (custom .ppn file)
    pub vad_threshold: f32,          // 0.5
    pub sample_rate: u32,            // 16000
    pub push_to_talk: bool,          // Alternative to wake word
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum VoiceEvent {
    WakeWordDetected,
    ListeningStarted,
    PartialTranscript { text: String },
    TranscriptComplete { text: String, confidence: f32 },
    TTSStarted,
    TTSCompleted,
    Error { message: String },
}

pub struct VoiceInterface {
    config: VoiceConfig,
    stt: WhisperCpp,
    tts: Piper,
    wake_word: Porcupine,
    vad: SileroVAD,
    audio_input: AudioInputStream,
    event_tx: mpsc::Sender<VoiceEvent>,
}

impl VoiceInterface {
    pub async fn new(config: VoiceConfig, event_tx: mpsc::Sender<VoiceEvent>) -> Result<Self> {
        let stt = WhisperCpp::new(&config.stt_model)?;
        let tts = Piper::new(&config.tts_voice)?;
        let wake_word = Porcupine::new("hey_agentos.ppn")?;
        let vad = SileroVAD::new(config.vad_threshold)?;
        let audio_input = AudioInputStream::new(config.sample_rate)?;
        
        Ok(Self { config, stt, tts, wake_word, vad, audio_input, event_tx })
    }
    
    pub async fn run(&mut self) -> Result<()> {
        if self.config.push_to_talk {
            self.run_push_to_talk().await
        } else {
            self.run_wake_word().await
        }
    }
    
    async fn run_wake_word(&mut self) -> Result<()> {
        loop {
            // 1. Listen for wake word (always on, low CPU)
            self.wake_word.wait_for_wake_word().await?;
            self.event_tx.send(VoiceEvent::WakeWordDetected).await?;
            
            // 2. Record with VAD
            let audio = self.record_with_vad().await?;
            self.event_tx.send(VoiceEvent::ListeningStarted).await?;
            
            // 3. Transcribe
            let transcript = self.stt.transcribe(&audio).await?;
            self.event_tx.send(VoiceEvent::TranscriptComplete { 
                text: transcript.text, 
                confidence: transcript.confidence 
            }).await?;
            
            // 4. Send to AgentOS chat
            self.send_to_chat(transcript.text).await?;
        }
    }
    
    async fn record_with_vad(&mut self) -> Result<Vec<f32>> {
        let mut buffer = Vec::new();
        let mut silence_frames = 0;
        const MAX_SILENCE_FRAMES: u32 = 30; // ~1.5s at 16kHz
        
        loop {
            let frame = self.audio_input.next_frame().await?;
            let is_speech = self.vad.is_speech(&frame)?;
            
            if is_speech {
                buffer.extend_from_slice(&frame);
                silence_frames = 0;
            } else {
                silence_frames += 1;
                if silence_frames > MAX_SILENCE_FRAMES && !buffer.is_empty() {
                    break;
                }
            }
        }
        Ok(buffer)
    }
    
    async fn send_to_chat(&self, text: String) -> Result<()> {
        // Send via IPC to create thread/message
        // Could use a channel or direct IPC call
    }
}
```

---

## 3. STT: whisper.cpp Integration

```rust
// src/voice/whisper.rs
pub struct WhisperCpp {
    ctx: whisper_rs::WhisperContext,
    params: whisper_rs::WhisperFullParams,
}

impl WhisperCpp {
    pub fn new(model_name: &str) -> Result<Self> {
        let model_path = Self::resolve_model_path(model_name)?;
        let ctx = whisper_rs::WhisperContext::new(&model_path)?;
        let mut params = whisper_rs::WhisperFullParams::new(whisper_rs::SamplingStrategy::Greedy { best_of: 1 });
        params.set_language(Some("en"));
        params.set_translate(false);
        params.set_print_progress(false);
        params.set_print_realtime(false);
        params.set_print_timestamps(false);
        
        Ok(Self { ctx, params })
    }
    
    pub async fn transcribe(&mut self, audio: &[f32]) -> Result<Transcript> {
        let state = self.ctx.create_state()?;
        state.full(self.params, audio)?;
        
        let num_segments = state.full_n_segments()?;
        let mut text = String::new();
        let mut total_confidence = 0.0;
        
        for i in 0..num_segments {
            text.push_str(&state.full_get_segment_text(i)?);
            total_confidence += state.full_get_segment_avg_logprob(i)? as f32;
        }
        
        Ok(Transcript {
            text: text.trim().to_string(),
            confidence: (total_confidence / num_segments as f32).exp().min(1.0),
        })
    }
}

#[derive(Debug, Clone)]
pub struct Transcript {
    pub text: String,
    pub confidence: f32,
}
```

---

## 4. TTS: Piper Integration

```rust
// src/voice/piper.rs
pub struct Piper {
    voice: piper_rs::PiperVoice,
    config: piper_rs::PiperConfig,
}

impl Piper {
    pub fn new(voice_name: &str) -> Result<Self> {
        let voice_path = Self::resolve_voice_path(voice_name)?;
        let voice = piper_rs::PiperVoice::load(&voice_path)?;
        let config = piper_rs::PiperConfig {
            length_scale: 1.0,
            noise_scale: 0.667,
            noise_w: 0.8,
            sentence_silence: 0.2,
        };
        Ok(Self { voice, config })
    }
    
    pub async fn synthesize(&self, text: &str) -> Result<Vec<f32>> {
        let audio = self.voice.synthesize(text, self.config)?;
        Ok(audio)
    }
    
    pub async fn synthesize_streaming(&self, text: &str, tx: mpsc::Sender<Vec<f32>>) -> Result<()> {
        // Stream audio chunks for real-time playback
        self.voice.synthesize_streaming(text, self.config, |chunk| {
            tx.blocking_send(chunk).ok();
        })?;
        Ok(())
    }
}
```

---

## 5. Audio Playback (cpal)

```rust
// src/voice/playback.rs
use cpal::{Stream, StreamConfig, SampleRate};

pub struct AudioPlayer {
    stream: Stream,
    sample_rate: u32,
}

impl AudioPlayer {
    pub fn new() -> Result<Self> {
        let host = cpal::default_host();
        let device = host.default_output_device().ok_or("No output device")?;
        let config = StreamConfig {
            channels: 1,
            sample_rate: SampleRate(16000),
            buffer_size: cpal::BufferSize::Default,
        };
        
        let stream = device.build_output_stream(
            &config,
            |data: &mut [f32], _| {
                // Fill from queue
            },
            |err| eprintln!("Audio error: {}", err),
            None
        )?;
        
        stream.play()?;
        Ok(Self { stream, sample_rate: 16000 })
    }
    
    pub fn play(&self, audio: &[f32]) -> Result<()> {
        // Queue audio for playback
    }
    
    pub fn play_streaming(&self, rx: mpsc::Receiver<Vec<f32>>) -> Result<()> {
        // Stream from Piper directly to output
    }
}
```

---

## 6. Frontend (Svelte 5)

```svelte
<!-- VoiceInterface.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let state = $state<'idle' | 'wake_word' | 'listening' | 'processing' | 'speaking'>('idle');
  let transcript = $state('');
  let partial = $state('');
  let config = $state<VoiceConfig>();
  let availableVoices = $state<string[]>([]);
  let availableModels = $state<string[]>([]);
  
  async function loadConfig() {
    config = await invoke('get_voice_config', {});
    availableVoices = await invoke('list_piper_voices', {});
    availableModels = await invoke('list_whisper_models', {});
  }
  
  async function toggleListening() {
    if (state === 'idle' || state === 'wake_word') {
      await invoke('voice_start_listening', { pushToTalk: true });
      state = 'listening';
    } else {
      await invoke('voice_stop_listening', {});
      state = 'idle';
    }
  }
  
  // Event listener from backend
  onMount(() => {
    const unlisten = await invoke('on_voice_event', { handler: handleVoiceEvent });
    return unlisten;
  });
  
  function handleVoiceEvent(event: VoiceEvent) {
    switch (event.type) {
      case 'WakeWordDetected': state = 'listening'; break;
      case 'ListeningStarted': state = 'listening'; break;
      case 'PartialTranscript': partial = event.text; break;
      case 'TranscriptComplete': 
        transcript = event.text;
        partial = '';
        state = 'processing';
        break;
      case 'TTSStarted': state = 'speaking'; break;
      case 'TTSCompleted': state = 'idle'; break;
      case 'Error': notify(event.message); state = 'idle'; break;
    }
  }
</script>

<div class="voice-interface">
  <div class="voice-orb" class:active={state !== 'idle'} class:state={state}>
    <span class="icon">
      {#if state === 'wake_word'}👂{/if}
      {#if state === 'listening'}🎙️{/if}
      {#if state === 'processing'}⚙️{/if}
      {#if state === 'speaking'}🔊{/if}
      {#if state === 'idle'}💤{/if}
    </span>
  </div>
  
  <div class="transcript">
    {#if partial}
      <span class="partial">{partial}▊</span>
    {:else if transcript}
      <span class="final">{transcript}</span>
    {:else}
      <span class="hint">{state === 'idle' ? 'Say "Hey AgentOS" or click to start' : state}</span>
    {/if}
  </div>
  
  <div class="controls">
    <button onclick={toggleListening} class={state !== 'idle' ? 'active' : ''}>
      {state !== 'idle' ? 'Stop' : 'Push to Talk'}
    </button>
    
    <select bind:value={config?.tts_voice}>
      {#each availableVoices as v}
        <option value={v}>{v}</option>
      {/each}
    </select>
    
    <select bind:value={config?.stt_model}>
      {#each availableModels as m}
        <option value={m}>{m}</option>
      {/each}
    </select>
  </div>
</div>
```

---

## 7. IPC Commands

```rust
// src/ipc/voice_commands.rs
#[command]
pub async fn get_voice_config(state: State<'_, AppState>) -> Result<VoiceConfig, AppError> {
    Ok(state.voice_interface.config.clone())
}

#[command]
pub async fn update_voice_config(state: State<'_, AppState>, config: VoiceConfig) -> Result<(), AppError> {
    state.voice_interface.update_config(config).await
}

#[command]
pub async fn voice_start_listening(state: State<'_, AppState>, push_to_talk: bool) -> Result<(), AppError> {
    state.voice_interface.start_listening(push_to_talk).await
}

#[command]
pub async fn voice_stop_listening(state: State<'_, AppState>) -> Result<(), AppError> {
    state.voice_interface.stop_listening().await
}

#[command]
pub async fn list_whisper_models() -> Result<Vec<String>, AppError> {
    Ok(vec!["tiny.en", "base.en", "small.en", "medium.en", "large-v3".to_string()])
}

#[command]
pub async fn list_piper_voices() -> Result<Vec<String>, AppError> {
    // Scan piper voices directory
    Ok(vec!["en_US-lessac-medium", "en_US-libritts_r-medium", "en_GB-northern_english_male".to_string()])
}

// Event channel for voice events
#[command]
pub async fn on_voice_event(
    state: State<'_, AppState>,
    channel: Channel<VoiceEvent>
) -> Result<(), AppError> {
    let mut rx = state.voice_interface.event_tx.subscribe();
    tauri::async_runtime::spawn(async move {
        while let Some(event) = rx.recv().await {
            channel.send(event).ok();
        }
    });
    Ok(())
}
```

---

## 8. Model/Voice Management

```rust
// Auto-download models/voices on first use
async fn ensure_model(model: &str) -> Result<PathBuf> {
    let cache_dir = dirs::cache_dir().unwrap().join("agentos/whisper");
    let path = cache_dir.join(format!("ggml-{}.bin", model));
    
    if !path.exists() {
        let url = format!("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-{}.bin", model);
        download_with_progress(url, &path).await?;
    }
    Ok(path)
}

async fn ensure_voice(voice: &str) -> Result<PathBuf> {
    let cache_dir = dirs::cache_dir().unwrap().join("agentos/piper");
    let path = cache_dir.join(format!("{}.onnx", voice));
    
    if !path.exists() {
        let url = format!("https://github.com/rhasspy/piper/releases/download/v1.2.0/{}.onnx", voice);
        download_with_progress(url, &path).await?;
        // Also download .json config
    }
    Ok(path)
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/voice/`.