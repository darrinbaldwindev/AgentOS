# Session 013: Agent Loop Runtime (ReAct / Plan-Execute)
**Project:** AgentOS | **Component:** `agent/runtime` (Rust Sidecar)
**Date:** 2026-08-20
**Status:** 🟡 Spec Complete — Ready for Implementation (Depends on Session 010 + 011 + 012)

---

## 1. Why Build Our Own Agent Loop?

- **OpenHands/SWE-agent** are great but heavy (Docker, Python, specific frameworks)
- **We need:** Lightweight, embedded in Rust sidecar, uses *our* MCP tools, *our* sandbox, *our* router
- **Control:** Step budgeting, cost tracking, referral routing, context assembly per step
- **Integration:** Native Tauri IPC streaming, artifact handling, git operations

---

## 2. Architecture: Plan-Execute with ReAct Fallback

```
┌─────────────────────────────────────────────────────────────┐
│                      AGENT RUNTIME                          │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────────┐  │
│  │  PLANNER    │───▶│  EXECUTOR   │───▶│   VERIFIER      │  │
│  │  (Model)    │    │  (Model)    │    │  (Model/Tool)   │  │
│  └─────────────┘    └─────────────┘    └─────────────────┘  │
│        │                  │                   │              │
│        ▼                  ▼                   ▼              │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              TOOL SET (MCP + Sandbox)                │   │
│  │  github__create_pr  │  sandbox__python  │  web_search │   │
│  └─────────────────────────────────────────────────────┘   │
│        │                  │                   │              │
│        └──────────────────┴───────────────────┘              │
│                           ▼                                  │
│              ┌───────────────────────┐                       │
│              │   CONTEXT ASSEMBLER   │  (Per-step context)  │
│              └───────────────────────┘                       │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Core Types

```rust
// src/agent/runtime.rs
use serde::{Serialize, Deserialize};
use specta::Type;
use crate::mcp::ToolSet;
use crate::sandbox::Sandbox;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct AgentConfig {
    pub planner_model_id: ULID,           // High-reasoning model (Sonnet, GPT-4o)
    pub executor_model_id: ULID,          // Fast, good at tool use (Haiku, Llama 3.1 70B)
    pub verifier_model_id: Option<ULID>,  // Optional: cheaper model for verification
    pub max_steps: u32,                   // 10-20
    pub max_cost_usd: f64,                // Hard limit per run
    pub step_timeout_secs: u64,           // 60
    pub require_verification: bool,       // true for coding tasks
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct AgentTask {
    pub id: ULID,
    pub project_id: ULID,
    pub thread_id: ULID,
    pub objective: String,                // "Fix failing tests in /workspace/auth"
    pub context: AgentContext,            // Files, repo state, previous attempts
    pub config: AgentConfig,
    pub created_at: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct AgentContext {
    pub working_dir: String,
    pub repo_url: Option<String>,
    pub pinned_files: Vec<String>,        // Paths relative to working_dir
    pub environment: HashMap<String, String>,
    pub previous_plan: Option<Plan>,
    pub previous_results: Vec<StepResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct Plan {
    pub steps: Vec<PlanStep>,
    pub reasoning: String,
    pub estimated_cost_usd: f64,
    pub estimated_steps: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct PlanStep {
    pub id: u32,
    pub description: String,
    pub tool: Option<String>,             // namespaced tool name or "sandbox"
    pub input_schema: serde_json::Value,  // Expected input
    pub success_criteria: String,         // How to verify
    pub rollback: Option<String>,         // If fails
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct StepResult {
    pub step_id: u32,
    pub action: AgentAction,
    pub output: ToolResult,               // From MCP tool or sandbox
    pub cost_usd: f64,
    pub latency_ms: u64,
    pub success: bool,
    pub verification: Option<VerificationResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum AgentAction {
    ToolCall { name: String, args: serde_json::Value },
    SandboxExec { language: Language, code: String },
    Think { reasoning: String },
    AskUser { question: String, options: Vec<String> },
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct VerificationResult {
    pub passed: bool,
    pub evidence: String,
    pub suggestions: Vec<String>,
}
```

---

## 4. Planner (Generates Plan)

```rust
// src/agent/planner.rs
pub struct Planner {
    model: Model,
    tool_set: ToolSet,
    config: AgentConfig,
}

impl Planner {
    pub async fn create_plan(&self, task: &AgentTask) -> Result<Plan, AgentError> {
        let system_prompt = r#"
You are a senior software engineer creating an execution plan.
Available tools: {tool_descriptions}
Sandbox languages: Python, Node, Rust, Bash, SQL
Constraints: {max_steps} steps max, ${max_cost_usd} budget

Output JSON:
{
  "steps": [
    {"id": 1, "description": "...", "tool": "github__search_code", "input_schema": {...}, "success_criteria": "...", "rollback": "..."},
    {"id": 2, "description": "...", "tool": "sandbox", "input_schema": {"language": "Python", "code": "..."}, "success_criteria": "..."}
  ],
  "reasoning": "...",
  "estimated_cost_usd": 0.05,
  "estimated_steps": 3
}
"#;
        
        let prompt = format!("Task: {}\nContext: {}", task.objective, serde_json::to_string(&task.context)?);
        let response = self.model.complete_once(system_prompt, prompt).await?;
        parse_plan_response(response)
    }
}
```

---

## 5. Executor (Runs Steps)

```rust
// src/agent/executor.rs
pub struct Executor {
    model: Model,
    tool_set: ToolSet,
    sandbox: Arc<dyn Sandbox>,
    registry: Arc<RegistryManager>,
    config: AgentConfig,
}

impl Executor {
    pub async fn execute_step(&mut self, step: &PlanStep, context: &mut AgentContext) -> Result<StepResult, AgentError> {
        let start = Instant::now();
        
        match &step.tool {
            Some(tool_name) if tool_name.starts_with("sandbox") => {
                // Sandbox execution
                let args: SandboxArgs = serde_json::from_value(step.input_schema.clone())?;
                let result = self.sandbox.execute(args.language, args.code, args.files).await?;
                StepResult { ... }
            }
            Some(tool_name) => {
                // MCP tool call
                let result = self.registry.call_tool(tool_name, step.input_schema.clone()).await?;
                StepResult { ... }
            }
            None => {
                // Think step - just reasoning
                StepResult { action: AgentAction::Think { reasoning: step.description }, ... }
            }
        }
    }
}
```

---

## 6. Verifier (Validates Step Success)

```rust
// src/agent/verifier.rs
pub struct Verifier {
    model: Option<Model>,
    sandbox: Arc<dyn Sandbox>,
}

impl Verifier {
    pub async fn verify(&self, step: &PlanStep, result: &StepResult, context: &AgentContext) -> Result<VerificationResult, AgentError> {
        if let Some(model) = &self.model {
            // LLM-based verification
            let prompt = format!(
                "Step: {}\nExpected: {}\nActual Output: {}\nVerify success criteria met. Output JSON: {{\"passed\": bool, \"evidence\": \"...\", \"suggestions\": []}}",
                step.description, step.success_criteria, serde_json::to_string(&result.output)?
            );
            model.complete_once(prompt).await
        } else {
            // Heuristic verification (exit_code == 0, output contains expected strings)
            Ok(VerificationResult {
                passed: result.output.exit_code == 0,
                evidence: format!("Exit code: {}", result.output.exit_code),
                suggestions: vec![],
            })
        }
    }
}
```

---

## 7. Main Agent Loop

```rust
// src/agent/runtime.rs
pub struct AgentRuntime {
    planner: Planner,
    executor: Executor,
    verifier: Verifier,
    config: AgentConfig,
    db: SqlitePool,          // For persistence
    event_tx: broadcast::Sender<AgentEvent>, // For streaming to frontend
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum AgentEvent {
    PlanCreated { plan: Plan },
    StepStarted { step: PlanStep },
    StepCompleted { result: StepResult },
    StepVerified { verification: VerificationResult },
    StepFailed { error: String, rollback: Option<String> },
    CostUpdate { total_usd: f64 },
    Completed { success: bool, summary: String },
    Paused { reason: String }, // Waiting for user input
}

impl AgentRuntime {
    pub async fn run(&mut self, task: AgentTask) -> Result<AgentRunResult, AgentError> {
        // 1. Create Plan
        let plan = self.planner.create_plan(&task).await?;
        self.emit(AgentEvent::PlanCreated { plan: plan.clone() }).await;
        
        let mut context = task.context;
        let mut total_cost = 0.0;
        let mut step_results = Vec::new();
        
        // 2. Execute Steps
        for step in plan.steps {
            if total_cost > self.config.max_cost_usd {
                return Err(AgentError::BudgetExceeded);
            }
            
            self.emit(AgentEvent::StepStarted { step: step.clone() }).await;
            
            let mut result = self.executor.execute_step(&step, &mut context).await?;
            total_cost += result.cost_usd;
            
            // 3. Verify
            if self.config.require_verification {
                let verification = self.verifier.verify(&step, &result, &context).await?;
                result.verification = Some(verification.clone());
                self.emit(AgentEvent::StepVerified { verification }).await;
                
                if !verification.passed {
                    // Rollback or retry
                    if let Some(rollback) = step.rollback {
                        self.execute_rollback(&rollback, &context).await?;
                    }
                    self.emit(AgentEvent::StepFailed { error: "Verification failed".into(), rollback: step.rollback }).await;
                    // Decide: retry, skip, or abort
                }
            }
            
            step_results.push(result.clone());
            self.emit(AgentEvent::StepCompleted { result }).await;
            self.emit(AgentEvent::CostUpdate { total_usd: total_cost }).await;
            
            // Update context for next step
            context.previous_results.push(result);
        }
        
        // 4. Final Summary
        let summary = self.generate_summary(&step_results).await?;
        self.emit(AgentEvent::Completed { success: true, summary }).await;
        
        Ok(AgentRunResult { steps: step_results, total_cost, summary })
    }
}
```

---

## 8. Streaming to Frontend (Real-time)

```rust
// Tauri command returns Channel<AgentEvent>
#[command]
#[specta::type]
pub async fn run_agent(
    state: State<'_, AppState>,
    channel: Channel<AgentEvent>,
    task: AgentTask
) -> Result<AgentRunResult, AppError> {
    let mut runtime = AgentRuntime::new(
        state.agent_planner,
        state.agent_executor,
        state.agent_verifier,
        state.db.clone(),
    );
    
    // Subscribe to events
    let mut rx = runtime.event_tx.subscribe();
    tauri::async_runtime::spawn(async move {
        while let Ok(event) = rx.recv().await {
            channel.send(event).ok();
        }
    });
    
    runtime.run(task).await.map_err(AppError::Agent)
}
```

**Frontend:**
```svelte
<!-- AgentRunView.svelte -->
<script>
  let events = $state<AgentEvent[]>([]);
  let running = $state(false);
  
  async function run() {
    running = true;
    events = [];
    const channel = new Channel<AgentEvent>();
    channel.onmessage = (e) => events = [...events, e];
    channel.onclose = () => running = false;
    await invoke('run_agent', { channel, task });
  }
</script>

<div class="agent-run">
  {#each events as e}
    <AgentEventCard event={e} />
  {/each}
</div>
```

---

## 9. Specialized Agents (Pre-built Configs)

| Agent | Planner | Executor | Verifier | Use Case |
|---|---|---|---|---|
| **Code Fixer** | Sonnet | Haiku + Sandbox | Sonnet | Fix failing tests, lint errors |
| **Feature Builder** | GPT-4o | Llama 3.1 70B + Sandbox | GPT-4o | Implement spec from PRD |
| **Refactorer** | Sonnet | Haiku + Sandbox | None | Rename, extract, modernize |
| **Researcher** | Sonnet | Perplexity MCP + Sandbox | None | Deep research, comparison |
| **Reviewer** | Sonnet | GitHub MCP + Sandbox | Sonnet | PR review, security audit |

---

## 10. Integration with Referral Router

- **Planner** uses Router to pick models (cost-aware)
- **Executor** tracks per-step cost → `usage_events` with `task_type: "agent_step"`
- **Referral Bonus** applied per step → Total referral value in run summary
- **Budget Enforcement:** Hard stop at `max_cost_usd` (Session 005 Router + Session 003 Context)

---

> **Ready for Implementation.** Requires Sessions 010 (MCP), 011 (Sandbox), 012 (GitHub/Perplexity MCP) complete.