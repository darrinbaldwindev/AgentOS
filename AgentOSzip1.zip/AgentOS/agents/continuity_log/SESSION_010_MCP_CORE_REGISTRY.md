# Session 010: MCP Core & Registry Implementation
**Project:** AgentOS | **Components:** `mcp/client`, `registry/manager`, `ipc/mcp_commands`
**Date:** 2026-08-20
**Status:** 🟡 Spec Complete — Ready for Implementation (No Pilot Dependency)

---

## 1. MCP Transport Abstraction (`src/mcp/transport.rs`)

```rust
use async_trait::async_trait;
use rmcp::transport::{StdioTransport, SseTransport, StreamableHttpTransport};
use rmcp::{ServerInfo, Tool, ToolResult};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum McpTransportConfig {
    Stdio { 
        command: String, 
        args: Vec<String>, 
        env: HashMap<String, String>,
        working_dir: Option<String>,
    },
    Sse { 
        url: String, 
        headers: HashMap<String, String>,
        timeout_secs: u64,
    },
    StreamableHttp { 
        url: String, 
        headers: HashMap<String, String>,
        timeout_secs: u64,
    },
}

#[async_trait]
pub trait McpClient: Send + Sync + 'static {
    fn server_info(&self) -> &ServerInfo;
    fn transport_config(&self) -> &McpTransportConfig;
    
    async fn connect(&mut self) -> Result<(), McpError>;
    async fn is_connected(&self) -> bool;
    async fn list_tools(&self) -> Result<Vec<Tool>, McpError>;
    async fn call_tool(&self, name: &str, args: serde_json::Value) -> Result<ToolResult, McpError>;
    async fn disconnect(&mut self) -> Result<(), McpError>;
}

// Concrete Implementations:
pub struct StdioMcpClient { /* spawns process, stdin/stdout JSON-RPC */ }
pub struct SseMcpClient { /* HTTP SSE connection, long-lived */ }
pub struct StreamableHttpMcpClient { /* New MCP Streamable HTTP */ }
```

---

## 2. Tool Set Aggregator (`src/mcp/toolset.rs`)

```rust
use rmcp::Tool;
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct NamespacedTool {
    pub server_id: String,           // "github-official"
    pub original_name: String,       // "create_issue"
    pub namespaced_name: String,     // "github__create_issue"
    pub tool: Tool,                  // Full MCP tool schema
}

pub struct ToolSet {
    pub tools: Vec<NamespacedTool>,
    pub by_server: HashMap<String, Vec<NamespacedTool>>,
    pub by_name: HashMap<String, NamespacedTool>, // namespaced_name -> tool
}

impl ToolSet {
    pub fn new() -> Self { Self { tools: vec![], by_server: HashMap::new(), by_name: HashMap::new() } }
    
    pub fn merge(&mut self, server_id: &str, tools: Vec<Tool>) {
        for tool in tools {
            let namespaced = format!("{}__{}", server_id, tool.name);
            let nt = NamespacedTool { 
                server_id: server_id.to_string(), 
                original_name: tool.name.clone(), 
                namespaced_name: namespaced.clone(), 
                tool: tool.clone() 
            };
            self.tools.push(nt.clone());
            self.by_server.entry(server_id.to_string()).or_default().push(nt.clone());
            self.by_name.insert(namespaced, nt);
        }
    }
    
    pub fn to_llm_tools(&self) -> Vec<Tool> {
        // Convert to LLM format with namespaced names
        self.tools.iter().map(|nt| {
            let mut t = nt.tool.clone();
            t.name = nt.namespaced_name.clone();
            t.description = format!("[{}] {}", nt.server_id, t.description);
            t
        }).collect()
    }
    
    pub async fn call(&self, namespaced_name: &str, args: serde_json::Value, clients: &HashMap<String, Box<dyn McpClient>>) -> Result<ToolResult, McpError> {
        let nt = self.by_name.get(namespaced_name).ok_or(McpError::ToolNotFound)?;
        let client = clients.get(&nt.server_id).ok_or(McpError::ServerNotConnected)?;
        client.call_tool(&nt.original_name, args).await
    }
}
```

---

## 3. Registry Manager (`src/registry/manager.rs`)

```rust
use serde::{Serialize, Deserialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum QualityTier { Verified, Community, Experimental }

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct ReferralInfo {
    pub r#type: String,              // "oauth_app" | "api_key_suffix" | "signup_url" | "none"
    pub payload: serde_json::Value,  // { "client_id": "...", "signup_url": "..." }
    pub commission_details: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct RegistryEntry {
    pub id: String,                    // "github-official"
    pub name: String,                  // "GitHub (Official)"
    pub tier: QualityTier,
    pub transport: McpTransportConfig,
    pub capabilities: Vec<String>,     // ["repo_read", "issue_write", "code_search"]
    pub referral: Option<ReferralInfo>,
    pub last_audit: Option<String>,    // ISO date
    pub auto_start: bool,
    pub enabled: bool,
}

pub struct RegistryManager {
    entries: HashMap<String, RegistryEntry>,
    clients: HashMap<String, Box<dyn McpClient>>,
    tool_set: ToolSet,
    builtin_path: PathBuf,      // registry_builtin.json (signed, shipped with binary)
    user_path: PathBuf,         // registry_user.json (user additions)
    db: SqlitePool,             // For persisting connection status, last_audit, etc.
}

impl RegistryManager {
    pub async fn new(db: SqlitePool) -> Result<Self, RegistryError> {
        let mut mgr = Self { 
            entries: HashMap::new(), 
            clients: HashMap::new(), 
            tool_set: ToolSet::new(),
            builtin_path: PathBuf::from("registry_builtin.json"),
            user_path: PathBuf::from("registry_user.json"),
            db,
        };
        mgr.load_registries().await?;
        Ok(mgr)
    }
    
    async fn load_registries(&mut self) -> Result<(), RegistryError> {
        // 1. Load builtin (verified, signed) — fail if signature invalid
        // 2. Load user custom (merged, user wins on ID conflict)
        // 3. Validate each entry has required fields
    }
    
    pub async fn connect_all(&mut self) -> Vec<ConnectionResult> {
        let mut results = Vec::new();
        for (id, entry) in &self.entries {
            if entry.enabled && entry.auto_start {
                let result = self.connect_server(id).await;
                results.push(ConnectionResult { server_id: id.clone(), success: result.is_ok(), error: result.err().map(|e| e.to_string()) });
            }
        }
        self.rebuild_tool_set();
        results
    }
    
    async fn connect_server(&mut self, id: &str) -> Result<(), McpError> {
        let entry = self.entries.get(id).cloned().ok_or(McpError::ServerNotFound)?;
        let mut client: Box<dyn McpClient> = match &entry.transport {
            McpTransportConfig::Stdio { .. } => Box::new(StdioMcpClient::new(entry.transport.clone())),
            McpTransportConfig::Sse { .. } => Box::new(SseMcpClient::new(entry.transport.clone())),
            McpTransportConfig::StreamableHttp { .. } => Box::new(StreamableHttpMcpClient::new(entry.transport.clone())),
        };
        client.connect().await?;
        self.clients.insert(id.to_string(), client);
        Ok(())
    }
    
    fn rebuild_tool_set(&mut self) {
        self.tool_set = ToolSet::new();
        for (id, client) in &self.clients {
            if let Ok(tools) = client.list_tools().await {
                self.tool_set.merge(id, tools);
            }
        }
    }
    
    pub fn get_tool_set(&self) -> &ToolSet { &self.tool_set }
    pub fn get_entries(&self) -> Vec<RegistryEntry> { self.entries.values().cloned().collect() }
}
```

---

## 4. Builtin Registry (`registry_builtin.json` — Shipped with Binary)

```json
{
  "version": 1,
  "signature": "ed25519:...",  // Verified at load time
  "entries": [
    {
      "id": "github-official",
      "name": "GitHub (Official)",
      "tier": "verified",
      "transport": { "type": "stdio", "command": "npx", "args": ["-y", "@modelcontextprotocol/server-github"], "env": {} },
      "capabilities": ["repo_read", "issue_write", "pr_write", "code_search", "workflow_run"],
      "referral": { "type": "oauth_app", "payload": { "client_id": "AGENTOS_GITHUB_CLIENT_ID" }, "commission_details": "GitHub Partner Program credits" },
      "last_audit": "2026-08-20",
      "auto_start": false,
      "enabled": true
    },
    {
      "id": "perplexity-search",
      "name": "Perplexity Search",
      "tier": "verified",
      "transport": { "type": "stdio", "command": "npx", "args": ["-y", "@modelcontextprotocol/server-perplexity"], "env": {} },
      "capabilities": ["search", "deep_research", "ask_followup"],
      "referral": { "type": "signup_url", "payload": { "url": "https://perplexity.ai/signup?ref=AGENTOS_REF" }, "commission_details": "$10 Pro credits per referral" },
      "last_audit": "2026-08-20",
      "auto_start": false,
      "enabled": true
    },
    {
      "id": "filesystem-secure",
      "name": "Filesystem (Secure)",
      "tier": "verified",
      "transport": { "type": "stdio", "command": "npx", "args": ["-y", "@modelcontextprotocol/server-filesystem", "/workspace"], "env": {} },
      "capabilities": ["read_file", "write_file", "list_dir", "search"],
      "referral": { "type": "none", "payload": {} },
      "last_audit": "2026-08-20",
      "auto_start": true,
      "enabled": true
    },
    {
      "id": "sqlite-analyzer",
      "name": "SQLite Analyzer",
      "tier": "verified",
      "transport": { "type": "stdio", "command": "python", "args": ["-m", "mcp_sqlite_server", "--db-path", "/workspace/agentos.db"], "env": {} },
      "capabilities": ["query", "schema", "explain"],
      "referral": { "type": "none", "payload": {} },
      "last_audit": "2026-08-20",
      "auto_start": false,
      "enabled": true
    },
    {
      "id": "code-executor-python",
      "name": "Python Code Executor",
      "tier": "verified",
      "transport": { "type": "stdio", "command": "python", "args": ["-m", "mcp_python_executor"], "env": {} },
      "capabilities": ["execute", "install_package", "list_packages"],
      "referral": { "type": "none", "payload": {} },
      "last_audit": "2026-08-20",
      "auto_start": true,
      "enabled": true
    }
  ]
}
```

---

## 5. IPC Commands for MCP Management

```rust
// src/ipc/mcp_commands.rs
#[command]
#[specta::type]
pub async fn list_mcp_servers(state: State<'_, AppState>) -> Result<Vec<RegistryEntry>, AppError> {
    Ok(state.registry_manager.get_entries())
}

#[command]
#[specta::type]
pub async fn connect_mcp_server(state: State<'_, AppState>, server_id: String) -> Result<ConnectionResult, AppError> {
    state.registry_manager.connect_server(&server_id).await
}

#[command]
#[specta::type]
pub async fn disconnect_mcp_server(state: State<'_, AppState>, server_id: String) -> Result<(), AppError> {
    state.registry_manager.disconnect_server(&server_id).await
}

#[command]
#[specta::type]
pub async fn add_custom_mcp_server(state: State<'_, AppState>, entry: RegistryEntry) -> Result<(), AppError> {
    // Validate, add to user registry, persist to registry_user.json
    // If auto_start, connect immediately
}

#[command]
#[specta::type]
pub async fn call_mcp_tool(state: State<'_, AppState>, namespaced_name: String, args: serde_json::Value) -> Result<ToolResult, AppError> {
    state.registry_manager.get_tool_set().call(&namespaced_name, args, &state.registry_manager.clients).await
}

#[command]
#[specta::type]
pub async fn get_mcp_tool_set(state: State<'_, AppState>) -> Result<Vec<NamespacedTool>, AppError> {
    Ok(state.registry_manager.get_tool_set().tools.clone())
}
```

---

## 6. Frontend Integration (Svelte 5)

```svelte
<!-- MCPServerCard.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  import { onMount } from 'svelte';
  
  export let server: RegistryEntry;
  let status = $state<'connecting' | 'connected' | 'disconnected' | 'error'>('disconnected');
  let tools = $state<NamespacedTool[]>([]);
  
  async function connect() {
    status = 'connecting';
    const result = await invoke('connect_mcp_server', { serverId: server.id });
    status = result.success ? 'connected' : 'error';
    if (result.success) loadTools();
  }
  
  async function loadTools() {
    const allTools = await invoke('get_mcp_tool_set', {});
    tools = allTools.filter(t => t.server_id === server.id);
  }
  
  onMount(() => { if (server.auto_start) connect(); });
</script>

<div class="card" class:connected={status === 'connected'}>
  <div class="header">
    <span class="tier-badge {server.tier}">{server.tier}</span>
    <strong>{server.name}</strong>
    {#if server.referral?.type !== 'none'}
      <span class="referral-badge">🔗 Referral</span>
    {/if}
  </div>
  <div class="tools">
    {#each tools as tool}
      <span class="tool-tag">{tool.original_name}</span>
    {/each}
  </div>
  <button onclick={connect} disabled={status === 'connecting'}>
    {status === 'connected' ? 'Disconnect' : status === 'connecting' ? 'Connecting...' : 'Connect'}
  </button>
</div>
```

---

## 7. Security & Isolation

| Concern | Mitigation |
|---|---|
| **Supply Chain** | Builtin registry signed (Ed25519). User registry unsigned but local-only. |
| **Process Isolation** | Stdio servers run as child processes. Crash ≠ app crash. |
| **Network Access** | SSE/HTTP servers: configurable timeout, no auth in core (handled by server). |
| **File Access** | Filesystem servers: sandboxed to `/workspace` (project folder) via args. |
| **Env Secrets** | Only whitelisted env vars passed to stdio servers (`GITHUB_TOKEN`, etc.) |

---

> **Ready for Implementation.** No dependency on Researcher pilot. Can start immediately.