# Session 007: Local LLM Management (The "Local First" Ops)
**Project:** AgentOS | **Component:** `local/ollama_manager` (Rust Sidecar)
**Date:** 2026-08-20
**Status:** ✅ Completed — Operational Spec v1.0, Ollama Integration + Hardware Detection

---

## 1. Responsibilities

1. **Detection:** Is Ollama running? (`GET /api/version`). Version check.
2. **Model Sync:** `ollama list` → Upsert `models` table (prices=NULL, tags=["local"]).
3. **Model Pulling:** Streaming download progress → Frontend Progress Bar.
4. **Hardware Profiling:** VRAM/RAM detection → Auto-recommend Quantization (Q4_K_M, Q8_0, FP16).
5. **Lifecycle:** Start/Stop Ollama service (Tauri Sidecar manages binary? **Decision: Assume User Manages, App Detects.**)

---

## 2. Hardware Detection (`sysinfo` + `nvml-wrapper` / `metal`)

```rust
// src/local/ollama_manager.rs
use serde::{Serialize, Deserialize};
use specta::Type;

#[derive(Debug, Serialize, Deserialize, Type, Clone)]
pub struct HardwareProfile {
    pub total_ram_gb: f32,
    pub gpus: Vec<GpuInfo>,
    pub recommended_quant: String,        // "Q4_K_M", "Q8_0", "FP16"
    pub max_model_size_gb: f32,           // Safe limit for offloading
}

#[derive(Debug, Serialize, Deserialize, Type, Clone)]
pub struct GpuInfo {
    pub name: String,
    pub vram_gb: f32,
    pub backend: GpuBackend,              // CUDA | Metal | ROCm | Vulkan | CPU
    pub compute_capability: Option<String>, // e.g., "8.6" (RTX 3080)
}

#[derive(Debug, Serialize, Deserialize, Type, Clone, Copy, PartialEq, Eq)]
pub enum GpuBackend { Cuda, Metal, Rocm, Vulkan, Cpu }

impl OllamaManager {
    pub async fn detect_hardware() -> HardwareProfile {
        let sys = System::new_all();
        let ram = sys.total_memory() as f32 / (1024.0_f32.powi(3));
        
        let gpus = detect_gpus(); // Platform specific
        
        let (max_vram, backend) = gpus.iter()
            .max_by_key(|g| g.vram_gb as u32)
            .map(|g| (g.vram_gb, g.backend))
            .unwrap_or((0.0, GpuBackend::Cpu));

        // Heuristic: Offload all layers if model fits in VRAM + 2GB overhead
        // Else split layers (llama.cpp -ngl)
        let max_model_size = if max_vram > 0.0 { max_vram - 2.0 } else { ram * 0.6 };
        
        let recommended_quant = if max_model_size >= 40.0 { "FP16" }
            else if max_model_size >= 20.0 { "Q8_0" }
            else if max_model_size >= 10.0 { "Q5_K_M" }
            else if max_model_size >= 6.0 { "Q4_K_M" }
            else { "Q3_K_M" };

        HardwareProfile { total_ram_gb: ram, gpus, recommended_quant, max_model_size_gb: max_model_size.max(0.0) }
    }

    pub async fn pull_model(&self, model_name: &str, quant: Option<String>) -> Result<Channel<PullProgress>, Error> {
        let channel = Channel::new();
        let quant_suffix = quant.unwrap_or_else(|| self.hardware_profile.recommended_quant.clone());
        let full_name = format!("{}:{}", model_name, quant_suffix);
        
        tauri::async_runtime::spawn(async move {
            let client = reqwest::Client::new();
            let resp = client.post("http://localhost:11434/api/pull")
                .json(&json!({ "name": full_name, "stream": true }))
                .send().await?;
            
            let mut stream = resp.bytes_stream();
            while let Some(chunk) = stream.next().await {
                // Parse Ollama streaming JSON: { "status": "downloading", "completed": 1024, "total": 4000000000 }
                // Send progress to channel
            }
            channel.close();
        });
        
        Ok(channel)
    }
}
```

---

## 3. Platform-Specific GPU Detection

| Platform | Method | Crate |
|---|---|---|
| **Linux (NVIDIA)** | `nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv` | `nvml-wrapper` |
| **Linux (AMD/ROCm)** | `rocm-smi --showproductname --showmeminfo vram` | `rocm-smi` parsing |
| **macOS** | `system_profiler SPDisplaysDataType -json` | `std::process::Command` |
| **Windows** | `wmic path win32_VideoController get Name,AdapterRAM` | `wmi` crate |
| **Fallback** | CPU only | — |

```rust
fn detect_gpus() -> Vec<GpuInfo> {
    #[cfg(target_os = "linux")]
    { detect_linux_gpus() }
    #[cfg(target_os = "macos")]
    { detect_macos_gpus() }
    #[cfg(target_os = "windows")]
    { detect_windows_gpus() }
    #[cfg(not(any(target_os = "linux", target_os = "macos", target_os = "windows")))]
    { vec![] }
}
```

---

## 4. Model Sync & Discovery

```rust
// Runs on startup + "Refresh Models" click
pub async fn sync_local_models(&self) -> Result<Vec<Model>, Error> {
    let client = reqwest::Client::new();
    let resp = client.get("http://localhost:11434/api/tags").send().await?;
    let data: OllamaTagsResponse = resp.json().await?;
    
    let mut models = Vec::new();
    for model in data.models {
        // Parse name:tag → base_name, quant
        let (base_name, quant) = parse_name_tag(&model.name);
        let size_gb = model.size as f32 / (1024.0_f32.powi(3));
        
        models.push(Model {
            id: ULID::new(),
            provider_id: "01ARZ3NDEKTSV4RRFFQ69G5FAZ".to_string(), // Ollama provider ID
            api_name: model.name.clone(),
            display_name: format!("{} ({})", base_name, quant),
            context_window: 32768, // Default, override per known model
            max_output: 4096,
            input_price_usd: None,
            output_price_usd: None,
            quality_score: estimate_quality(&base_name, &quant),
            speed_score: estimate_speed(&base_name, &quant, size_gb),
            coding_score: estimate_coding(&base_name),
            tags_json: json!(["local", "free", "private", quant.to_lowercase()]).to_string(),
            local_size_gb: Some(size_gb),
            local_ram_gb: Some(size_gb * 1.2), // Rough KV cache estimate
            local_filename: Some(model.name),
            ..Default::default()
        });
    }
    
    // Upsert into DB (preserve user quality_score overrides)
    self.db.upsert_models(models).await
}
```

---

## 5. Quantization Recommendation Logic

| Model Size | VRAM Available | Recommended Quant | Reason |
|---|---|---|---|
| 7B | 8-12 GB | Q5_K_M / Q4_K_M | Fits in VRAM, good quality |
| 13B | 12-16 GB | Q5_K_M | Balanced |
| 32B | 24-32 GB | Q4_K_M / Q5_K_M | Fits in 24GB VRAM |
| 70B | 40-48 GB | Q4_K_M | Fits in 48GB VRAM (2x 24GB) |
| 70B | 16-24 GB | Q3_K_M / Q4_K_M (offload) | Partial GPU offload |
| Any | CPU Only | Q4_K_M (system RAM) | System RAM must be > model_size * 1.5 |

**Frontend UX:**
```tsx
<ModelCard>
  <Badge variant={isLocal ? "green" : "blue"}>Local</Badge>
  <QuantBadge quant={model.local_filename?.split(':').last()}>
  <HardwareMatch match={hardwareProfile.max_model_size_gb >= model.local_size_gb} />
  <PullButton onClick={() => pullModel(model.api_name, hardwareProfile.recommended_quant)} />
</ModelCard>
```

---

## 6. Ollama Lifecycle Management

**Decision: App does NOT manage Ollama process.** User installs/runs Ollama independently.
**App responsibilities:**
- Detect if running (`GET /api/version` with 2s timeout)
- Show status: 🟢 Running (v0.1.XX) | 🔴 Not Running
- "Start Ollama" button → `open -a Ollama` (macOS) / `ollama serve` (Linux/Win) / `Start-Process ollama` (Win)
- Auto-reconnect when Ollama starts (poll every 5s)

---

## 7. Integration with Router & Context

- Local models have `input_price_usd: NULL`, `output_price_usd: NULL` → Router treats as **Cost Score: 10**
- `provider_type: "local"` → Passes `PrivacyLevel::LocalOnly` filter automatically
- Hardware profile stored in `user_settings` → Used by Router for `max_latency_ms` estimates

---

> **Accepted as Canonical.** Implementation proceeds in `src/local/ollama_manager.rs`.