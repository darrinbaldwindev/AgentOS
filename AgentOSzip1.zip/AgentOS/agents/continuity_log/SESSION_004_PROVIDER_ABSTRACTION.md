# Session 004: Provider Abstraction Layer (The "Polyglot" Interface)
**Project:** AgentOS | **Component:** `providers` (Rust Sidecar)
**Date:** 2026-08-20
**Status:** ✅ Completed — Trait Design v1.0, Ready for Implementations

---

## 1. Core Trait (`src/providers/trait.rs`)

```rust
use async_trait::async_trait;
use futures::Stream;
use crate::context::AssembledPrompt;
use crate::db::Model;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StreamChunk {
    pub content: Option<String>,
    pub tool_calls: Option<Vec<ToolCallDelta>>,
    pub usage: Option<TokenUsage>,
    pub finish_reason: Option<String>,
    pub raw: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenUsage {
    pub prompt_tokens: u32,
    pub completion_tokens: u32,
    pub cache_read_tokens: Option<u32>,
    pub cache_write_tokens: Option<u32>,
    pub total_tokens: u32,
}

#[derive(Debug, thiserror::Error)]
pub enum ProviderError {
    #[error("Auth failed: {0}")] Auth(String),
    #[error("Rate limited: retry after {retry_after_secs}s")] RateLimited { retry_after_secs: u64 },
    #[error("Model not found: {0}")] ModelNotFound(String),
    #[error("Context length exceeded: {0}")] ContextOverflow(String),
    #[error("Upstream error: {code} - {message}")] Upstream { code: String, message: String },
    #[error("Stream closed unexpectedly")] StreamClosed,
    #[error("Invalid request: {0}")] InvalidRequest(String),
}

#[async_trait]
pub trait Provider: Send + Sync + 'static {
    fn id(&self) -> &str;
    fn name(&self) -> &str;
    fn capabilities(&self) -> ProviderCapabilities;
    async fn health_check(&self) -> Result<HealthStatus, ProviderError>;

    /// Main entry point: stream chat completion
    async fn stream_chat(
        &self,
        model: &Model,
        prompt: AssembledPrompt,
        params: GenerationParams
    ) -> Result<Pin<Box<dyn Stream<Item = Result<StreamChunk, ProviderError>> + Send>>, ProviderError>;

    /// Non-streaming (embeddings, classification, summarization)
    async fn complete_once(
        &self,
        model: &Model,
        prompt: AssembledPrompt,
        params: GenerationParams
    ) -> Result<CompletionResponse, ProviderError>;

    /// List models from provider (sync with DB)
    async fn fetch_models(&self) -> Result<Vec<RemoteModelInfo>, ProviderError>;

    /// Estimate cost using DB pricing snapshot
    fn estimate_cost(&self, model: &Model, usage: &TokenUsage) -> f64;
}
```

---

## 2. Generation Parameters (Unified)

```rust
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct GenerationParams {
    pub temperature: Option<f32>,
    pub top_p: Option<f32>,
    pub top_k: Option<u32>,
    pub max_tokens: Option<u32>,
    pub stop_sequences: Vec<String>,
    pub tools: Vec<ToolDefinition>,
    pub tool_choice: ToolChoice,
    pub response_format: Option<ResponseFormat>, // Text | JSON Schema | JSON Object
    pub seed: Option<u64>,
    pub user_id: Option<String>,
    pub provider_options: HashMap<String, serde_json::Value>, // Passthrough
}
```

---

## 3. Provider Implementations Strategy

| Provider | Auth | Streaming Format | Special Handling |
|---|---|---|---|
| **OpenAI** | Bearer | SSE (`data: {...}`) | Tool calling native, `logprobs`, `structured_outputs`, Prompt Caching (auto) |
| **Anthropic** | Bearer (x-api-key) | SSE (Events: `message_start`, `content_block_delta`) | **System Prompt separate param**, `cache_control` headers, Tool Use format diff, Thinking blocks (beta) |
| **Ollama** | None | SSE (`{ "message": {...}, "done": true }`) | `/api/chat` & `/api/generate`. Local model management (pull/delete). GPU detection via `nvidia-smi`/`system_profiler`. |
| **OpenRouter** | Bearer | OpenAI Compatible | **Model Routing Header** (`HTTP-Referer`, `X-Title`), Auto-fallback, Shows `provider` in response metadata |
| **Groq** | Bearer | OpenAI Compatible | **Extreme Speed**. Low context (8k-128k). No vision (yet). Tool calling varies by model. |
| **Gemini** | Bearer / OAuth | SSE (Custom) | `system_instruction` separate, `cachedContent` for explicit caching, Safety Settings mandatory |

---

## 4. Factory & Registry (`src/providers/registry.rs`)

```rust
pub struct ProviderRegistry {
    providers: HashMap<String, Arc<dyn Provider>>,
    db: SqlitePool,
}

impl ProviderRegistry {
    pub async fn new(db: SqlitePool) -> Self {
        let mut reg = Self { providers: HashMap::new(), db };
        reg.register(Arc::new(OpenAIProvider::new()));
        reg.register(Arc::new(AnthropicProvider::new()));
        reg.register(Arc::new(OllamaProvider::new())); // Auto-detects localhost:11434
        reg.register(Arc::new(OpenRouterProvider::new()));
        reg.register(Arc::new(GroqProvider::new()));
        reg.hydrate_keys_from_keychain().await; // Load API keys from OS Keychain
        reg
    }

    pub fn get(&self, provider_id: &str) -> Option<Arc<dyn Provider>> {
        self.providers.get(provider_id).cloned()
    }

    pub async fn get_for_model(&self, model_id: &str) -> Result<Arc<dyn Provider>, ProviderError> {
        // 1. Check cache (model_id -> provider_id)
        // 2. Query DB: SELECT provider_id FROM models WHERE id = ?
        // 3. Return provider
    }
}
```

---

## 5. Key Implementation Details

### OpenAI Provider
- Uses `reqwest` + `tokio-stream` for SSE parsing
- Handles `tool_calls` accumulation across chunks
- Supports `response_format: { type: "json_schema", json_schema: {...} }` for Structured Outputs
- Automatic retry with exponential backoff on 429/5xx

### Anthropic Provider
- **Critical:** System prompt sent as top-level `system` parameter, not in `messages`
- **Prompt Caching:** Inject `cache_control: { type: "ephemeral" }` on system prompt & large RAG blocks (>1024 tokens)
- **Tool Use:** Different format — `tool_use` blocks in content array
- **Beta Headers:** `anthropic-beta: prompt-caching-2024-07-31`, `tools-2024-04-04`

### Ollama Provider
- **Auto-discovery:** `GET /api/tags` on startup → upsert local models into DB
- **Model Pulling:** Stream `POST /api/pull` progress → Frontend progress bar
- **Hardware Detection:** `nvidia-smi`, `system_profiler SPDisplaysDataType` → recommend quantization
- **GPU Offload:** `-ngl` layers based on VRAM (see Session 007)

### OpenRouter Provider
- **Headers:** `HTTP-Referer: https://agentos.local`, `X-Title: AgentOS`
- **Model Routing:** Pass `model: "openrouter/auto"` for auto-fallback
- **Referral:** Appends `?ref=AGENTOS_REF` to signup URLs in registry

---

## 6. Health Checks & Model Sync

```rust
// Runs on startup + every 5 min
async fn health_check_all(&self) -> Vec<HealthStatus> {
    futures::future::join_all(
        self.providers.values().map(|p| p.health_check())
    ).await
}

// Sync models from provider → DB (runs daily + on "Refresh Models" click)
async fn sync_models(&self, provider_id: &str) -> Result<Vec<Model>, ProviderError> {
    let provider = self.get(provider_id)?;
    let remote_models = provider.fetch_models().await?;
    // Upsert into DB with pricing, capabilities, tags
    // Preserve local `referral_code`, `quality_score` overrides
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/providers/`.