# Session 018: Browser Extension (Acquisition Channel)
**Project:** AgentOS | **Component:** `extension/browser` (WebExtension MV3 + Native Messaging)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Capabilities

| Trigger | Action |
|---------|--------|
| **Right-click selection** | "Send to AgentOS" → new thread with selected text + page URL + DOM context |
| **Toolbar click** | Quick capture: screenshot + visible text → new thread |
| **Keyboard shortcut** | `Alt+Shift+A` → floating input → send to AgentOS |
| **Code blocks** | Detect `<pre><code>` → offer "Explain this" / "Refactor this" / "Write tests" |

---

## 2. Manifest (MV3)

```json
{
  "name": "AgentOS Companion",
  "version": "1.0.0",
  "manifest_version": 3,
  "description": "Send web content to AgentOS for analysis, coding, research",
  "permissions": [
    "activeTab",
    "contextMenus",
    "scripting",
    "storage",
    "nativeMessaging",
    "tabs"
  ],
  "host_permissions": ["<all_urls>"],
  "background": {
    "service_worker": "background.js",
    "type": "module"
  },
  "content_scripts": [{
    "matches": ["<all_urls>"],
    "js": ["content.js"],
    "css": ["content.css"],
    "run_at": "document_idle"
  }],
  "commands": {
    "send-to-agentos": {
      "suggested_key": { "default": "Alt+Shift+A" },
      "description": "Send selection to AgentOS"
    }
  },
  "icons": {
    "16": "icons/icon16.png",
    "48": "icons/icon48.png",
    "128": "icons/icon128.png"
  }
}
```

---

## 3. Native Messaging Host (Rust Sidecar)

```rust
// src/extension/native_messaging.rs
use serde::{Serialize, Deserialize};
use std::io::{stdin, stdout, Read, Write};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum ExtensionMessage {
    SendContext { payload: ContextPayload },
    Ping,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ContextPayload {
    pub url: String,
    pub title: String,
    pub selection: Option<String>,
    pub dom_snapshot: Option<String>,  // Simplified DOM
    pub screenshot: Option<String>,    // Base64 PNG
    pub code_blocks: Vec<CodeBlock>,
    pub timestamp: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeBlock {
    pub language: Option<String>,
    pub code: String,
    pub selector: String,
}

pub struct NativeMessagingHost {
    tx: mpsc::Sender<ExtensionCommand>,
}

impl NativeMessagingHost {
    pub fn new(tx: mpsc::Sender<ExtensionCommand>) -> Self {
        Self { tx }
    }
    
    pub fn run(&self) {
        let mut stdin = stdin();
        let mut stdout = stdout();
        let mut buffer = [0u8; 4];
        
        loop {
            // Read 4-byte length prefix (native messaging protocol)
            if stdin.read_exact(&mut buffer).is_err() { break; }
            let length = u32::from_ne_bytes(buffer) as usize;
            
            let mut msg_buf = vec![0u8; length];
            if stdin.read_exact(&mut msg_buf).is_err() { break; }
            
            let msg: ExtensionMessage = match serde_json::from_slice(&msg_buf) {
                Ok(m) => m,
                Err(_) => continue,
            };
            
            match msg {
                ExtensionMessage::SendContext { payload } => {
                    self.tx.blocking_send(ExtensionCommand::CreateThreadFromContext(payload)).ok();
                }
                ExtensionMessage::Ping => {
                    self.send_response(ExtensionResponse::Pong).ok();
                }
            }
        }
    }
    
    fn send_response(&self, resp: ExtensionResponse) -> Result<()> {
        let json = serde_json::to_vec(&resp)?;
        let len = (json.len() as u32).to_ne_bytes();
        stdout().write_all(&len)?;
        stdout().write_all(&json)?;
        stdout().flush()?;
        Ok(())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum ExtensionCommand {
    CreateThreadFromContext { payload: ContextPayload },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum ExtensionResponse {
    Pong,
    ThreadCreated { thread_id: String, url: String },
    Error { message: String },
}
```

---

## 4. Tauri Integration (Native Messaging Manifest)

```json
// Native messaging manifest (installed by Tauri)
{
  "name": "com.agentos.native_messaging",
  "description": "AgentOS Browser Extension Host",
  "path": "agentos-native-host",
  "type": "stdio",
  "allowed_origins": [
    "chrome-extension://<EXTENSION_ID>/"
  ]
}
```

```rust
// Tauri command to install native messaging host
#[command]
pub async fn install_native_messaging_host() -> Result<(), AppError> {
    let manifest = NativeMessagingManifest {
        name: "com.agentos.native_messaging",
        description: "AgentOS Browser Extension Host",
        path: std::env::current_exe()?.to_string_lossy().to_string(),
        type_: "stdio",
        allowed_origins: vec!["chrome-extension://*".to_string()],
    };
    
    // Write to OS-specific location:
    // macOS: ~/Library/Application Support/Google/Chrome/NativeMessagingHosts/
    // Linux: ~/.config/google-chrome/NativeMessagingHosts/
    // Windows: HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\
    
    Ok(())
}
```

---

## 5. Content Script (Content Capture)

```javascript
// content.js
class AgentOSContentCapture {
  constructor() {
    this.observer = new MutationObserver(() => this.updateCodeBlocks());
    this.observe();
  }
  
  getSelectionContext() {
    const selection = window.getSelection();
    if (!selection.rangeCount) return null;
    
    const range = selection.getRangeAt(0);
    const text = selection.toString().trim();
    if (!text) return null;
    
    // Get surrounding context (parent elements)
    const container = range.commonAncestorContainer;
    const domSnapshot = this.simplifyDOM(container, 3);
    
    return {
      text,
      url: window.location.href,
      title: document.title,
      domSnapshot,
      codeBlocks: this.extractCodeBlocks(),
      timestamp: Date.now()
    };
  }
  
  extractCodeBlocks() {
    return Array.from(document.querySelectorAll('pre code')).map(el => ({
      language: el.className.match(/language-(\w+)/)?.[1],
      code: el.textContent,
      selector: this.getSelector(el)
    }));
  }
  
  simplifyDOM(node, depth = 3) {
    if (depth <= 0 || node.nodeType === Node.TEXT_NODE) {
      return node.textContent?.substring(0, 5000);
    }
    if (node.nodeType !== Node.ELEMENT_NODE) return '';
    
    const tag = node.tagName.toLowerCase();
    const attrs = Array.from(node.attributes)
      .filter(a => ['id', 'class', 'href', 'src'].includes(a.name))
      .map(a => `${a.name}="${a.value}"`)
      .join(' ');
    
    const children = Array.from(node.childNodes)
      .map(c => this.simplifyDOM(c, depth - 1))
      .join('');
    
    return `<${tag} ${attrs}>${children}</${tag}>`;
  }
}

// Listen for messages from background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_CONTEXT') {
    sendResponse(capture.getSelectionContext());
  }
});
```

---

## 6. Background Script

```javascript
// background.js (ES Module)
import { NativeMessaging } from './native-messaging.js';

const native = new NativeMessaging('com.agentos.native_messaging');

// Context menu
chrome.contextMenus.create({
  id: 'send-to-agentos',
  title: 'Send to AgentOS',
  contexts: ['selection', 'page', 'link']
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'send-to-agentos') {
    const context = await captureFromTab(tab.id);
    await native.send({ type: 'SendContext', payload: context });
  }
});

// Keyboard shortcut
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'send-to-agentos') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const context = await captureFromTab(tab.id);
    await native.send({ type: 'SendContext', payload: context });
  }
});

async function captureFromTab(tabId) {
  return chrome.scripting.executeScript({
    target: { tabId },
    func: () => window.AgentOSContentCapture.getSelectionContext()
  });
}
```

---

## 7. Frontend: Thread Creation from Extension

```rust
// src/ipc/extension_commands.rs
#[command]
#[specta::type]
pub async fn create_thread_from_extension(
    state: State<'_, AppState>,
    payload: ExtensionContextPayload
) -> Result<Thread, AppError> {
    // 1. Create new thread in default project
    // 2. Add user message with captured context
    // 3. Auto-route based on content (code → coding, docs → research)
    // 4. Return thread for UI to focus
    
    let project = state.db.get_default_project().await?;
    let thread = state.db.create_thread(project.id, "Extension Capture").await?;
    
    let message = UserMessageInput {
        text: format!("**Source:** {}\n\n**Selection:**\n{}", payload.url, payload.selection.unwrap_or_default()),
        files: payload.screenshot.map(|s| FileInput { 
            name: "screenshot.png".into(), 
            content: s, 
            mime_type: "image/png".into() 
        }).into_iter().collect(),
        artifact_refs: vec![],
    };
    
    let assembled = state.assembler.assemble(AssemblyRequest {
        thread_id: thread.id,
        project_id: project.id,
        user_message: message,
        overrides: None,
    }).await?;
    
    // Route and stream...
    Ok(thread)
}
```

---

## 7. Installation Flow

```svelte
<!-- ExtensionInstall.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let installed = $state(false);
  let browser = $state<'chrome' | 'firefox' | 'edge'>('chrome');
  
  async function checkInstallation() {
    installed = await invoke('check_extension_installed', { browser });
  }
  
  async function install() {
    // 1. Install native messaging host
    await invoke('install_native_messaging_host', {});
    // 2. Open extension store page
    await invoke('open_external_url', { 
      url: browser === 'chrome' 
        ? 'https://chrome.google.com/webstore/detail/agentos-companion/...'
        : 'https://addons.mozilla.org/firefox/addon/agentos-companion/'
    });
  }
  
  onMount(checkInstallation);
</script>

<div class="extension-install">
  <h3>AgentOS Browser Extension</h3>
  <p>Send any webpage content to AgentOS with right-click or Alt+Shift+A</p>
  
  <select bind:value={browser}>
    <option value="chrome">Chrome / Brave / Edge</option>
    <option value="firefox">Firefox</option>
  </select>
  
  {#if installed}
    <span class="success">✅ Extension installed and connected</span>
  {:else}
    <button class="btn-primary" onclick={install}>
      Install for {browser}
    </button>
  {/if}
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/extension/` + `extension/` (WebExtension).