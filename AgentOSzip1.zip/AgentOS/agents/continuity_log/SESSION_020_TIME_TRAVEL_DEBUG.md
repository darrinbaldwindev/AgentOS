# Session 020: Time Travel Debug (Sandbox Snapshots)
**Project:** AgentOS | **Component:** `sandbox/time_travel` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Core Concept

Built on Session 011 sandbox snapshots. Every sandbox execution creates a snapshot. Users can "rewind" to any previous state, modify, and replay forward.

---

## 2. Snapshot System (Extended from Session 011)

```rust
// src/sandbox/snapshots.rs
use serde::{Serialize, Deserialize};
use specta::Type;
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SandboxSnapshot {
    pub id: ULID,
    pub thread_id: ULID,
    pub step: u32,
    pub timestamp: i64,
    pub action: String,
    pub working_dir: String,
    pub env: HashMap<String, String>,
    pub installed_packages: HashMap<Language, Vec<String>>,
    pub git_status: Option<GitStatus>,
    pub filesystem_hash: String,
    pub artifact_outputs: Vec<ArtifactOutput>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct GitStatus {
    pub branch: String,
    pub commit: String,
    pub dirty: bool,
    pub staged_files: Vec<String>,
    pub unstaged_files: Vec<String>,
}

pub struct SnapshotManager {
    snapshots: Vec<SandboxSnapshot>,
    max_snapshots: usize,
    storage: SnapshotStorage,
}

impl SnapshotManager {
    pub fn new(max_snapshots: usize) -> Self {
        Self { snapshots: Vec::new(), max_snapshots, storage: SnapshotStorage::default() }
    }
    
    pub async fn create_snapshot(&mut self, sandbox: &dyn Sandbox, action: String) -> Result<SandboxSnapshot> {
        let state = sandbox.snapshot().await?;
        let snapshot = SandboxSnapshot {
            id: ULID::new(),
            thread_id: self.current_thread_id,
            step: self.snapshots.len() as u32 + 1,
            timestamp: now_ms(),
            action,
            working_dir: state.working_dir,
            env: state.env,
            installed_packages: state.installed_packages,
            git_status: state.git_status,
            filesystem_hash: self.hash_workspace().await?,
            artifact_outputs: state.artifacts,
        };
        
        self.snapshots.push(snapshot.clone());
        if self.snapshots.len() > self.max_snapshots {
            self.snapshots.remove(0);
        }
        self.storage.save(&snapshot).await?;
        Ok(snapshot)
    }
    
    pub async fn restore(&self, snapshot_id: ULID, sandbox: &mut dyn Sandbox) -> Result<()> {
        let snapshot = self.snapshots.iter().find(|s| s.id == snapshot_id).ok_or("Snapshot not found")?;
        sandbox.restore(snapshot.clone()).await?;
        Ok(())
    }
    
    pub fn get_history(&self) -> Vec<SandboxSnapshot> {
        self.snapshots.clone()
    }
}
```

---

## 3. Time Travel Operations

```rust
pub struct TimeTravelController {
    snapshots: SnapshotManager,
    sandbox: Box<dyn Sandbox>,
    current_index: Option<usize>,
}

impl TimeTravelController {
    pub async fn jump_to(&mut self, snapshot_id: ULID) -> Result<()> {
        let index = self.snapshots.snapshots.iter().position(|s| s.id == snapshot_id).ok_or("Snapshot not found")?;
        self.current_index = Some(index);
        self.snapshots.restore(snapshot_id, self.sandbox.as_mut()).await?;
        Ok(())
    }
    
    pub async fn jump_to_step(&mut self, step: u32) -> Result<()> {
        let snapshot = self.snapshots.snapshots.iter().find(|s| s.step == step).ok_or("Step not found")?;
        self.jump_to(snapshot.id).await
    }
    
    pub async fn rewind(&mut self, steps: u32) -> Result<()> {
        let current = self.current_index.unwrap_or(self.snapshots.snapshots.len());
        let target = current.saturating_sub(steps as usize);
        let snapshot = &self.snapshots.snapshots[target];
        self.jump_to(snapshot.id).await
    }
    
    pub async fn fork_from(&mut self, snapshot_id: ULID) -> Result<ULID> {
        let snapshot = self.snapshots.snapshots.iter().find(|s| s.id == snapshot_id).ok_or("Snapshot not found")?;
        self.snapshots.restore(snapshot_id, self.sandbox.as_mut()).await?;
        self.snapshots.snapshots.truncate(snapshot.step as usize);
        Ok(snapshot.id)
    }
    
    pub async fn diff(&self, from: ULID, to: ULID) -> Result<DiffResult> {
        let from_snap = self.snapshots.snapshots.iter().find(|s| s.id == from).ok_or("From not found")?;
        let to_snap = self.snapshots.snapshots.iter().find(|s| s.id == to).ok_or("To not found")?;
        DiffResult {
            filesystem_changed: from_snap.filesystem_hash != to_snap.filesystem_hash,
            git_changes: self.diff_git(from_snap.git_status, to_snap.git_status),
            package_changes: self.diff_packages(from_snap.installed_packages, to_snap.installed_packages),
            artifact_changes: self.diff_artifacts(from_snap.artifact_outputs, to_snap.artifact_outputs),
        }
    }
}
```

---

## 4. Frontend: Time Travel Slider

```svelte
<!-- TimeTravelSlider.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let history = $state<Snapshot[]>([]);
  let currentIndex = $state(0);
  let selectedSnapshot = $state<Snapshot | null>(null);
  let diff = $state<DiffResult | null>(null);
  
  async function load() {
    history = await invoke('get_sandbox_history', { threadId });
    if (history.length > 0) currentIndex = history.length - 1;
  }
  
  function jumpTo(index: number) {
    currentIndex = index;
    const snap = history[index];
    invoke('sandbox_jump_to', { snapshotId: snap.id });
  }
  
  function compareWithCurrent(index: number) {
    const from = history[index];
    const to = history[history.length - 1];
    diff = await invoke('sandbox_diff', { from: from.id, to: to.id });
    selectedSnapshot = from;
  }
  
  function forkFrom(index: number) {
    invoke('sandbox_fork', { snapshotId: history[index].id });
  }
</script>

<div class="time-travel">
  <div class="timeline">
    {#each history as snap, i}
      <button 
        class={i === currentIndex ? 'current' : ''} 
        class:selected={selectedSnapshot?.id === snap.id}
        onclick={() => jumpTo(i)}
        oncontextmenu={(e) => { e.preventDefault(); compareWithCurrent(i); }}
        title={snap.action}
      >
        <span class="step">Step {snap.step}</span>
        <span class="action">{snap.action}</span>
        <span class="time">{formatTime(snap.timestamp)}</span>
      </button>
    {/each}
  </div>
  
  <div class="controls">
    <button onclick={() => jumpTo(currentIndex - 1)} disabled={currentIndex === 0}>← Rewind</button>
    <span class="position">Step {currentIndex + 1} / {history.length}</span>
    <button onclick={() => jumpTo(currentIndex + 1)} disabled={currentIndex >= history.length - 1}>Forward →</button>
    <button onclick={() => forkFrom(currentIndex)} class="fork-btn">🍴 Fork Here</button>
  </div>
  
  {#if diff}
    <DiffPanel diff={diff} />
  {/if}
</div>
```

---

## 5. Diff Panel

```svelte
<!-- DiffPanel.svelte -->
<script lang="ts">
  export let diff: DiffResult;
</script>

<div class="diff-panel">
  <h4>Changes from Step {diff.from_step} → Current</h4>
  {#if diff.filesystem_changed}
    <div class="diff-item changed"><span class="label">📁 Filesystem</span><span class="value">Modified</span><button onclick={() => showFileDiff()}>View Diff</button></div>
  {/if}
  {#if diff.git_changes}
    <div class="diff-item"><span class="label">🌿 Git</span><pre>{diff.git_changes}</pre></div>
  {/if}
  {#if diff.package_changes.added.length > 0}
    <div class="diff-item added"><span class="label">📦 Packages Added</span><ul>{#each diff.package_changes.added as p}<li>{p}</li>{/each}</ul></div>
  {/if}
  {#if diff.package_changes.removed.length > 0}
    <div class="diff-item removed"><span class="label">📦 Packages Removed</span><ul>{#each diff.package_changes.removed as p}<li>{p}</li>{/each}</ul></div>
  {/if}
  {#if diff.artifact_changes.length > 0}
    <div class="diff-item"><span class="label">📄 Artifacts</span>{#each diff.artifact_changes as a}<div class="artifact-change"><span class={a.type}>{a.type}</span><span>{a.path}</span></div>{/each}</div>
  {/if}
</div>
```

---

## 6. IPC Commands

```rust
// src/ipc/sandbox_time_travel_commands.rs
#[command]
pub async fn get_sandbox_history(state: State<'_, AppState>, thread_id: ULID) -> Result<Vec<SandboxSnapshot>, AppError> {
    Ok(state.sandbox_manager.get_history(thread_id))
}

#[command]
pub async fn sandbox_jump_to(state: State<'_, AppState>, snapshot_id: ULID) -> Result<(), AppError> {
    state.sandbox_time_travel.jump_to(snapshot_id).await.map_err(AppError::Sandbox)
}

#[command]
pub async fn sandbox_fork(state: State<'_, AppState>, snapshot_id: ULID) -> Result<ULID, AppError> {
    state.sandbox_time_travel.fork_from(snapshot_id).await.map_err(AppError::Sandbox)
}

#[command]
pub async fn sandbox_diff(state: State<'_, AppState>, from: ULID, to: ULID) -> Result<DiffResult, AppError> {
    state.sandbox_time_travel.diff(from, to).await.map_err(AppError::Sandbox)
}
```

---

## 6. Use Cases

| Scenario | Action |
|----------|--------|
| Break at step 5, change variable, replay | Jump to 5 → edit in sandbox → re-execute 6+ |
| Compare output before/after refactor | Snapshot at step 3 → continue → diff artifacts |
| Undo agent mistake | Agent deletes file → jump to before → continue |
| Try alternative approach | Fork from step 4 → try different solution → compare |
| Debug flaky test | Jump to before test → add debug output → rerun |

---

> **Accepted as Canonical.** Implementation proceeds in `src/sandbox/snapshots.rs` + frontend.