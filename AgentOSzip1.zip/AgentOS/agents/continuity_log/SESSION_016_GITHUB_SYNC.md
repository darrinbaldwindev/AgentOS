# Session 016: GitHub Sync (Encrypted, Git-Native)
**Project:** AgentOS | **Component:** `sync/github` (Rust Sidecar)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| **Transport** | Git (push/pull) + GitHub API (AI read) | Works offline, versioned, conflict-resolvable |
| **Encryption** | age (x25519) — per-workspace key | Modern, simple, auditable |
| **Key Storage** | OS Keychain (private) / Embedded public key | Private never leaves device |
| **Repo Structure** | Single private repo per workspace | Isolation, access control |
| **Sync Trigger** | Manual + Auto (5min) + On close | User control + safety |
| **Conflict Resolution** | Git merge → UI shows conflicts | Human decides, not AI |

---

## 2. Repo Structure

```
agentos-workspace/
├── .agentos/
│   ├── workspace.db.enc        # Encrypted SQLite (age)
│   ├── continuity_log/
│   │   ├── INDEX.md
│   │   ├── SESSION_001_FOUNDATION.md
│   │   └── ...
│   ├── research/
│   │   └── affiliate/
│   │       ├── REGISTRY_MANIFEST.json
│   │       └── BRIEF_2026-08-21.md
│   ├── charters/
│   ├── tasks/
│   ├── prompts/
│   └── .gitignore
├── .gitignore
└── README.md
```

---

## 3. Sync Engine (Rust Sidecar)

```rust
// src/sync/github_sync.rs
use octocrab::{Octocrab, params};
use std::path::PathBuf;
use age::{Encryptor, Decryptor, secrecy::SecretString};

pub struct GitHubSync {
    octocrab: Octocrab,
    repo: (String, String), // (owner, repo)
    local_root: PathBuf,
    encryption_key: [u8; 32], // x25519 public key for AI decryption
    private_key: Option<[u8; 32]>, // x25519 private key (OS Keychain only)
}

impl GitHubSync {
    pub fn new(pat: &str, owner: &str, repo: &str, local_root: PathBuf) -> Result<Self> {
        let octocrab = Octocrab::builder().personal_token(pat.to_string()).build()?;
        Ok(Self { octocrab, repo: (owner.into(), repo.into()), local_root, encryption_key: load_public_key()?, private_key: None })
    }

    // Push local changes (encrypted)
    pub async fn push(&self, message: &str) -> Result<()> {
        let files = self.collect_changed_files()?;
        let mut tree_items = vec![];
        
        for file in files {
            let content = std::fs::read(&file)?;
            let encrypted = encrypt(&content, &self.encryption_key)?;
            let blob = self.octocrab.git().create_blob(
                &self.repo.0, &self.repo.1, 
                base64::encode(encrypted), "base64"
            ).await?;
            
            tree_items.push(git2::TreeEntry {
                path: file.strip_prefix(&self.local_root)?.to_string_lossy().into(),
                mode: "100644".into(),
                type_: "blob".into(),
                sha: blob.sha,
            });
        }
        
        let tree = self.octocrab.git().create_tree(&self.repo.0, &self.repo.1, tree_items).await?;
        let parent = self.get_head_sha().await?;
        let commit = self.octocrab.git().create_commit(
            &self.repo.0, &self.repo.1, message, tree.sha, &[parent]
        ).await?;
        
        self.octocrab.git().update_ref(&self.repo.0, &self.repo.1, "heads/main", commit.sha, true).await?;
        Ok(())
    }

    // Pull remote changes (decrypt on write)
    pub async fn pull(&self) -> Result<()> {
        let tree = self.octocrab.git().get_tree(&self.repo.0, &self.repo.1, &self.get_head_sha().await?, true).await?;
        
        for entry in tree.tree {
            if entry.type_ == "blob" {
                let blob = self.octocrab.git().get_blob(&self.repo.0, &self.repo.1, &entry.sha).await?;
                let encrypted = base64::decode(&blob.content)?;
                let decrypted = decrypt(&encrypted, &self.private_key.unwrap())?;
                
                let path = self.local_root.join(&entry.path);
                std::fs::create_dir_all(path.parent().unwrap())?;
                std::fs::write(path, decrypted)?;
            }
        }
        Ok(())
    }

    // AI (me) reads files via API — no sync needed
    pub async fn read_file(&self, path: &str) -> Result<String> {
        let content = self.octocrab.repos(&self.repo.0, &self.repo.1)
            .get_content().path(path).send().await?;
        let encrypted = base64::decode(content.content)?;
        Ok(String::from_utf8(decrypt(&encrypted, &self.private_key.unwrap())?)?)
    }
    
    pub async fn list_files(&self, path: &str) -> Result<Vec<FileEntry>> {
        let content = self.octocrab.repos(&self.repo.0, &self.repo.1)
            .get_content().path(path).send().await?;
        // Parse and return file entries
    }
}

fn encrypt(data: &[u8], public_key: &[u8; 32]) -> Result<Vec<u8>> {
    let mut encrypted = Vec::new();
    let mut encryptor = Encryptor::with_user_keys(vec![
        age::x25519::PublicKey::from_bytes(public_key).unwrap()
    ]);
    encryptor.wrap_output(&mut encrypted, |mut w| {
        w.write_all(data).unwrap();
        Ok(())
    }).unwrap();
    Ok(encrypted)
}

fn decrypt(data: &[u8], private_key: &[u8; 32]) -> Result<Vec<u8>> {
    let mut decrypted = Vec::new();
    let decryptor = Decryptor::new(data)?;
    decryptor.read_to_end(&mut decrypted)?;
    Ok(decrypted)
}
```

---

## 4. Encryption (age / x25519)

```bash
# One-time setup on PC
age-keygen -o ~/.agentos/key.txt
# Public key → embedded in binary for AI decryption
# Private key → never leaves PC (stored in OS Keychain)
```

```rust
// Private key loaded from OS Keychain at runtime
async fn load_private_key() -> Result<[u8; 32]> {
    let keychain_entry = keyring::Entry::new("AgentOS", "github_sync_age_key")?;
    let key_b64 = keychain_entry.get_password()?;
    let key_bytes = base64::decode(key_b64)?;
    Ok(key_bytes.try_into().unwrap())
}
```

---

## 5. Frontend UX (Svelte 5)

```svelte
<!-- SyncStatus.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let status = $state<'idle' | 'pushing' | 'pulling' | 'synced' | 'conflict'>('idle');
  let lastSync = $state<number | null>(null);
  let conflictFiles = $state<string[]>([]);
  
  async function sync() {
    status = 'pushing';
    try {
      await invoke('sync_push', { message: `Sync from ${deviceName()}` });
      status = 'synced';
      lastSync = Date.now();
    } catch (e) {
      if (e.includes('conflict')) {
        status = 'conflict';
        conflictFiles = parseConflictFiles(e);
      }
      status = 'idle';
    }
  }
  
  // Auto-sync every 5 min + on app close
  onMount(() => {
    const interval = setInterval(sync, 5 * 60 * 1000);
    window.addEventListener('beforeunload', sync);
    return () => clearInterval(interval);
  });
</script>

<div class="sync-status">
  <span class={status}>{status}</span>
  {#if lastSync}
    <span>Last sync: {formatTime(lastSync)}</span>
  {/if}
  {#if status === 'conflict'}
    <ConflictResolver files={conflictFiles} />
  {/if}
  <button onclick={sync} disabled={status !== 'idle'}>Sync Now</button>
</div>
```

---

## 6. Conflict Resolution

```rust
pub struct ConflictResolver {
    local_root: PathBuf,
    repo: (String, String),
    octocrab: Octocrab,
}

impl ConflictResolver {
    pub async fn detect_conflicts(&self) -> Result<Vec<Conflict>> {
        // 1. git fetch
        // 2. git merge --dry-run
        // 3. Parse conflicts
        // 4. Classify: config (auto-resolve), data (user), schema (manual)
    }
    
    pub async fn resolve_auto(&self, conflicts: &[Conflict]) -> Result<Vec<Conflict>> {
        // Auto-resolve: workspace settings (last-write-wins), RAG index (rebuild)
    }
    
    pub async fn present_to_user(&self, conflicts: &[Conflict]) -> Result<()> {
        // Show in UI with diff view, user picks resolution
    }
}
```

---

## 7. AI Access (Me on Mobile)

```rust
// IPC commands I can call from mobile via GitHub API
#[command]
pub async fn github_read_file(state: State<'_, AppState>, path: String) -> Result<String, AppError> {
    state.github_sync.read_file(&path).await.map_err(AppError::Sync)
}

#[command]
pub async fn github_list_files(state: State<'_, AppState>, path: String) -> Result<Vec<FileEntry>, AppError> {
    state.github_sync.list_files(&path).await.map_err(AppError::Sync)
}

#[command]
pub async fn github_search_code(state: State<'_, AppState>, query: String) -> Result<Vec<CodeMatch>, AppError> {
    state.github_sync.search_code(&query).await.map_err(AppError::Sync)
}
```

---

## 8. Setup Flow

```svelte
<!-- GitHubSetup.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let pat = $state('');
  let owner = $state('');
  let repo = $state('');
  let step = $state<'pat' | 'repo' | 'test' | 'done'>('pat');
  
  async function testConnection() {
    step = 'test';
    const result = await invoke('test_github_connection', { pat, owner, repo });
    if (result.success) step = 'done';
  }
  
  async function completeSetup() {
    await invoke('configure_github_sync', { pat, owner, repo });
    step = 'done';
  }
</script>

<div class="setup-wizard">
  {#if step === 'pat'}
    <h3>GitHub Personal Access Token</h3>
    <p>Create a PAT with <code>repo</code> scope at <a href="https://github.com/settings/tokens">github.com/settings/tokens</a></p>
    <input type="password" bind:value={pat} placeholder="ghp_..." />
    <button onclick={() => step = 'repo'} disabled={!pat}>Next</button>
  {:else if step === 'repo'}
    <h3>Repository</h3>
    <input bind:value={owner} placeholder="owner" /> / <input bind:value={repo} placeholder="repo" />
    <p class="hint">Private repo recommended. Will be created if it doesn't exist.</p>
    <button onclick={testConnection}>Test & Continue</button>
  {:else if step === 'test'}
    <h3>Testing Connection...</h3>
    <Spinner />
  {:else}
    <h3>✅ GitHub Sync Configured</h3>
    <button onclick={completeSetup}>Finish Setup</button>
  {/if}
</div>
```

---

## 7. Implementation Order

| Step | Task |
|------|------|
| 1 | `age` encryption utilities + key management (OS Keychain) |
| 2 | `GitHubSync` struct with push/pull/read |
| 3 | File change detection (notify crate) |
| 4 | Auto-sync scheduler (5min + on close) |
| 5 | Conflict detection + auto-resolve + UI |
| 6 | IPC commands for AI read access |
| 7 | Setup wizard UI |
| 8 | Integration tests |

---

> **Accepted as Canonical.** Implementation proceeds in `src/sync/github_sync.rs`.