# Session 005: Routing Engine Algorithm (The "Optimization Brain")
**Project:** AgentOS | **Component:** `router` (Rust Sidecar)
**Date:** 2026-08-20
**Status:** ✅ Completed — Heuristic Spec v1.0, Fast/Explainable/User-Controllable

---

## 1. Design Philosophy

**No LLM-as-Judge in hot path** — too slow, expensive, non-deterministic.
**Heuristic Scoring + Hard Filters + Rule Overrides** — sub-millisecond, explainable, user-controllable.

---

## 2. Core Types

```rust
// src/router/types.rs
use crate::db::{Model, Provider};

#[derive(Debug, Clone)]
pub struct RoutingContext {
    pub task_type: TaskType,
    pub project_id: ULID,
    pub user_prefs: UserRoutingPrefs,
    pub available_models: Vec<Model>,
    pub estimated_tokens: TokenEstimate,
    pub privacy_level: PrivacyLevel,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum TaskType {
    Coding, Reasoning, Creative, Analysis, SpeedChat, ImageGen, Unknown
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserRoutingPrefs {
    pub prefer_local: bool,
    pub prefer_referral: bool,
    pub max_cost_per_1k_tokens: Option<f64>,
    pub min_quality_score: f32,
    pub max_latency_ms: Option<u32>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PrivacyLevel { Public, Private, LocalOnly }

#[derive(Debug, Clone)]
pub struct RoutingDecision {
    pub model_id: ULID,
    pub provider_id: ULID,
    pub reason: String,                    // "Matched Rule: Referral Coding Optimizer (Groq Llama 3.1 70B)"
    pub fallback_chain: Vec<ULID>,
    pub estimated_cost_usd: f64,
    pub estimated_latency_ms: u32,
    pub confidence: f32,                   // 0.0 - 1.0
}
```

---

## 3. The Algorithm: Weighted Scoring + Hard Filters + Rule Overrides

```rust
// src/router/heuristic_router.rs
pub struct HeuristicRouter {
    db: SqlitePool,
    weights: RouterWeights,
}

#[derive(Debug, Clone)]
pub struct RouterWeights {
    pub task_affinity: f32,    // 0.35
    pub cost: f32,             // 0.25
    pub speed: f32,            // 0.20
    pub quality: f32,          // 0.15
    pub referral_bonus: f32,   // 0.05 (only when user_prefs.prefer_referral)
}

impl Default for RouterWeights {
    fn default() -> Self {
        Self { task_affinity: 0.35, cost: 0.25, speed: 0.20, quality: 0.15, referral_bonus: 0.05 }
    }
}

#[async_trait]
impl Router for HeuristicRouter {
    async fn route(&self, ctx: RoutingContext) -> RoutingDecision {
        let mut candidates = ctx.available_models;

        // PHASE 1: HARD FILTERS (Deal Breakers)
        candidates.retain(|m| {
            m.context_window >= ctx.estimated_tokens.total_needed &&
            !(ctx.privacy_level == PrivacyLevel::LocalOnly && m.provider_type != "local") &&
            (!ctx.task_type.requires_tools() || m.supports_tools) &&
            (!ctx.task_type.requires_vision() || m.supports_vision) &&
            (!ctx.task_type.requires_json() || m.supports_json)
        });

        if candidates.is_empty() {
            return RoutingDecision::fallback_error("No models pass hard filters");
        }

        // PHASE 2: RULE OVERRIDES (Explicit User/Project Config)
        if let Some(rule_match) = self.match_rules(ctx.project_id, &ctx).await {
            if let Some(target) = candidates.iter().find(|m| m.id == rule_match.target_model_id) {
                return RoutingDecision::from_rule(target, &rule_match);
            }
            // Rule matched but target unavailable → log warning, fall through to scoring
        }

        // PHASE 3: SCORE REMAINING CANDIDATES
        let scored: Vec<_> = candidates.into_iter().map(|m| {
            let mut score = 0.0;
            let mut reasons = Vec::new();

            // A. Task Affinity (0-10)
            let affinity = match ctx.task_type {
                TaskType::Coding => m.coding_score,
                TaskType::Reasoning => m.reasoning_score,
                TaskType::Creative => m.quality_score,
                TaskType::Analysis => m.quality_score,
                TaskType::SpeedChat => m.speed_score,
                _ => m.quality_score,
            };
            score += affinity * self.weights.task_affinity;
            reasons.push(format!("Task Affinity: {:.1}", affinity));

            // B. Cost Efficiency (Inverse cost, normalized 0-10)
            if let (Some(in_p), Some(out_p)) = (m.input_price_usd, m.output_price_usd) {
                let cost_per_1k = (in_p + out_p) / 2.0;
                let cost_score = (1.0 - (cost_per_1k / 50.0).min(1.0)) * 10.0; // $50/1k = 0
                score += cost_score * self.weights.cost;
                reasons.push(format!("Cost Score: {:.1} (${:.4}/1k)", cost_score, cost_per_1k));
            } else {
                score += 10.0 * self.weights.cost; // Local/Free = Max
                reasons.push("Cost Score: 10.0 (Free/Local)".to_string());
            }

            // C. Speed (Inverse Latency, 0-10)
            let avg_latency = self.get_avg_latency(&m.id).await.unwrap_or(m.speed_score * 100.0);
            let speed_score = (1.0 - (avg_latency / 10000.0).min(1.0)) * 10.0;
            score += speed_score * self.weights.speed;
            reasons.push(format!("Speed Score: {:.1} (~{}ms)", speed_score, avg_latency));

            // D. Referral Bonus (Business Logic)
            if m.provider.has_referral && ctx.user_prefs.prefer_referral {
                score += self.weights.referral_bonus * 100.0; // Scaled to 0-10 range
                reasons.push("Referral Bonus Applied".to_string());
            }

            // E. General Quality (0-10)
            score += m.quality_score * self.weights.quality;
            reasons.push(format!("Quality: {:.1}", m.quality_score));

            (m, score, reasons.join(" | "))
        }).collect();

        // PHASE 4: SELECT WINNER
        scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap());
        let (winner, score, reason) = scored[0].clone();

        RoutingDecision {
            model_id: winner.id,
            provider_id: winner.provider_id,
            reason: format!("Score: {:.2} | {}", score, reason),
            fallback_chain: scored[1..].iter().map(|(m,_,_)| m.id).take(3).collect(),
            estimated_cost_usd: self.estimate_cost(&winner, &ctx.estimated_tokens),
            estimated_latency_ms: self.get_avg_latency(&winner.id).await.unwrap_or(2000),
            confidence: (score / 50.0).min(1.0), // Max possible ~50
        }
    }
}
```

---

## 4. Task Classification (Lightweight)

**No LLM for every request.** Three-tier approach:

1. **Keywords/Regex** (fastest): `code`, `function`, `debug`, `refactor` → `Coding`
2. **Local Embedding Classifier** (fast): Tiny BERT/ONNX model (<5ms CPU) classifying user intent
3. **User Explicit Override** (highest): `@model:claude` or `/route local` slash commands

```rust
pub fn classify_task_type(user_message: &str, explicit_hint: Option<TaskType>) -> TaskType {
    if let Some(t) = explicit_hint { return t; }
    let lower = user_message.to_lowercase();
    if CODING_KEYWORDS.iter().any(|k| lower.contains(k)) { return TaskType::Coding; }
    if REASONING_KEYWORDS.iter().any(|k| lower.contains(k)) { return TaskType::Reasoning; }
    // ... fallback to local classifier or Unknown
    TaskType::Unknown
}
```

---

## 5. Routing Rules (DB-Driven, Session 002 Schema)

```sql
-- Example: Global rule preferring referral for coding
INSERT INTO routing_rules (id, project_id, name, priority, conditions_json, target_provider_id, fallback_chain_json) VALUES
('01ARZ3NDEKTSV4RRFFQ69G5FC0', NULL, 'Referral Coding Optimizer', 10,
 '{"task_type": "coding", "min_quality": 8.5, "prefer_referral": true}',
 '01ARZ3NDEKTSV4RRFFQ69G5FAY', -- Groq Provider ID
 '["01ARZ3NDEKTSV4RRFFQ69G5FB2", "01ARZ3NDEKTSV4RRFFQ69G5FB0"]'); -- Fallback: Sonnet → GPT-4o
```

**Rule Matching Logic:**
- Conditions are JSON Logic / SQL WHERE fragments
- Priority: lower = runs first
- Project rules override global rules
- Fallback chain used if target unavailable/unhealthy

---

## 6. Referral Ethics Implementation (Fork 2 Decision: **Opt-In Per Provider**)

```rust
// UserPrefs stored in user_settings table
{
  "referral_consent": {
    "openrouter": true,
    "groq": true,
    "perplexity": false,
    "github": false
  }
}

// Router only applies referral_bonus if consent[provider_id] == true
if m.provider.has_referral && ctx.user_prefs.prefer_referral && ctx.user_prefs.referral_consent.get(&m.provider_id).copied().unwrap_or(false) {
    score += self.weights.referral_bonus * 100.0;
}
```

**UI:** Settings → "Referral Partners" → Toggle per provider with tooltip: *"Route via Groq (Referral Partner) — saves you $0.02/request, supports development"*

---

## 7. Explainability & Debugging

Every decision includes:
- **Reason string** with score breakdown
- **Fallback chain** (next 3 models)
- **Confidence** (0-1)
- **Estimated cost/latency**

Frontend shows: `"Routed to Groq Llama 3.1 70B (Score: 8.7) — Task: Coding, Referral: Yes, Cost: $0.0008/1k, Est. Latency: 120ms. Fallback: Claude 3.5 Sonnet → GPT-4o"`

---

> **Accepted as Canonical.** Implementation proceeds in `src/router/heuristic_router.rs`.