# Session 012: GitHub & Perplexity MCP Servers (Killer Integrations)
**Project:** AgentOS | **Components:** `mcp/servers/github`, `mcp/servers/perplexity`, `registry/builtin`
**Date:** 2026-08-20
**Status:** 🟡 Spec Complete — Ready for Implementation (Depends on Session 010 + 011)

---

## 1. GitHub MCP Server (Tier 1: Verified + Referral)

### Base: Fork `github/github-mcp-server`
- **Upstream:** `https://github.com/github/github-mcp-server` (TypeScript, stdio transport)
- **Our Fork:** Add OAuth App integration for referral tracking

### Referral Mechanism: GitHub OAuth App
```
1. We create GitHub OAuth App "AgentOS" with callback: `agentos://oauth/github`
2. User clicks "Connect GitHub" in AgentOS → Opens browser to GitHub OAuth
3. User authorizes → GitHub redirects to `agentos://oauth/github?code=XXX`
4. AgentOS exchanges code for token → Stores in OS Keychain
5. MCP Server starts with `GITHUB_TOKEN` in env
6. We track `installation_id` → GitHub Partner Program credits
```

### OAuth App Manifest (Shipped with Binary)
```json
{
  "name": "AgentOS",
  "url": "https://agentos.local",
  "callback_url": "agentos://oauth/github",
  "permissions": {
    "contents": "read",
    "issues": "write",
    "pull_requests": "write",
    "actions": "read",
    "metadata": "read"
  },
  "events": ["push", "pull_request", "issues", "workflow_run"]
}
```

### MCP Server Config (In Registry)
```json
{
  "id": "github-official",
  "name": "GitHub (Official)",
  "tier": "verified",
  "transport": {
    "type": "stdio",
    "command": "node",
    "args: ["/bundled/mcp-servers/github/dist/index.js"],
    "env": { "GITHUB_TOKEN": "{{KEYCHAIN:github_token}}" }
  },
  "capabilities": ["repo_read", "issue_write", "pr_write", "code_search", "workflow_run", "file_write"],
  "referral": {
    "type": "oauth_app",
    "payload": { "client_id": "OV23li...", "redirect_uri": "agentos://oauth/github" },
    "commission_details": "GitHub Partner Program: $500-$5000/mo based on referred orgs"
  },
  "auto_start": false,
  "enabled": true
}
```

### Tools Exposed to LLM
| Tool | Description | Referral Value |
|---|---|---|
| `github__create_issue` | Create issue in repo | High — drives repo activity |
| `github__create_pr` | Create pull request | High — drives collaboration |
| `github__search_code` | Search code across repos | Medium — discovery |
| `github__read_file` / `write_file` | File operations | Medium — content creation |
| `github__run_workflow` | Trigger CI/CD | High — automation |

### Installation Flow (Frontend)
```svelte
<!-- GitHubConnect.svelte -->
<script>
  async function connectGitHub() {
    // 1. Start MCP server (it will request OAuth)
    const result = await invoke('connect_mcp_server', { serverId: 'github-official' });
    // 2. If needs auth, MCP server returns special result with auth_url
    if (result.needs_auth) {
      await invoke('open_external_url', { url: result.auth_url });
      // 3. Deep link `agentos://oauth/github?code=...` handled by Tauri
      // 4. Backend exchanges code, stores token, restarts MCP server
    }
  }
</script>
```

---

## 2. Perplexity MCP Server (Tier 1: Verified + Affiliate)

### Challenge: No Official Public API (as of 2026-08-20)
**Two Paths:**

#### Path A: Official API (If/When Released)
- Wrap REST API (`/chat/completions`, `/search`)
- Standard MCP tools: `search`, `deep_research`, `ask_followup`

#### Path B: Controlled Browser Automation (Current Reality)
- **Only if user provides session cookie** (opt-in, explicit)
- Runs in **Sandbox** (Session 011) with Playwright
- **Isolated:** No access to user's broader browser data

```rust
// src/mcp/servers/perplexity.rs
pub struct PerplexityMcpServer {
    sandbox: Arc<dyn Sandbox>,
    session_cookie: Option<String>,  // From Keychain, user-provided
}

impl McpServer for PerplexityMcpServer {
    async fn list_tools(&self) -> Vec<Tool> {
        vec![
            Tool { name: "search", description: "Web search via Perplexity", input_schema: ... },
            Tool { name: "deep_research", description: "Deep research report", input_schema: ... },
        ]
    }
    
    async fn call_tool(&self, name: &str, args: Value) -> ToolResult {
        if self.session_cookie.is_none() {
            return ToolResult::error("Perplexity session not configured. Add cookie in Settings.");
        }
        
        // Execute in sandbox with Playwright
        let code = self.build_playwright_script(name, args);
        let result = self.sandbox.execute(Language::Python, code, vec![]).await?;
        // Parse result, return structured data
    }
}
```

### Referral: Affiliate Link in Signup
- Perplexity has affiliate program: `$10 Pro credits` per referral
- Tool generates signup links with `?ref=AGENTOS_REF`
- **No automated routing** — only when user explicitly asks "sign up for Perplexity"

### Registry Entry
```json
{
  "id": "perplexity-search",
  "name": "Perplexity Search",
  "tier": "verified",
  "transport": { "type": "stdio", "command": "python", "args": ["-m", "mcp_perplexity"], "env": {} },
  "capabilities": ["search", "deep_research", "ask_followup"],
  "referral": {
    "type": "signup_url",
    "payload": { "url": "https://perplexity.ai/signup?ref=AGENTOS_REF" },
    "commission_details": "$10 Pro credits per referral (user gets $10, we get $10)"
  },
  "auto_start": false,
  "enabled": true
}
```

---

## 3. Manus: No API → Placeholder + Alternative

### Current Status (2026-08-20)
- **No public API, no affiliate program, invite-only**
- **Browser automation fragile:** UI changes break it, cookie handling risky

### Our Strategy: Option C (OpenHands) + Option B (Placeholder)

#### Option C: OpenHands via MCP (Available Today)
- **OpenHands** (formerly OpenDevin) = open-source autonomous coding agent
- **MCP Server:** `https://github.com/All-Hands-AI/OpenHands` has MCP support
- **Runs in our Sandbox** (Docker or LocalJail)
- **Tools:** `create_agent`, `run_task`, `get_status`, `list_files`, `run_command`

```json
{
  "id": "openhands-agent",
  "name": "OpenHands Autonomous Agent",
  "tier": "verified",
  "transport": { "type": "stdio", "command": "docker", "args": ["run", "-i", "--rm", "ghcr.io/all-hands-ai/openhands:mcp"], "env": {} },
  "capabilities": ["code_generation", "debugging", "repo_analysis", "test_writing", "deployment"],
  "referral": { "type": "none", "payload": {} },
  "auto_start": false,
  "enabled": true
}
```

#### Option B: Manus Placeholder (Future-Proof)
```json
{
  "id": "manus-agent",
  "name": "Manus (Placeholder)",
  "tier": "experimental",
  "transport": { "type": "stdio", "command": "python", "args": ["-m", "mcp_manus_stub"], "env": {} },
  "capabilities": [],
  "referral": { "type": "none", "payload": {} },
  "auto_start": false,
  "enabled": false,
  "stub_message": "Manus API not public. Join waitlist: https://manus.im/waitlist. OpenHands available as alternative."
}
```

---

## 4. Referral Integration Patterns (Summary)

| Provider | Referral Type | Implementation | User Consent |
|---|---|---|---|
| **OpenRouter** | API Key suffix / Query param | Append `?ref=AGENTOS_REF` to signup, track via dashboard | Opt-in toggle |
| **Groq** | Signup URL | `https://console.groq.com/signup?ref=AGENTOS_REF` | Opt-in toggle |
| **GitHub** | OAuth App | Custom OAuth App → Partner credits | Explicit "Connect GitHub" |
| **Perplexity** | Affiliate link | `?ref=AGENTOS_REF` on signup | Opt-in toggle |
| **Together/Fireworks** | Credit share | Dashboard tracking | Opt-in toggle |
| **OpenHands** | None (OSS) | N/A | N/A |

---

## 5. Security Considerations

| Risk | Mitigation |
|---|---|
| **GitHub Token Leak** | Token only in Keychain → injected at MCP spawn → never in DB/logs |
| **Perplexity Cookie** | User-provided only, stored in Keychain, sandboxed browser |
| **OAuth Flow** | PKCE, state parameter, short-lived codes, custom scheme `agentos://` |
| **MCP Server Supply Chain** | Builtin servers bundled with binary (node_modules/python packages vendored) |
| **Tool Injection** | Namespaced tool names (`github__create_issue`) prevent collisions |

---

## 6. Frontend: Connection Manager

```svelte
<!-- ProviderConnections.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let servers = $state<RegistryEntry[]>([]);
  
  async function load() {
    servers = await invoke('list_mcp_servers', {});
  }
  
  async function connect(id: string) {
    const result = await invoke('connect_mcp_server', { serverId: id });
    if (result.needs_auth) {
      await invoke('open_external_url', { url: result.auth_url });
    }
    load();
  }
</script>

<div class="connections">
  {#each servers as s}
    <MCPServerCard server={s} on:connect={connect} />
  {/each}
</div>
```

---

## 7. Implementation Order

1. **Session 010 Complete** → MCP Client, Registry, ToolSet working
2. **Session 011 Complete** → Sandbox with Python/Node runtimes working
3. **This Session:**
   - Bundle GitHub MCP server (vendored node_modules)
   - Build Perplexity MCP wrapper (Python + Playwright in sandbox)
   - Add both to `registry_builtin.json`
   - Implement OAuth flow for GitHub (Tauri deep link handling)
   - Add "Connect GitHub" / "Connect Perplexity" UI

---

> **Ready for Implementation.** Requires Sessions 010 + 011 complete. No dependency on Researcher pilot.