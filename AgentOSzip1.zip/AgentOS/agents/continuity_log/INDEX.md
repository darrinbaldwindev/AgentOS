# AgentOS — Continuity Log Index

**Canonical Project Record Directory:** `agents/continuity_log/`
**Maintained by:** architect-prime (Primary Coordinator)
**Format:** One Markdown file per session/major exchange. `INDEX.md` for navigation.

---

## Session Logs

| Session | File | Date | Focus | Status |
|---|---|---|---|---|
| 001 | `SESSION_001_FOUNDATION.md` | 2026-08-20 | Product vision, architecture overview, monetization model, tech stack selection | ✅ Completed |
| 002 | `SESSION_002_SCHEMA_DESIGN.md` | 2026-08-20 | SQLite schema (DDL), Rust/TS types, migrations, seed data | ✅ Completed |
| 003 | `SESSION_003_CONTEXT_ASSEMBLY.md` | 2026-08-20 | Context assembly pipeline, tokenizer, summarization, RAG injection, budget bar | ✅ Completed |
| 004 | `SESSION_004_PROVIDER_ABSTRACTION.md` | 2026-08-20 | Provider trait, implementations, registry, factory | ✅ Completed |
| 005 | `SESSION_005_ROUTING_ENGINE.md` | 2026-08-20 | Heuristic router, scoring, task classification, referral bonus | ✅ Completed |
| 006 | `SESSION_006_IPC_CONTRACT.md` | 2026-08-20 | Tauri commands, streaming, type-safe bindings (specta) | ✅ Completed |
| 007 | `SESSION_007_LOCAL_LLM_OPS.md` | 2026-08-20 | Ollama management, hardware detection, model pulling, quantization | ✅ Completed |
| 008 | `SESSION_008_MCP_SANDBOX.md` | 2026-08-20 | MCP-first tools, sandbox execution, GitHub/Perplexity integration, referral layer | ✅ Completed |
| 009 | `SESSION_009_COORDINATION_ADOPTION.md` | 2026-08-20 | AI Coordination Kit adoption assessment, charter, ledger, first specialist role | 🟡 In Progress |

---

## Coordination Records (AI Coordination Kit)

| Record | Path | Purpose |
|---|---|---|
| Project Coordination Charter | `../PROJECT_COORDINATION_CHARTER.md` | Constitution: roles, authority, record model, boundaries |
| Shared Coordination Ledger | `../COORDINATION_LEDGER.md` | Append-only task/request/result/disposition log |
| Specialist Role Charter | `../charters/AFFILIATE_RESEARCHER_CHARTER.md` | Durable role definition for affiliate-researcher-01 |
| First Task Brief | `../tasks/TASK_001_AFFILIATE_VERIFY.md` | Bounded verification task for 5 Tier-1 providers |
| Onboarding Copy Block | `../prompts/RESEARCHER_ONBOARDING_COPY_BLOCK.md` | Paste into new chat to spawn Researcher |

---

## Research Outputs (to be populated)

| Output | Path | Status |
|---|---|---|
| Affiliate Registry Manifest | `../research/affiliate/REGISTRY_MANIFEST.json` | ⏳ Pending Researcher result |
| Research Brief | `../research/affiliate/BRIEF_2026-08-20.md` | ⏳ Pending Researcher result |
| Manifest Schema (validation) | `../research/affiliate/REGISTRY_MANIFEST_SCHEMA.json` | ✅ Created |

---

## Key Architectural Decisions (Accepted Facts)

| Decision | Session | Record |
|---|---|---|
| **Stack:** Tauri v2 (Rust + Svelte 5) + Rust Sidecar + SQLite + LanceDB | 001 | SESSION_001_FOUNDATION.md |
| **Core Unit:** Project → Thread → Message + Artifact + Embedding pointer | 002 | SESSION_002_SCHEMA_DESIGN.md |
| **Context Pipeline:** Weighted budget packing (System > Recent > Artifacts > RAG > Summary) | 003 | SESSION_003_CONTEXT_ASSEMBLY.md |
| **Provider Abstraction:** Trait-based (OpenAI, Anthropic, Ollama, OpenRouter, Groq) | 004 | SESSION_004_PROVIDER_ABSTRACTION.md |
| **Router:** Heuristic scoring + hard filters + rule overrides + referral bonus | 005 | SESSION_005_ROUTING_ENGINE.md |
| **IPC:** specta + ts-bindgen, Channel streaming, typed commands | 006 | SESSION_006_IPC_CONTRACT.md |
| **Local Ops:** Ollama detection, hardware profiling, quantization recommendation | 007 | SESSION_007_LOCAL_LLM_OPS.md |
| **Tools/Agents:** MCP-first, native sandbox (bwrap/firejail), GitHub/Perplexity verified | 008 | SESSION_008_MCP_SANDBOX.md |
| **Governance:** AI Coordination Kit adopted; architect-prime = Coordinator; Human = Owner | 009 | SESSION_009_COORDINATION_ADOPTION.md |

---

## Strategic Forks Awaiting Owner Decision

| Fork | Options | Current Lean | Session |
|---|---|---|---|
| Frontend Framework | React vs **Svelte 5** vs SolidJS | **Svelte 5** (performance, bundle, DX) | 001/008 |
| Referral Ethics | Opt-out (A) vs **Opt-in per provider (B)** vs Marketplace (C) | **B** (explicit consent, granular) | 008 |
| Sync/Multi-device | Pure Local v1 vs CRDT vs ElectricSQL vs Custom Cloud | **Pure Local v1** (defer to v1.1) | 001/008 |

---

## Next Actions

1. **Spawn Researcher:** Copy `RESEARCHER_ONBOARDING_COPY_BLOCK.md` → new chat → run Task 001.
2. **Collect Report:** Researcher returns `<<<REPORT_BLOCK>>>` → paste here → Coordinator reviews.
3. **Write Manifest:** Coordinator writes `REGISTRY_MANIFEST.json` + `BRIEF.md` to `research/affiliate/`.
4. **Record Disposition:** Coordinator adds `IN REVIEW` → `ACCEPTED`/`FOLLOW-UP` entry to Ledger.
5. **Evaluate Pilot:** Use `COORDINATION_EVALUATION_TEMPLATE.md` to decide on expansion.

---

> **Note:** This index is maintained by the Primary Coordinator. Specialists do not edit it. Corrections are new session entries.