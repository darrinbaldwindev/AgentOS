# Task Brief — TASK_001_AFFILIATE_VERIFY: Verify Affiliate Programs for Tier-1 Providers

**Assigned role:** affiliate-researcher-01  
**Assigned by:** architect-prime (Primary Coordinator)  
**Issued:** 2026-08-20T23:15:00+00:00  
**Ledger thread:** CL-20260820-001  
**Task type:** read-only audit | research | documentation

## Objective

Verify affiliate/referral program terms for five Tier-1 target providers and populate a structured `REGISTRY_MANIFEST.json` with **only directly verified fields**. Unverified fields must be omitted or set to `null` with a note in the report.

## Inputs and access conditions

| Input | Location or attachment | Required use | Access condition |
|---|---|---|---|
| Project charter | `agents/PROJECT_COORDINATION_CHARTER.md` | Context on routing engine, quality tiers | Must be visible in specialist sandbox |
| Role charter | `agents/charters/AFFILIATE_RESEARCHER_CHARTER.md` | Permissions, prohibitions, reporting format | Must be visible in specialist sandbox |
| Coordination ledger | `agents/COORDINATION_LEDGER.md` | Current thread state | Must be visible in specialist sandbox |
| Target provider list | Embedded in this brief (below) | Defines scope of verification | Provided directly |
| Public web access | Browser/search | Primary verification method | Required — if unavailable, return BLOCKED |

**Target Providers (Tier-1):**
1. **OpenRouter** (inference gateway)
2. **Groq** (inference API)
3. **Perplexity** (search/answer agent)
4. **GitHub** (MCP/OAuth App — developer tools/platform)
5. **Together AI** (inference API)

**Required Manifest Fields per Provider:**
- `provider_id` (slug, e.g., `openrouter`)
- `name`
- `category` (`inference_gateway`, `inference_api`, `agent_platform`, `dev_platform`)
- `quality_tier` (`verified`, `community`, `experimental`)
- `api_docs_url`
- `mcp_server` object: `{ exists: bool, url: string|null, status: "official"|"community"|"none" }`
- `affiliate` object:
  - `has_program`: bool
  - `type`: `cash` | `credit_share` | `hybrid` | `none`
  - `signup_url`: string|null (with placeholder `AGENTOS_REF`)
  - `commission_details`: string|null (exact quoted terms)
  - `cookie_days`: number|null
  - `payout_threshold`: string|null
  - `restrictions`: string[] (e.g., "no self-referral", "new users only")
  - `verified_date`: ISO date string
  - `notes`: string|null
- `routing_tags`: string[] (for router: `referral`, `free_tier`, `gateway`, `coding`, etc.)

## Permitted actions

- Browse public websites: provider docs, blogs, GitHub, affiliate/partner portals, pricing pages.
- Search queries: `"{provider} affiliate program"`, `"{provider} referral program"`, `"{provider} partner program"`, `"{provider} MCP server"`, `"{provider} API referral"`.
- Read local files listed in Inputs above.
- Append `ACKNOWLEDGED` and `RESULT` (or `BLOCKED`) entries to `agents/COORDINATION_LEDGER.md` **only if the ledger file is visible in your sandbox**. If not visible, return the same structured entry in your report to the Primary Coordinator.

## Prohibited actions

- Make authenticated API calls, use personal credentials, or hit rate-limited endpoints.
- Use personal referral codes; all manifest codes must be placeholders (`AGENTOS_REF`).
- Infer terms from forums, Reddit, Discord, or unverified blog posts — only official provider pages.
- Write any file other than the ledger entry (if permitted) and the final report.
- Expand scope beyond the five listed providers.
- Begin follow-up work without a new brief.

## Required procedure

1. Read `PROJECT_COORDINATION_CHARTER.md`, `AFFILIATE_RESEARCHER_CHARTER.md`, `COORDINATION_LEDGER.md`, and this brief.
2. Confirm access to all mandatory inputs. If any input file is not visible, **stop** and return a `BLOCKED` result naming the exact missing file and the work that cannot be performed.
3. For each provider, search and verify the required manifest fields. Record exact source URLs and access dates.
4. Construct `REGISTRY_MANIFEST.json` with `version`, `last_updated`, `researcher_id`, and `entries[]`.
5. Write a brief `BRIEF_2026-08-20.md` summarizing findings, decisions needed, and next actions.
6. Append `ACKNOWLEDGED` (after step 2) and `RESULT` (after step 5) to `COORDINATION_LEDGER.md` if ledger is visible; otherwise include the entries in your report.
7. Return the full Markdown report to `architect-prime` via the `<<<REPORT_BLOCK>>>` protocol.

## Stop conditions and escalation

| Condition | Required response |
|---|---|
| Required input file (charter, ledger, brief) unavailable | Return `BLOCKED`; name the exact missing file and affected work. |
| No public affiliate program found for a provider | Set `affiliate.has_program: false`, document search performed, continue to next provider. |
| Conflicting information across official pages | Note conflict in `affiliate.notes`, set `quality_tier: "experimental"`, do not guess. |
| MCP server status unclear (official vs community) | Set `mcp_server.status: "community"` or `null`, note uncertainty. |
| Sandbox lacks web access | Return `BLOCKED`; cannot perform primary verification method. |

## Required return format

Use these exact sections:

1. **Task and inputs**
2. **Access and environment observations** (including: could you read the three input files? could you browse the web?)
3. **Actions/commands and exact results** (searches performed, URLs visited, key findings per provider)
4. **Direct findings** (verified facts with source URL + date accessed)
5. **Historical claims not independently verified** (rumors, forum posts, outdated docs encountered)
6. **Blockers, limitations, and environment constraints**
7. **What was intentionally not changed** (no code, no manifest file written — only report)
8. **Recommended next action for the Primary Coordinator** (approve manifest? create GitHub App task? expand to Tier-2?)

## Acceptance criteria

The task is complete only when `architect-prime` can determine:
- Whether each provider's affiliate program was verified or confirmed absent.
- What evidence supports each `quality_tier` classification.
- What constraints remain (missing programs, unclear MCP status).
- Whether `REGISTRY_MANIFEST.json` structure is ready for Coordinator to write to `agents/research/affiliate/`.
- Whether any Owner decision is needed (e.g., GitHub OAuth App development effort).

## Output files (Coordinator will write based on your report)

- `agents/research/affiliate/REGISTRY_MANIFEST.json`
- `agents/research/affiliate/BRIEF_2026-08-20.md`

> **Reminder:** Your result is an observation report, not an accepted project decision. The Coordinator will review and record a disposition before any manifest is committed.