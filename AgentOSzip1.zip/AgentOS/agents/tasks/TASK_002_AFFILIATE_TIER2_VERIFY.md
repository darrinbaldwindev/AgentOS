# Task Brief — TASK_002_AFFILIATE_TIER2_VERIFY: Verify Tier-2 Affiliate Programs for AgentOS Routing

**Assigned role:** affiliate-researcher-01  
**Assigned by:** architect-prime (Primary Coordinator)  
**Issued:** 2026-08-21T14:40:00+00:00  
**Ledger thread:** CL-20260821-005  
**Task type:** read-only audit | research | documentation

## Objective

Verify affiliate/referral programs for 10 Tier-2 target providers and produce a **TIER2_SHORTLIST.json** with compatibility scores for AgentOS routing inclusion. Only providers scoring ≥70 on the compatibility rubric advance to routing consideration.

## Inputs and access conditions

| Input | Location or attachment | Required use | Access condition |
|-------|------------------------|--------------|------------------|
| Project charter | `agents/PROJECT_COORDINATION_CHARTER.md` | Context on routing engine, quality tiers | Must be visible in specialist sandbox |
| Role charter | `agents/charters/AFFILIATE_RESEARCHER_CHARTER.md` | Permissions, prohibitions, reporting format | Must be visible in specialist sandbox |
| Coordination ledger | `agents/COORDINATION_LEDGER.md` | Current thread state | Must be visible in specialist sandbox |
| Tier-1 manifest | `agents/research/affiliate/REGISTRY_MANIFEST.json` | Context on verified providers | Must be visible in specialist sandbox |
| Target provider list | Embedded in this brief (below) | Defines scope of verification | Provided directly |
| Public web access | Browser/search | Primary verification method | Required — if unavailable, return BLOCKED |

## Target Providers (Tier-2)

| # | Provider | Category | Priority | Notes |
|---|----------|----------|----------|-------|
| 1 | **Anthropic** | Inference API | High | Check for partner/enterprise program only |
| 2 | **Replicate** | Inference API | High | 12% lifetime recurring claimed |
| 3 | **Mistral AI** | Inference API | High | 20% first mo + 10% recurring (6mo) claimed |
| 4 | **Vercel v0** | Dev Platform | Medium | $5/lead + 30% hybrid (6mo) claimed |
| 5 | **ElevenLabs** | Voice API | Medium | 20% recurring (12mo) claimed |
| 6 | **n8n** | Workflow Automation | High | 50% commission claimed |
| 7 | **Framer** | AI Website Builder | Medium | 50% recurring (12mo) claimed |
| 8 | **Fireflies.ai** | Meeting/Transcription | Low | Up to 30% recurring (12mo) claimed |
| 9 | **Synthflow AI** | Voice Agents | Low | 20% recurring (15mo) claimed, PartnerStack |
| 10 | **Otter.ai** | Meeting/Transcription | Low | 25% recurring (12mo) via Impact |

## Compatibility Scoring Rubric

Each provider scored on 5 dimensions (0-100 each), weighted equally:

| Dimension | Weight | Scoring Criteria |
|-----------|--------|------------------|
| **dev_relevance** | 20% | How directly does this serve AgentOS users? (100 = core dev tool, 0 = consumer only) |
| **recurring_quality** | 20% | Commission structure quality: lifetime > multi-year > 12mo > one-time; recurring > one-time |
| **setup_ease** | 20% | How easy to integrate? (100 = simple referral link, 0 = complex partner approval) |
| **terms_clarity** | 20% | Are terms public, clear, and favorable? (100 = transparent, 0 = opaque/enterprise-only) |
| **routing_value** | 20% | Does this unlock routing value? (100 = unique capability, 0 = redundant) |

**Threshold:** ≥70 → advances to routing consideration. <70 → documented but not routed.

## Required Manifest Fields per Provider

```json
{
  "provider_id": "anthropic",
  "name": "Anthropic",
  "category": "inference_api",
  "quality_tier": "verified|community|experimental",
  "api_docs_url": "https://docs.anthropic.com",
  "mcp_server": { "exists": true, "url": "...", "status": "official|community|none" },
  "affiliate": {
    "has_program": true,
    "type": "cash|credit_share|hybrid|none",
    "signup_url": "https://...?ref=AGENTOS_REF",
    "commission_details": "Exact quoted terms",
    "cookie_days": 30,
    "payout_threshold": "$50",
    "restrictions": ["no_self_referral", "new_users_only"],
    "verified_date": "2026-08-21",
    "notes": "Any caveats"
  },
  "compatibility_score": {
    "dev_relevance": 90,
    "recurring_quality": 80,
    "setup_ease": 70,
    "terms_clarity": 85,
    "routing_value": 60,
    "total": 77
  },
  "routing_recommendation": "include|exclude|defer",
  "routing_tags": ["referral", "high_quality", "voice_api"]
}
```

## Permitted actions

- Browse public websites: provider docs, blogs, GitHub, affiliate/partner portals, pricing pages
- Search queries: `"{provider} affiliate program"`, `"{provider} referral program"`, `"{provider} partner program"`, `"{provider} MCP server"`, `"{provider} API referral"`
- Read local files listed in Inputs above
- Append `ACKNOWLEDGED` and `RESULT` (or `BLOCKED`) entries to `agents/COORDINATION_LEDGER.md` **only if the ledger file is visible in your sandbox**. If not visible, return the same structured entry in your report to the Primary Coordinator.

## Prohibited actions

- Make authenticated API calls, use personal credentials, or hit rate-limited endpoints
- Use personal referral codes; all manifest codes must be placeholders (`AGENTOS_REF`)
- Infer terms from forums, Reddit, Discord, or unverified blog posts — only official provider pages
- Write any file other than the ledger entry (if permitted) and the final report
- Expand scope beyond the 10 listed providers
- Begin follow-up work without a new brief
- Self-schedule, poll a ledger for replies, delegate another specialist, or expand your task scope
- Treat unavailable paths, attachments, or runtimes as product failures without direct evidence
- Present a local result as a release, security, performance, or production claim

## Required procedure

1. Read `PROJECT_COORDINATION_CHARTER.md`, `AFFILIATE_RESEARCHER_CHARTER.md`, `COORDINATION_LEDGER.md`, `REGISTRY_MANIFEST.json`, and this brief.
2. Confirm access to all mandatory inputs. If any input file is not visible, **stop** and return a `BLOCKED` result naming the exact missing file and the work that cannot be performed.
3. For each provider, search and verify the required manifest fields. Record exact source URLs and access dates.
4. Calculate compatibility score using the rubric above.
5. Construct `TIER2_SHORTLIST.json` with all 10 providers (including those scoring <70).
6. Write a brief `TIER2_BRIEF_2026-08-21.md` summarizing findings, recommendations, and any providers needing Owner decision.
7. Append `ACKNOWLEDGED` (after step 2) and `RESULT` (after step 6) to `COORDINATION_LEDGER.md` if ledger is visible; otherwise include the entries in your report.
8. Return the full Markdown report to `architect-prime` via the `<<<REPORT_BLOCK::RESEARCH::START>>>` protocol.

## Stop conditions and escalation

| Condition | Required response |
|-----------|-------------------|
| Required input file (charter, ledger, brief, manifest) unavailable | Return `BLOCKED`; name the exact missing file and affected work. |
| Search rate limit reached before 90% verification | Return `RESULT` with partial data; note incomplete providers in blockers. |
| No public affiliate program found for a provider | Set `affiliate.has_program: false`, document search performed, continue to next provider. |
| Conflicting information across official pages | Note conflict in `affiliate.notes`, set `quality_tier: "experimental"`, do not guess. |
| MCP server status unclear (official vs community) | Set `mcp_server.status: "community"` or `null`, note uncertainty. |
| Provider requires enterprise contact for program details | Set `quality_tier: "experimental"`, note "Enterprise only — not suitable for individual referral routing" in notes. |

## Required return format

Use these exact sections:

1. **Task and inputs**
2. **Access and environment observations** (including: could you read the three input files? could you browse the web?)
3. **Actions/commands and exact results** (searches performed, URLs visited, key findings per provider)
4. **Direct findings** (verified facts with source URL + date accessed)
5. **Corroborated findings** (multiple independent sources agreeing)
6. **Unverified / conflicting claims** (third-party aggregators, forum posts, outdated docs)
7. **Negative findings** (what was NOT found)
8. **Blockers, limitations, and environment constraints**
9. **What was intentionally not changed** (no code, no manifest file written — only report)
10. **Recommended next action for the Primary Coordinator** (which providers to include/exclude/defer; any Owner decisions needed)

## Acceptance criteria

The task is complete only when `architect-prime` can determine:
- Each provider's affiliate program verified or confirmed absent
- Compatibility scores calculated per rubric with evidence
- Which providers meet ≥70 threshold for routing inclusion
- `TIER2_SHORTLIST.json` structure is ready for Coordinator to write to `agents/research/affiliate/`
- Whether any Owner decision is needed (e.g., enterprise-only programs, unclear terms)

## Output files (Coordinator will write based on your report)

- `agents/research/affiliate/TIER2_SHORTLIST.json`
- `agents/research/affiliate/TIER2_BRIEF_2026-08-21.md`

> **Reminder:** Your result is an observation report, not an accepted project decision. The Coordinator will review and record a disposition before any manifest is committed.