# Task Brief — TASK_003_MCP_VERIFICATION: Verify MCP Server Status for Groq, Together AI, Perplexity

**Assigned role:** affiliate-researcher-01  
**Assigned by:** architect-prime (Primary Coordinator)  
**Issued:** 2026-08-21T14:50:00+00:00  
**Ledger thread:** CL-20260821-007  
**Task type:** read-only audit | verification | documentation

## Objective

Verify the official vs community status of MCP servers for three providers where search rate limits prevented completion in TASK_001. Produce an **MCP_STATUS_UPDATE.json** with definitive classification.

## Inputs and access conditions

| Input | Location | Required use | Access condition |
|-------|----------|--------------|------------------|
| Project charter | `agents/PROJECT_COORDINATION_CHARTER.md` | Context | Must be visible |
| Role charter | `agents/charters/AFFILIATE_RESEARCHER_CHARTER.md` | Permissions | Must be visible |
| Coordination ledger | `agents/COORDINATION_LEDGER.md` | Current thread | Must be visible |
| Tier-1 manifest | `agents/research/affiliate/REGISTRY_MANIFEST.json` | Current MCP status | Must be visible |
| Public web access | Browser/search | Primary verification | Required |

## Target Providers (MCP Verification Only)

| Provider | Current Status (from TASK_001) | Verification Needed |
|----------|--------------------------------|---------------------|
| **Groq** | Community (unverified) | Is there an official Groq MCP server? Check groq.com, GitHub org, docs |
| **Together AI** | Community (unverified) | Is there an official Together AI MCP server? Check together.ai, GitHub org |
| **Perplexity** | Community (ppl-ai org) | Is the ppl-ai MCP server officially blessed? Check docs.perplexity.ai, Perplexity blog |

## Required Output: MCP_STATUS_UPDATE.json

```json
{
  "version": 1,
  "last_updated": "2026-08-21T...Z",
  "researcher_id": "affiliate-researcher-01",
  "entries": [
    {
      "provider_id": "groq",
      "mcp_server": {
        "exists": true,
        "url": "https://github.com/...",
        "status": "official|community|none",
        "official_source_url": "https://groq.com/... or https://docs.groq.com/...",
        "last_verified": "2026-08-21",
        "notes": "Verified via official Groq docs/blog/GitHub org"
      }
    },
    {
      "provider_id": "together_ai",
      "mcp_server": {
        "exists": true,
        "url": "https://github.com/togethercomputer/...",
        "status": "official|community|none",
        "official_source_url": "https://together.ai/... or https://docs.together.ai/...",
        "last_verified": "2026-08-21",
        "notes": "Verified via official Together AI docs/blog/GitHub org"
      }
    },
    {
      "provider_id": "perplexity",
      "mcp_server": {
        "exists": true,
        "url": "https://github.com/ppl-ai/mcp-server-perplexity",
        "status": "official|community|none",
        "official_source_url": "https://docs.perplexity.ai/... or https://www.perplexity.ai/blog/...",
        "last_verified": "2026-08-21",
        "notes": "ppl-ai org status: officially maintained by Perplexity team or community?"
      }
    }
  ]
}
```

## Permitted actions

- Browse official docs, GitHub orgs, provider blogs, MCP server repositories
- Search: `"{provider} MCP server"`, `site:github.com/{org} mcp`, `"{provider} model context protocol"`
- Read local files listed in Inputs
- Append `ACKNOWLEDGED` and `RESULT` to ledger if visible

## Prohibited actions

- Same as TASK_002 (no auth, no personal codes, no scope expansion, etc.)

## Required procedure

1. Read input files, confirm access
2. For each provider, verify MCP server status via **official sources only**
3. Determine status: `official` (published by provider org, referenced in official docs), `community` (third-party, not officially blessed), `none` (no MCP server found)
4. Record exact source URL that confirms status
5. Construct `MCP_STATUS_UPDATE.json`
6. Write brief `MCP_VERIFICATION_BRIEF_2026-08-21.md`
7. Append ledger entries, return report via `<<<REPORT_BLOCK>>>`

## Stop conditions

| Condition | Response |
|-----------|----------|
| Input files unavailable | `BLOCKED` with exact missing file |
| No official MCP server found | Set `status: "none"`, document search |
| Status ambiguous (community repo but referenced in docs) | Set `status: "community"`, note ambiguity in notes |
| Rate limit reached | Return partial results, note incomplete |

## Output files (Coordinator writes)

- `agents/research/mcp/MCP_STATUS_UPDATE.json`
- `agents/research/mcp/MCP_VERIFICATION_BRIEF_2026-08-21.md`

## Report format

Same 10-section format as TASK_002. Include specific MCP verification evidence per provider.