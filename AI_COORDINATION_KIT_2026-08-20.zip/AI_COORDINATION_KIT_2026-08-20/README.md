# AI Coordination Kit

**Version:** 1.0  
**Format:** Markdown-first, local-first, human-supervised  
**Purpose:** Provide a reusable coordination pattern for a primary AI and durable specialist AIs working across sessions or separate sandboxes.

## What this kit solves

The kit preserves **task intent, role boundaries, evidence, blockers, and review decisions** so that a future contributor can resume an AI-assisted project without relying on lost chat history. It is designed for projects where a primary coordinator assigns bounded work to specialists and must distinguish raw agent observations from accepted project facts.

> This kit is a coordination pattern, not a real-time multi-agent platform. It does not create automatic messaging, shared sandbox visibility, background execution, or authority to change a project.

## Core operating model

```text
Project owner → Primary Coordinator → bounded specialist assignment → specialist report
→ Primary Coordinator evidence review → accepted project record / follow-up / closure
```

The **primary coordinator** owns the canonical project record. Specialists receive an explicit brief, work within stated boundaries, and return evidence. A shared ledger and optional specialist-specific ledger provide structured append-only coordination records where the environment permits; a structured report is the fallback when shared files or attachments are unavailable.

## Kit contents

| File | Purpose |
|---|---|
| `COORDINATION_PROTOCOL.md` | Core governance model, roles, states, and non-polling rules. |
| `PROJECT_ADOPTION_CHECKLIST.md` | Safe project-specific setup and rollout checklist. |
| `templates/PROJECT_COORDINATION_CHARTER_TEMPLATE.md` | Defines the project’s coordinator, record ownership, and boundaries. |
| `templates/SPECIALIST_ROLE_CHARTER_TEMPLATE.md` | Creates a durable specialist role with explicit permissions and limits. |
| `templates/TASK_BRIEF_TEMPLATE.md` | Issues one bounded task to a specialist. |
| `templates/COORDINATION_LEDGER_TEMPLATE.md` | Shared append-only request/result index. |
| `templates/AGENT_LEDGER_TEMPLATE.md` | Optional specialist-specific thread record. |
| `templates/REVIEW_DISPOSITION_TEMPLATE.md` | Documents coordinator acceptance, deferral, or rejection of specialist findings. |
| `templates/AGENT_ONBOARDING_COPY_BLOCK_TEMPLATE.md` | Provides a copy-ready specialist onboarding instruction. |

## Minimum adoption

1. Copy `COORDINATION_PROTOCOL.md` and `PROJECT_ADOPTION_CHECKLIST.md` into the target project’s governance area.
2. Instantiate the project coordination charter and choose the **one canonical project record** that holds accepted facts.
3. Create one specialist role charter; do not create several agents until the first role and handoff process have been tested.
4. Create a shared coordination ledger and issue one bounded task brief.
5. Require the specialist to return a structured result, then have the primary coordinator record the review disposition.
6. Only promote accepted findings into the project’s canonical record.

## Non-negotiable boundaries

| Boundary | Required rule |
|---|---|
| Evidence ownership | The canonical project record contains accepted facts, not unreviewed agent output. |
| Scope control | Every task names the objective, inputs, allowed actions, prohibited actions, stop conditions, and required output. |
| Append-only coordination | Ledger entries are added, not rewritten. Corrections reference prior entries. |
| No implicit messaging | Agents do not poll ledgers or assume they share a filesystem or attachments. |
| Human authority | Specialists do not silently make strategic, data-loss, release, payment, production, or external-service decisions. |
| Safe fallback | If shared files or inputs are unavailable, the agent returns the same structured report through the human/project coordinator. |

## What not to claim

Do not describe this kit as providing automatic agent-to-agent communication, a queue, scheduling, cross-sandbox synchronization, security isolation, or production orchestration. Those capabilities require separately designed, approved, and tested infrastructure.

## Recommended first experiment

Run one read-only verification, documentation audit, or requirements-analysis task. Measure whether the records answer: **who was assigned what, based on which inputs, what they found, what remained uncertain, and what the coordinator accepted or deferred**. Refine templates from real use before building a UI, scheduler, or persistent service.
