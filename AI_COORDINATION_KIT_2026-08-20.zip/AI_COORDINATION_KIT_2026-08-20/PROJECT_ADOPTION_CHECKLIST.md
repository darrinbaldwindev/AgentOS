# Project Adoption Checklist

Use this checklist before applying the AI Coordination Kit to a new project.

## A. Establish project governance

| Check | Completion condition |
|---|---|
| Identify the project owner | The person or role that approves high-impact decisions is named. |
| Identify the Primary Coordinator | One AI or human role is assigned routine continuity and evidence-review responsibility. |
| Identify the canonical project record | The file or system where accepted project facts belong is explicitly named. |
| Preserve existing authority | Existing state, architecture, product, release, and data owners are not silently replaced. |
| Confirm shared-file assumptions | Treat cross-agent sandbox visibility as unproven until directly tested. |

## B. Configure the minimum artifacts

| Artifact | Required setup |
|---|---|
| Project coordination charter | Set coordinator name, canonical record, project scope, and safety boundaries. |
| Shared coordination ledger | Create an empty append-only ledger with the generic message template. |
| First specialist charter | Define one read-only or low-risk specialist role. |
| First task brief | State objective, evidence inputs, permitted/prohibited actions, stop conditions, and return format. |
| Review disposition record | Specify how the coordinator accepts, defers, rejects, or closes findings. |

## C. Run the first exchange

1. Use a bounded task that can be completed without production actions, destructive changes, or external credentials.
2. Provide every required attachment directly to the specialist task; do not assume another sandbox can see the coordinator’s local file path.
3. Require an `ACKNOWLEDGED`, `BLOCKED`, or `RESULT` response using the ledger format.
4. Have the Primary Coordinator classify all evidence before writing any accepted fact to the canonical record.
5. Record missing attachments, inaccessible paths, unavailable runtimes, and conflicting records as environment or governance constraints rather than defects unless independently demonstrated.

## D. Evaluate recovery quality

After the exchange, confirm that a new contributor can answer all questions below from project records:

| Question | Expected evidence |
|---|---|
| Who performed the work? | Specialist role and charter reference. |
| What was the task? | Bounded brief and ledger request. |
| What inputs were available? | File paths, attachment identities, hashes, or explicit absence. |
| What was observed? | Specialist result with direct observations separate from historical claims. |
| What did the coordinator accept? | Review disposition and canonical-record update where applicable. |
| What remains open? | Blocker, deferred decision, or follow-up entry. |

## E. Do not expand yet if any of these apply

Do not add more agents, a UI, a scheduler, external providers, or persistent orchestration until the first exchange is recoverable and all of the following are clear:

- The canonical project record has a named owner.
- The project can distinguish observation from accepted fact.
- Required inputs can be attached or otherwise delivered reliably.
- The owner understands that ledger files are not real-time messaging systems.
- The team has a defined response for missing sandbox access and failed handoffs.
