# Generic AI Coordination Protocol

## 1. Purpose and scope

This protocol governs a **Primary Coordinator** and one or more durable **Specialist Agents** within a single project. Its purpose is to make AI-assisted work recoverable, reviewable, and bounded. It applies to project records, role charters, task briefs, coordination ledgers, specialist results, and review dispositions.

It does not create real-time agent messaging, background execution, automatic scheduling, or a shared sandbox. Those capabilities must be separately designed and approved.

## 2. Roles and record ownership

| Role | Responsibilities | Cannot do by default |
|---|---|---|
| Project Owner | Sets strategic direction, approves high-impact decisions, and can create or recall agents. | Delegate final authority without stating it. |
| Primary Coordinator | Maintains continuity, assigns bounded work, reviews evidence, and updates the canonical project record. | Treat unreviewed specialist output as accepted fact. |
| Specialist Agent | Performs a bounded task, reports direct observations and limitations, and follows its charter. | Self-schedule, expand scope, delegate another agent, or make strategic/release/data-loss decisions. |

The project must identify one **canonical project record** for accepted facts. The primary coordinator is its sole routine writer. Coordination ledgers are operational records and must remain separate from the canonical record.

## 3. Required task lifecycle

```text
REQUEST → ACKNOWLEDGED → RESULT → IN REVIEW → ACCEPTED / FOLLOW-UP / CLOSED
                  ↘ BLOCKED ↗
```

| State | Meaning | Normal writer |
|---|---|---|
| `REQUEST` | A bounded task is assigned. | Primary Coordinator |
| `ACKNOWLEDGED` | The task, scope, and inputs are understood and accessible. | Specialist |
| `BLOCKED` | An input, attachment, path, authority, or environment condition prevents progress. | Specialist or Primary Coordinator |
| `RESULT` | The specialist completed the bounded work and reports evidence/limitations. | Specialist |
| `IN REVIEW` | The coordinator is evaluating the returned evidence. | Primary Coordinator |
| `ACCEPTED` | A finding is accepted into project understanding. | Primary Coordinator |
| `FOLLOW-UP` | A new bounded next action is issued. | Primary Coordinator |
| `CLOSED` | The exchange has no remaining action. | Primary Coordinator |

## 4. Mandatory task boundaries

Every task brief must state:

1. The objective and expected deliverable.
2. Inputs, required files, attachment identities, and any hash/value needed for verification.
3. Permitted actions and prohibited actions.
4. Stop conditions and escalation triggers.
5. Whether the specialist may append to a ledger or must return its report through another channel.
6. How the primary coordinator will review and accept, defer, reject, or follow up on the result.

## 5. Ledger rules

A coordination ledger is append-only. Existing entries are never changed, deleted, reordered, or reclassified. A correction is a new entry that cites the prior entry ID.

Specialists read the ledger only at explicit task boundaries: before beginning the assigned work and immediately before returning. They do not poll it or wait for a response. One active task per specialist role is recommended unless the project has an explicit concurrency policy.

## 6. Shared-file and attachment fallback

Separate AI sandboxes may not see the same path, attachment, or ledger. If a specialist cannot access a required input, it must issue a `BLOCKED` result that names the exact unavailable input and the scope of work not performed. It must not infer a software regression from a missing sandbox resource.

If a specialist cannot append to the shared ledger, it returns the same structured ledger entry in its task response. The owner or primary coordinator then appends/reviews it through the project’s normal governance path.

## 7. Evidence and acceptance boundary

A specialist report is an observation, not a decision. The primary coordinator must distinguish:

| Category | Meaning |
|---|---|
| Direct observation | Reproduced or inspected in the specialist’s own assigned environment. |
| Historical claim | Recorded elsewhere but not independently rechecked in the current task. |
| Environment limitation | A missing input, runtime, path, attachment, permission, or shared-file visibility issue. |
| Accepted project fact | A coordinator-reviewed finding promoted into the canonical project record. |

## 8. Scheduling and background work

No specialist self-schedules. Do not use continuous polling as a coordination method. A recurring coordinator review may be created only after the owner explicitly approves the cadence, time zone, bounded prompt, evidence destination, expiry/review point, and scope limits.

High-frequency monitoring, persistent queues, external integrations, credential handling, and real-time messaging are separate system designs. Do not introduce them through a ledger template.

## 9. Safe adoption posture

Begin with a read-only or low-risk task. Keep the first roles and ledgers minimal. Collect evidence of handoff failures, missing attachments, conflicting records, and recovery usefulness before expanding into a product UI, automation service, or additional specialist roles.
