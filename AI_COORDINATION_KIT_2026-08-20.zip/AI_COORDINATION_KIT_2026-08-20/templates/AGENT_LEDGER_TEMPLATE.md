# <PROJECT NAME> — <SPECIALIST ROLE NAME> Ledger

**Specialist role:** <ROLE NAME>  
**Ledger steward:** <Primary Coordinator>  
**Shared coordination ledger:** `<path>`  
**Canonical project record:** `<path or system>`

> This ledger records one specialist role’s bounded exchanges. It is not a real-time mailbox and does not replace the shared coordination ledger or canonical project record.

## Role-specific rules

1. The Primary Coordinator opens requests and records reviews, dispositions, follow-ups, and closures.
2. The named specialist may append only its own `ACKNOWLEDGED`, `BLOCKED`, or `RESULT` entries when a task brief explicitly permits it.
3. Read this ledger at task start and before returning; do not poll it for replies.
4. If the file is not visible in the specialist sandbox, return the same formatted entry to the Primary Coordinator through the defined handoff channel.
5. Do not edit prior entries. Corrections are new entries with an `In reply to` reference.

## Entry template

```markdown
## <ROLE PREFIX>-YYYYMMDD-NNN — <short subject>

**Timestamp:** <local date/time and time zone>  
**From:** <Primary Coordinator | Specialist Role>  
**To:** <recipient>  
**State:** <REQUEST | ACKNOWLEDGED | BLOCKED | RESULT | IN REVIEW | ACCEPTED | FOLLOW-UP | CLOSED>  
**In reply to:** <entry ID or `none`>  
**Task/scope:** <bounded task reference>  
**Response required from:** <role/owner or `none`>

**Message.** <Factual request, evidence, limitation, or disposition.>

**Evidence or attachment reference.** <exact path, attachment, hash, command/result, report, or `none`>

**Boundary.** <What this entry does not authorize.>
```

## Active thread

<!-- Example: a request is created by the Primary Coordinator; the specialist acknowledges only after required inputs are visibly available. -->

## Entries

<!-- Add new entries below this line. -->
