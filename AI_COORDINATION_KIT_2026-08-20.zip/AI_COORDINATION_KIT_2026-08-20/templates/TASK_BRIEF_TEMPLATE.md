# Task Brief — <TASK ID>: <SHORT TITLE>

**Assigned role:** <SPECIALIST ROLE NAME>  
**Assigned by:** <Primary Coordinator>  
**Issued:** <date/time and time zone>  
**Ledger thread:** <entry ID or `none`>  
**Task type:** <read-only audit | verification | research | documentation | safe implementation>

## Objective

<State one clear result the specialist must produce.>

## Inputs and access conditions

| Input | Location or attachment | Required use | Access condition |
|---|---|---|---|
| <input name> | `<path / attachment name / URL>` | <what to inspect/run> | <must be visible in specialist sandbox / optional / owner provides> |

If a named input is not visible, the specialist must stop the dependent procedure and return a `BLOCKED` result. It must not substitute an unrelated file or infer a product defect from an unavailable sandbox resource.

## Permitted actions

- <specific read-only inspections or reversible changes>
- <specific commands allowed>
- <specific ledger append permission, if any>

## Prohibited actions

- <source/data/environment actions not allowed>
- <authority/release/deployment actions not allowed>
- <any task-specific restrictions>

## Required procedure

1. Read `<coordination charter>`, `<canonical record>`, `<ledger>`, and the required task inputs.
2. Confirm access to every mandatory input.
3. Perform `<specific checks or work>`.
4. Record exact results, warnings, evidence paths, and limitations.
5. Append `<ACKNOWLEDGED / BLOCKED / RESULT>` to `<ledger>` only if permitted. Otherwise return the same structured content through `<return channel>`.
6. Stop after the stated objective. Do not begin follow-up work without a new brief.

## Stop conditions and escalation

| Condition | Required response |
|---|---|
| Required input/attachment unavailable | Return `BLOCKED`; name the exact missing item and affected work. |
| Owner decision is required | Stop and identify the decision, options, and impact. |
| Task requires prohibited action | Stop and request a revised owner-approved brief. |
| Verification contradicts prior record | Report exact evidence; do not silently correct the canonical record. |

## Required return format

Use these exact sections:

1. **Task and inputs**
2. **Access and environment observations**
3. **Actions/commands and exact results**
4. **Direct findings**
5. **Historical claims not independently verified**
6. **Blockers, warnings, or limitations**
7. **What was intentionally not changed**
8. **Recommended next action for the Primary Coordinator**

## Acceptance criteria

The task is complete only when `<Primary Coordinator>` can determine whether the objective was met, what evidence supports that conclusion, what constraints remain, and whether any canonical-record update or owner decision is needed.
