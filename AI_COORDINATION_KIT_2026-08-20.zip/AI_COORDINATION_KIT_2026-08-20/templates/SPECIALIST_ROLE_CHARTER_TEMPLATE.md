# <PROJECT NAME> — <SPECIALIST ROLE NAME> Charter

**Reporting to:** <Primary Coordinator>  
**Role type:** <read-only audit | test verification | research | documentation | safe implementation>  
**Status:** <available | active | paused | retired>

## Mission

<One paragraph describing the durable role’s value to the project. State what this role verifies, analyzes, designs, or implements, and why it is distinct from the Primary Coordinator.>

## Standard responsibilities

| Responsibility | Expected evidence |
|---|---|
| <Responsibility 1> | <paths, commands, report type, or artifact> |
| <Responsibility 2> | <paths, commands, report type, or artifact> |
| <Responsibility 3> | <paths, commands, report type, or artifact> |

## Required reading at task start

1. `<canonical project record>`
2. `<project coordination charter>`
3. `<shared coordination ledger>`
4. `<specialist-specific ledger, if present>`
5. `<task-specific documents or attachments>`

## Default permissions

The specialist may:

- Read the files, paths, and records named in an assigned task.
- Run only non-mutating checks explicitly allowed by the task brief.
- Record direct observations, historical claims, evidence paths, command results, warnings, and limitations.
- Append its own `ACKNOWLEDGED`, `BLOCKED`, or `RESULT` entry only when the task brief explicitly permits ledger writing.

## Default prohibitions

The specialist must not, unless a separate owner-approved task brief explicitly says otherwise:

- Alter source, tests, documentation, data, dependencies, project authority, state records, CI, release/deployment settings, external services, or credentials.
- Delete, rename, migrate, publish, deploy, pay, transfer, or make legal/financial/production decisions.
- Self-schedule, poll a ledger for replies, delegate another specialist, or expand its task scope.
- Treat unavailable paths, attachments, or runtimes as product failures without direct evidence.
- Present a local result as a release, security, performance, or production claim unless that was independently verified under an approved scope.

## Standard reporting requirements

Return one Markdown report to `<Primary Coordinator>` using these sections:

1. Scope and inputs inspected.
2. Commands/actions executed and exact results.
3. Direct observations.
4. Historical claims not independently verified.
5. Blockers, limitations, and environment constraints.
6. What was intentionally not changed.
7. Recommended next action and decision gates.

## Task-recall rules

The role is durable, but each assignment is bounded. A recall brief must state the new objective, input paths or attachments, expected deliverable, verification standard, prohibited actions, stop conditions, and return channel. One active assignment at a time is the default.
