# Coordination Exchange Evaluation

**Project:** <PROJECT NAME>  
**Exchange/task ID:** <TASK OR LEDGER ID>  
**Specialist role:** <ROLE NAME>  
**Evaluator:** <Primary Coordinator>  
**Date:** <date/time and time zone>

## Evaluation purpose

Assess whether a completed specialist exchange is recoverable and governed well enough to justify continued use or cautious expansion of the coordination pattern.

## Recovery checklist

| Question | Evidence reference | Result | Notes |
|---|---|---|---|
| Is the specialist role and charter identifiable? | <path> | <pass/fail/partial> | |
| Is the bounded task objective clear? | <brief/ledger ID> | <pass/fail/partial> | |
| Are required inputs and attachments identifiable? | <paths/hashes> | <pass/fail/partial> | |
| Are direct observations separated from historical claims? | <report> | <pass/fail/partial> | |
| Are access and environment limitations recorded? | <report/ledger> | <pass/fail/partial> | |
| Is the coordinator disposition recorded? | <review record> | <pass/fail/partial> | |
| Is the next action or closure unambiguous? | <entry> | <pass/fail/partial> | |
| Did any unreviewed output enter the canonical project record? | <record check> | <yes/no> | |

## Handoff reliability

| Condition | Observed? | Impact | Improvement needed |
|---|---|---|---|
| Shared ledger visible to specialist | <yes/no/unknown> | | |
| Required attachment visible to specialist | <yes/no/unknown> | | |
| Coordinator and specialist used matching templates | <yes/no/partial> | | |
| A sandbox-local path was mistakenly assumed shared | <yes/no> | | |
| A fallback report channel was available | <yes/no> | | |

## Disposition

**Overall assessment:** <usable | usable with changes | blocked | discontinue/replace>

**Lessons learned.** <What the project should preserve, improve, or stop doing.>

**Expansion decision.** <Keep one role; add another role; improve templates; evaluate a prototype; defer further adoption.>

**Boundaries preserved.** <Confirm that no unapproved source, data, schedule, external-service, deployment, or release action resulted from this exchange.>
