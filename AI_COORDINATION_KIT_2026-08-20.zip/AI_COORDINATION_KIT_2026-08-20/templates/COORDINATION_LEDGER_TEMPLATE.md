# <PROJECT NAME> — AI Coordination Ledger

**Ledger steward:** <Primary Coordinator>  
**Canonical project record:** `<path or system>`  
**Purpose:** Append-only coordination record for bounded requests, acknowledgments, blockers, results, and review dispositions.

> A ledger entry is an operational coordination message. It is not automatically an accepted project fact, decision, test result, or release claim.

## Rules

1. The Primary Coordinator is the sole routine writer of the canonical project record.
2. A specialist may append only its own new entry and only when an assigned task explicitly permits it.
3. Entries are never edited, deleted, reordered, or reclassified. Corrections are new entries that cite earlier IDs.
4. Specialists read this file at explicit task boundaries only and do not poll it for replies.
5. If the ledger is unavailable in a specialist sandbox, the specialist returns the same entry in its report; the Primary Coordinator records/reviews it through the project’s normal handoff channel.
6. Keep one active task per specialist role unless an explicit concurrency policy says otherwise.

## State legend

| State | Writer | Meaning |
|---|---|---|
| `REQUEST` | Primary Coordinator | Bounded task issued. |
| `ACKNOWLEDGED` | Specialist | Task and required inputs are understood/available. |
| `BLOCKED` | Specialist or Coordinator | Required input, authority, environment, or access condition is unavailable. |
| `RESULT` | Specialist | Bounded task completed; direct evidence and limitations reported. |
| `IN REVIEW` | Primary Coordinator | Evidence is being assessed. |
| `ACCEPTED` | Primary Coordinator | Finding accepted into project understanding. |
| `FOLLOW-UP` | Primary Coordinator | New bounded next action issued. |
| `CLOSED` | Primary Coordinator | Thread complete. |

## Entry template

```markdown
## CL-YYYYMMDD-NNN — <short subject>

**Timestamp:** <ISO 8601 or local date/time and time zone>  
**From:** <Primary Coordinator | Specialist Role>  
**To:** <recipient role | Project Owner>  
**State:** <REQUEST | ACKNOWLEDGED | BLOCKED | RESULT | IN REVIEW | ACCEPTED | FOLLOW-UP | CLOSED>  
**In reply to:** <entry ID or `none`>  
**Task/scope:** <bounded task or question>  
**Response required from:** <role/owner or `none`>

**Message.** <Factual request, evidence, limitation, or disposition.>

**Evidence or attachment reference.** <exact path, attachment, hash, command/result, report, or `none`>

**Boundary.** <What this entry does not authorize.>
```

## Active thread index

| Specialist role | Task/thread ID | State | Next actor |
|---|---|---|---|
| <ROLE> | <CL ID> | <state> | <role or owner> |

## Entries

<!-- Add new entries below this line. -->
