# Review Disposition — <REVIEW ID>: <SUBJECT>

**Reviewer:** <Primary Coordinator>  
**Reviewed specialist role:** <ROLE NAME>  
**Task/thread reference:** <task ID / ledger entry>  
**Reviewed on:** <date/time and time zone>  
**Disposition:** <IN REVIEW | ACCEPTED | FOLLOW-UP | CLOSED | DEFERRED>

## Inputs reviewed

| Input | Location/reference | Treatment |
|---|---|---|
| Specialist report | `<path / pasted report / attachment>` | <direct evidence / limitation / historical claim> |
| Coordination entry | `<ledger ID>` | <state and relevance> |
| Project record | `<path>` | <consistency check> |

## Coordinator assessment

### Directly supported findings

<Identify findings supported by the specialist’s direct observations.>

### Findings not accepted as project facts

<Identify claims that remain historical, unverified, out of scope, unsupported, or blocked by environment/access limitations.>

### Decision and rationale

<State whether evidence is accepted, deferred, rejected, needs follow-up, or is closed. Explain why.>

## Consequences

| Area | Action | Authority / next actor |
|---|---|---|
| Canonical project record | <append accepted finding / no update / owner decision needed> | <Primary Coordinator / Owner> |
| Specialist thread | <close / issue follow-up / remain blocked> | <role> |
| Risks or constraints | <record / monitor / none> | <role> |
| Product or release posture | <no change / specified change> | <owner> |

## Boundaries preserved

<Explicitly list any source, data, release, deployment, authority, external-service, or schedule action that this review does not authorize.>

## Required next action

<One clear next action, or state `none` if closed.>
