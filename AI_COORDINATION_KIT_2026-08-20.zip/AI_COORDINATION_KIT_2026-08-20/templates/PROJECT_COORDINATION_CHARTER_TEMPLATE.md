# <PROJECT NAME> — AI Coordination Charter

**Status:** <draft | active internal practice | retired>  
**Project owner:** <name/role>  
**Primary Coordinator:** <name/role>  
**Canonical project record:** `<path or system>`  
**Effective date:** <date>

## Purpose

This charter defines how the project coordinates durable AI specialist roles while preserving a clear distinction between specialist observations and accepted project facts.

## Coordination scope

| In scope | Out of scope |
|---|---|
| <Examples: read-only audits, verification, documentation analysis, bounded safe implementation> | <Examples: production changes, payment actions, destructive migrations, release publication, unattended orchestration> |

## Roles and authority

| Role | Responsibilities | Authority limits |
|---|---|---|
| Project Owner | <strategic decisions and approvals> | <what remains owner-only> |
| Primary Coordinator | <assigns work, reviews evidence, writes canonical record> | <what the coordinator cannot decide alone> |
| Specialist Agent | <bounded domain work> | <must not self-schedule, broaden scope, or make high-impact decisions> |

## Record model

| Record | Purpose | Routine writer |
|---|---|---|
| Canonical project record | Accepted facts, durable decisions, verified status. | Primary Coordinator |
| Shared coordination ledger | Bounded requests, statuses, results, and dispositions. | Primary Coordinator; specialists only as explicitly delegated |
| Specialist ledger, optional | One specialist’s detailed append-only thread. | Primary Coordinator and named specialist under task rules |

## Mandatory boundaries

1. Coordination records are append-only and do not replace the canonical project record.
2. A specialist task must name objective, inputs, permitted/prohibited actions, stop conditions, and required output.
3. Specialists do not poll ledgers, assume shared paths, self-schedule, delegate, or silently alter project authority.
4. A specialist result is not accepted until the Primary Coordinator reviews and records a disposition.
5. If a shared file or attachment is unavailable, return a structured `BLOCKED` report; do not infer a product failure solely from sandbox limitations.

## Current roles

| Specialist role | Charter reference | Current state | Last thread/reference |
|---|---|---|---|
| <ROLE NAME> | `<path>` | <inactive | assigned | blocked | closed> | <ID or none> |

## Adoption decision

> This charter authorizes only the internal coordination practice described above. It does not authorize a product UI, automatic scheduling, persistent orchestration, real-time messaging, external integrations, or changes to project persistence/release scope.
