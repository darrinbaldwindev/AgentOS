# Task Brief — TASK_003_MCP_VERIFICATION: Verify MCP Server Status

**Assigned role:** affiliate-researcher-01  
**Assigned by:** architect-prime (Primary Coordinator)  
**Issued:** 2026-08-21  
**Ledger thread:** CL-20260821-007  
**Task type:** read-only audit | research | documentation

---

## Objective

Verify MCP server status (official vs community vs none) for three providers where verification was incomplete due to search rate limits in TASK_001.

---

## Target Providers

1. **Groq** — Community repo found: `github.com/groq/groq-mcp` (needs verification)
2. **Together AI** — Community repo found: `github.com/togethercomputer/together-mcp` (needs verification)
3. **Perplexity** — Community repo found: `github.com/ppl-ai/mcp-server-perplexity` (needs verification of official blessing)

---

## Required Output: MCP_STATUS_UPDATE.json

```json
{
  "version": 1,
  "last_updated": "2026-08-21",
  "entries": [
    {
      "provider_id": "groq",
      "mcp_server": {
        "exists": true|false,
        "url": "",
        "status": "official|community|none",
        "maintained_by": "",
        "last_release": "",
        "tools_count": 0,
        "transport": "stdio|sse|streamable_http",
        "install_command": ""
      },
      "verified_date": "2026-08-21",
      "notes": ""
    }
  ]
}
```

---

## Verification Criteria

| Status | Criteria |
|--------|----------|
| **official** | Published by provider's official GitHub org, referenced in provider docs, maintained by provider team |
| **community** | Published by third-party, not referenced in official docs, maintained by community |
| **none** | No MCP server found |

---

## Inputs and Access Conditions

| Input | Location | Required Use | Access Condition |
|-------|----------|--------------|------------------|
| Project charter | `agents/PROJECT_COORDINATION_CHARTER.md` | Context | Must be visible |
| Role charter | `agents/charters/AFFILIATE_RESEARCHER_CHARTER.md` | Permissions | Must be visible |
| Coordination ledger | `agents/COORDINATION_LEDGER.md` | Thread state | Must be visible |
| Target provider list | This brief | Scope definition | Provided directly |
| Public web access | Browser/search | Primary verification | Required |

---

## Permitted Actions

- Browse GitHub repos, provider docs, MCP server registries
- Search queries: `"{provider} mcp server"`, `site:github.com {provider} mcp`, `"{provider} mcp server official"`
- Read local files listed above
- Append `ACKNOWLEDGED` and `RESULT` entries to `agents/COORDINATION_LEDGER.md` if ledger visible

---

## Prohibited Actions

- Make authenticated API calls
- Clone or run MCP servers
- Expand scope beyond the 3 listed providers
- Begin follow-up work without a new brief

---

## Required Procedure

1. Read charter, role charter, ledger, and this brief
2. Confirm access to all mandatory inputs
3. For each provider, verify MCP server status using official sources
4. Construct `MCP_STATUS_UPDATE.json`
5. Write brief `MCP_VERIFICATION_BRIEF_2026-08-21.md`
6. Append `ACKNOWLEDGED` and `RESULT` to `COORDINATION_LEDGER.md` if visible
7. Return full Markdown report via `<<<REPORT_BLOCK>>>` protocol

---

## Stop Conditions

| Condition | Response |
|-----------|----------|
| Required input file unavailable | Return `BLOCKED` naming exact missing file |
| Search rate limit reached | Return `BLOCKED` with searches completed |
| No MCP server found | Set `exists: false`, `status: "none"` |
| Conflicting information | Note conflict, set `status: "community"` with note |

---

## Required Return Format

1. **Task and inputs**
2. **Access and environment observations**
3. **Actions/commands and exact results** (searches, URLs, findings per provider)
4. **Direct findings** (verified facts with source URL + date)
5. **Historical claims not independently verified**
6. **Blockers, limitations, and environment constraints**
7. **What was intentionally not changed**
8. **Recommended next action for architect-prime**

---

## Acceptance Criteria

Task complete only when architect-prime can determine:
- Official vs community vs none status for each provider
- Evidence supporting each classification
- Whether `MCP_STATUS_UPDATE.json` structure is ready for Coordinator to write
- Whether any registry updates are needed

---

> **Reminder:** Your result is an observation report, not an accepted project decision.