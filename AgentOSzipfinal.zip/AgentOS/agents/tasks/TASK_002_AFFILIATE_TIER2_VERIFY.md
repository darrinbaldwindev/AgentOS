# Task Brief — TASK_002_AFFILIATE_TIER2_VERIFY: Verify Tier-2 Affiliate Programs

**Assigned role:** affiliate-researcher-01  
**Assigned by:** architect-prime (Primary Coordinator)  
**Issued:** 2026-08-21  
**Ledger thread:** CL-20260821-005  
**Task type:** read-only audit | research | documentation

---

## Objective

Verify affiliate/referral programs for 10 Tier-2 target providers and produce a structured `TIER2_SHORTLIST.json` with compatibility scores. Only include providers scoring ≥70 for routing inclusion.

---

## Target Providers (Tier-2)

1. **Anthropic** (inference API)
2. **Replicate** (inference gateway)
3. **Mistral AI** (inference API)
4. **Vercel v0** (AI UI generator)
5. **ElevenLabs** (voice API)
6. **n8n** (workflow automation)
7. **Framer** (AI website builder)
8. **Fireflies.ai** (meeting assistant)
9. **Synthflow AI** (voice agents)
10. **Otter.ai** (transcription/meeting assistant)

---

## Required Output: TIER2_SHORTLIST.json

```json
{
  "version": 1,
  "last_updated": "2026-08-21",
  "entries": [
    {
      "provider_id": "anthropic",
      "name": "Anthropic",
      "category": "inference_api",
      "quality_tier": "verified|community|experimental",
      "api_docs_url": "",
      "mcp_server": { "exists": false, "url": null, "status": "none" },
      "affiliate": {
        "has_program": true|false,
        "type": "cash|credit_share|hybrid|none",
        "signup_url": "",
        "commission_details": "",
        "cookie_days": 0,
        "payout_threshold": "",
        "restrictions": [],
        "verified_date": "2026-08-21",
        "notes": ""
      },
      "compatibility_score": 0,
      "score_breakdown": {
        "dev_relevance": 0,
        "recurring_quality": 0,
        "setup_ease": 0,
        "terms_clarity": 0,
        "routing_value": 0
      },
      "routing_tags": []
    }
  ]
}
```

---

## Scoring Rubric (Max 100)

| Dimension | Weight | Criteria |
|-----------|--------|----------|
| **dev_relevance** | 25% | How relevant to AgentOS users (devs, agent builders, AI engineers) |
| **recurring_quality** | 25% | Recurring vs one-time, commission rate, lifetime vs capped |
| **setup_ease** | 20% | Signup flow, approval time, technical integration complexity |
| **terms_clarity** | 15% | Clear terms, no hidden restrictions, transparent payout |
| **routing_value** | 20% | How often AgentOS router would select this provider |

**Threshold:** ≥70 for routing inclusion.

---

## Inputs and Access Conditions

| Input | Location | Required Use | Access Condition |
|-------|----------|--------------|------------------|
| Project charter | `agents/PROJECT_COORDINATION_CHARTER.md` | Context | Must be visible |
| Role charter | `agents/charters/AFFILIATE_RESEARCHER_CHARTER.md` | Permissions | Must be visible |
| Coordination ledger | `agents/COORDINATION_LEDGER.md` | Thread state | Must be visible |
| Target provider list | This brief | Scope definition | Provided directly |
| Public web access | Browser/search | Primary verification | Required |

---

## Permitted Actions

- Browse public websites: provider docs, blogs, GitHub, affiliate/partner portals, pricing pages
- Search queries: `"{provider} affiliate program"`, `"{provider} referral program"`, `"{provider} partner program"`, `"{provider} MCP server"`
- Read local files listed above
- Append `ACKNOWLEDGED` and `RESULT` (or `BLOCKED`) entries to `agents/COORDINATION_LEDGER.md` if ledger visible

---

## Prohibited Actions

- Make authenticated API calls or use personal credentials
- Use personal referral codes; all codes must be placeholders (`AGENTOS_REF`)
- Infer terms from forums, Reddit, Discord, or unverified blog posts
- Write any file other than ledger entry (if permitted) and final report
- Expand scope beyond the 10 listed providers
- Begin follow-up work without a new brief

---

## Required Procedure

1. Read charter, role charter, ledger, and this brief
2. Confirm access to all mandatory inputs
3. For each provider, search and verify affiliate program details
4. Score each provider using the rubric
5. Construct `TIER2_SHORTLIST.json` with only providers scoring ≥70
6. Write brief `TIER2_BRIEF_2026-08-21.md` summarizing findings
7. Append `ACKNOWLEDGED` and `RESULT` to `COORDINATION_LEDGER.md` if visible
8. Return full Markdown report via `<<<REPORT_BLOCK>>>` protocol

---

## Stop Conditions

| Condition | Response |
|-----------|----------|
| Required input file unavailable | Return `BLOCKED` naming exact missing file |
| Search rate limit reached | Return `BLOCKED` with searches completed |
| Provider has no public affiliate page | Score 0 for affiliate dimensions, note in findings |
| Conflicting information | Note conflict, set `quality_tier: experimental` |
| 20 searches completed | Stop and return current results |

---

## Required Return Format

1. **Task and inputs**
2. **Access and environment observations**
3. **Actions/commands and exact results** (searches, URLs, findings per provider)
4. **Direct findings** (verified facts with source URL + date)
5. **Historical claims not independently verified**
6. **Blockers, limitations, and environment constraints**
7. **What was intentionally not changed**
8. **Recommended next action for architect-prime**

---

## Acceptance Criteria

Task complete only when architect-prime can determine:
- Which providers scored ≥70 and are routing-ready
- Evidence supporting each score dimension
- Which providers need follow-up verification
- Whether `TIER2_SHORTLIST.json` structure is ready for Coordinator to write
- Whether any Owner decision is needed

---

> **Reminder:** Your result is an observation report, not an accepted project decision. The Coordinator will review and record a disposition before any shortlist is committed.