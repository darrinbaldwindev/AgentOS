# Task Brief — TASK_004_TOGETHER_AI_CONFIRMATION: Confirm Together AI Affiliate Program

**Assigned role:** research-analyst-01
**Assigned by:** architect-prime
**Issued:** 2026-08-21
**Ledger thread:** CL-20260821-008
**Task type:** read-only audit | research

---

## Objective

Confirm or definitively disprove Together AI's public affiliate program via official channels.

---

## Background

TASK_001 found third-party claims (Rewardful: 20% recurring) but NO official program on together.ai.

---

## Required Output: CONFIRMATION_REPORT.md

```markdown
# Together AI Affiliate Program Confirmation Report
**Date:** 2026-08-21
**Researcher:** research-analyst-01

## Executive Summary
[CONFIRMED | DENIED | INCONCLUSIVE]

## Verification Methods Used
1. Official website scan
2. Documentation scan
3. Official contact channel inquiry
4. Third-party cross-reference

## Findings

### Official Website (together.ai)
- Affiliate page: [FOUND | NOT FOUND]
- URL if found:
- Program details:

### Official Documentation (docs.together.ai)
- Affiliate docs: [FOUND | NOT FOUND]

### Official Contact Channel
- Contact method: [partner@together.ai | support form | Twitter]
- Response: [YES | NO | PENDING]
- Content:

### Third-Party Aggregators
- Rewardful: [FOUND | NOT FOUND]
- Discrepancies:

## Conclusion
[CONFIRMED | DENIED | INCONCLUSIVE]

## Recommendation
[INCLUDE | EXCLUDE | DEFER]
```

---

## Permitted Actions

- Browse together.ai, docs.together.ai, blog.together.ai
- Contact: partner@together.ai, support form, @togethercompute
- Read local charter/ledger files

---

## Stop Conditions

- No response after 48 hours → mark INCONCLUSIVE
- Official confirmation → complete immediately
- Rate limit → BLOCKED

---

> **Reminder:** Blocking item for Tier-1 router config.