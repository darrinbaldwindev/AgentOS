# Session 024: Privacy Shield (Auto-Redaction + Local-Only Mode)
**Project:** AgentOS | **Component:** `privacy/shield` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Redaction Engine

```rust
// src/privacy/redactor.rs
use regex::Regex;
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RedactionRule {
    pub name: String,
    pub pattern: Regex,
    pub replacement: String,
    pub enabled: bool,
}

pub struct PrivacyShield {
    rules: Vec<RedactionRule>,
    custom_rules: Vec<RedactionRule>,
}

impl PrivacyShield {
    pub fn default_rules() -> Vec<RedactionRule> {
        vec![
            RedactionRule { name: "OpenAI API Key", pattern: Regex::new(r"sk-[a-zA-Z0-9]{48}").unwrap(), replacement: "[REDACTED_OPENAI_KEY]", enabled: true },
            RedactionRule { name: "Anthropic API Key", pattern: Regex::new(r"sk-ant-[a-zA-Z0-9_-]{95}").unwrap(), replacement: "[REDACTED_ANTHROPIC_KEY]", enabled: true },
            RedactionRule { name: "GitHub Token", pattern: Regex::new(r"gh[ps]_[a-zA-Z0-9]{36}").unwrap(), replacement: "[REDACTED_GITHUB_TOKEN]", enabled: true },
            RedactionRule { name: "Email", pattern: Regex::new(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b").unwrap(), replacement: "[EMAIL]", enabled: true },
            RedactionRule { name: "IP Address", pattern: Regex::new(r"\b(?:\d{1,3}\.){3}\d{1,3}\b").unwrap(), replacement: "[IP]", enabled: true },
            RedactionRule { name: "AWS Key", pattern: Regex::new(r"AKIA[0-9A-Z]{16}").unwrap(), replacement: "[REDACTED_AWS_KEY]", enabled: true },
            RedactionRule { name: "JWT Token", pattern: Regex::new(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+").unwrap(), replacement: "[REDACTED_JWT]", enabled: true },
        ]
    }
    
    pub fn redact(&self, text: &str) -> String {
        let mut result = text.to_string();
        for rule in &self.rules { if rule.enabled { result = rule.pattern.replace_all(&result, &rule.replacement).to_string(); } }
        for rule in &self.custom_rules { if rule.enabled { result = rule.pattern.replace_all(&result, &rule.replacement).to_string(); } }
        result
    }
    
    pub fn redact_messages(&self, messages: &mut [ApiMessage]) {
        for msg in messages { if let Some(text) = msg.content.as_text_mut() { *text = self.redact(text); } }
    }
}
```

---

## 2. Local-Only Mode (Project Setting)

```rust
pub struct LocalOnlyConfig {
    pub enabled: bool,
    pub block_cloud_models: bool,
    pub block_external_tools: bool,
    pub block_telemetry: bool,
    pub redact_before_logging: bool,
}
```

---

## 3. UI Toggle

```svelte
<!-- PrivacyShield.svelte -->
<script>
  export let projectId: string;
  let shield = $state<PrivacyShieldConfig>();
  async function toggleLocalOnly() {
    await invoke('set_project_privacy', { projectId, config: { ...shield, local_only: !shield.local_only } });
    shield.local_only = !shield.local_only;
  }
</script>

<div class="privacy-shield">
  <label class="toggle"><input type="checkbox" bind:checked={shield.local_only} onchange={toggleLocalOnly} /><span>Local-Only Mode</span></label>
  {#if shield.local_only}
    <div class="local-only-banner">🔒 Local-only: Cloud models blocked • External tools blocked • Full redaction</div>
  {/if}
  <details><summary>Redaction Rules</summary>{#each shield.rules as rule}<label><input type="checkbox" bind:checked={rule.enabled} />{rule.name} → {rule.replacement}</label>{/each}</details>
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/privacy/`.