# Session 026: Referral Revenue Attribution Dashboard
**Project:** AgentOS | **Component:** `attribution/referral` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Attribution Model

```rust
pub struct ReferralAttribution {
    pub total_earned_usd: f64,
    pub total_credits: HashMap<String, f64>,
    pub by_provider: Vec<ProviderAttribution>,
    pub by_referral_user: Vec<UserAttribution>,
    pub projected_annual: f64,
}

pub struct ProviderAttribution {
    pub provider: String,
    pub referrals: u32,
    pub credits_earned: f64,
    pub usd_value: f64,
    pub program_type: ReferralType,
    pub avg_value_per_referral: f64,
    pub trend: Trend,
}

pub struct UserAttribution {
    pub user_hash: String,
    pub referrals: u32,
    pub total_value_usd: f64,
    pub first_referral_at: i64,
    pub last_referral_at: i64,
    pub status: ReferralStatus,
}
```

---

## 2. Perplexity-Specific Calculation

```rust
impl ReferralAttribution {
    fn calculate_perplexity(&self, events: &[UsageEvent]) -> ProviderAttribution {
        let referrals = events.iter()
            .filter(|e| e.provider_id == "perplexity" && e.referral_applied)
            .map(|e| e.referral_code_used)
            .unique()
            .count();
        
        let active_months = self.get_active_referral_months("perplexity");
        let credits = referrals as f64 * 10.0 * active_months.min(12) as f64;
        
        ProviderAttribution {
            provider: "Perplexity".into(),
            referrals: referrals as u32,
            credits_earned: credits,
            usd_value: credits,
            program_type: ReferralType::CreditShare,
            avg_value_per_referral: 10.0 * active_months.min(12) as f64,
            trend: self.calculate_trend("perplexity"),
        }
    }
}
```

---

## 3. UI

```svelte
<!-- ReferralAttribution.svelte -->
<script>
  let attribution = $state<ReferralAttribution>();
</script>

<div class="attribution-dashboard">
  <div class="header"><h2>💸 Referral Revenue Attribution</h2><span class="total">${attribution.total_earned_usd.toFixed(2)} earned</span></div>
  <div class="provider-cards">
    {#each attribution.by_provider as p}
      <Card><h4>{p.provider}</h4><div class="metric"><span class="value">${p.usd_value.toFixed(2)}</span><span class="label">{p.referrals} referrals</span></div><div class="detail">{p.referrals} × ${p.avg_value_per_referral.toFixed(2)}/ref</div><TrendIndicator trend={p.trend} /></Card>
    {/each}
  </div>
  <details><summary>Top Referrers (Anonymized)</summary><table>{#each attribution.by_referral_user as u}<tr><td>User #{u.user_hash}</td><td>{u.referrals}</td><td>${u.total_value_usd.toFixed(2)}</td><td>{formatDate(u.first_referral_at)}</td><td>{u.status}</td></tr>{/each}</table></details>
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/attribution/`.