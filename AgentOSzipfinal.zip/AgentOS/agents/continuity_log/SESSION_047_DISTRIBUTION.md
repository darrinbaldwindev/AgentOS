# Session 047: Custom AgentOS Distributions (White-Label / OEM)
**Project:** AgentOS | **Component:** `distribution/` (Rust + Build System)
**Date:** 2026-08-21
**Status:** Spec Complete — Ready for Implementation

---

## 1. Distribution Builder

Branded builds with custom name, icons, colors, defaults, feature flags, enabled integrations, and policies.

## 2. Use Cases

| Distribution | Configuration |
|--------------|---------------|
| AgentOS Enterprise | SSO, RBAC, DLP, Audit, Compliance, Private Registry |
| AgentOS Edu | Free, no cloud, curated models, classroom sync |
| AgentOS Embedded | Headless, SDK-only, minimal binary |
| AgentOS Cloud | Multi-tenant, shared infrastructure, billing |
| AgentOS Gov | Air-gapped, FIPS, CMMC, IL4/IL5 |

---

> **Accepted as Canonical.** Implementation proceeds in `src/distribution/`.