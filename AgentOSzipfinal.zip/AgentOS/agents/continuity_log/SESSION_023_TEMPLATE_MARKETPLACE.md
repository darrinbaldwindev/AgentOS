# Session 023: Agent Template Marketplace (`.agentpkg` Format)
**Project:** AgentOS | **Component:** `marketplace/templates` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Package Structure

```
code-reviewer.agentpkg/
├── manifest.json          # Metadata, version, dependencies
├── prompt.prompt          # Main prompt (Session 017 format)
├── routing_rules.json     # Router config for this agent
├── mcp_requirements.json  # Required MCP servers
├── sandbox_profile.json   # Sandbox permissions needed
├── test_cases/            # Prompt Lab test fixtures
│   ├── input_1.json
│   └── expected_1.json
├── README.md
└── icon.png
```

---

## 2. manifest.json

```json
{
  "name": "code-reviewer",
  "version": "2.1.0",
  "description": "Senior engineer code review with GitHub integration",
  "author": "agentos-team",
  "license": "MIT",
  "category": "coding",
  "tags": ["review", "github", "security", "performance"],
  "requires": {
    "mcp_servers": ["github-official"],
    "sandbox": { "languages": ["python", "bash"], "network": false },
    "model_tier": "high_reasoning"
  },
  "routing_rules": {
    "task_type": "code_review",
    "prefer_referral": false,
    "min_quality": 9.0
  },
  "pricing": "free",
  "repository": "https://github.com/agentos-templates/code-reviewer"
}
```

---

## 3. Registry & CLI

```bash
# Browse
agentos template search "code review"

# Install
agentos template install code-reviewer@v2.1.0

# Publish
agentos template publish ./my-agent --registry official

# Run
agentos agent run code-reviewer --pr 42
```

### Marketplace UI

```svelte
<!-- TemplateMarketplace.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let templates = $state<Template[]>([]);
  let categories = $state(['coding', 'research', 'writing', 'analysis', 'automation']);
</script>

<div class="marketplace">
  <select bind:value={filterCategory}>
    <option value="">All Categories</option>
    {#each categories as c}
      <option value={c}>{c}</option>
    {/each}
  </select>
  
  <div class="template-grid">
    {#each templates as t}
      <TemplateCard template={t} onInstall={() => installTemplate(t.name)} />
    {/each}
  </div>
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/marketplace/`.