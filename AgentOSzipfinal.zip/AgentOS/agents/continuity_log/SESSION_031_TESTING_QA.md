# Session 031: Testing & QA Infrastructure
**Project:** AgentOS | **Component:** `testing/` (Rust + TypeScript)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Test Pyramid

| Layer | Tool | Coverage Target |
|-------|------|-----------------|
| Unit | `cargo test`, `vitest` | 80% |
| Integration | `tauri-driver` + `playwright` | 60% |
| Contract | `pact` (provider contracts) | 100% of IPC |
| E2E | `playwright` (user flows) | Critical paths |
| Benchmark | `criterion`, custom agent loops | Regression detection |
| Chaos | `chaos-mesh` (simulated failures) | Resilience |

---

## 2. Agent Loop Test Harness

```rust
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentTestCase {
    pub name: String,
    pub agent_config: AgentConfig,
    pub initial_context: AgentContext,
    pub steps: Vec<TestStep>,
    pub assertions: Vec<Assertion>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum TestStep {
    UserMessage { content: String },
    ToolCallExpected { tool: String, args: Value },
    ToolResult { output: Value },
    Timeout { secs: u64 },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Assertion {
    MessageContains { text: String },
    ToolCalled { tool: String, with_args: Value },
    ArtifactCreated { path: String, content_matches: String },
    CostUnder { max_usd: f64 },
    StepsUnder { max: u32 },
    VerificationPassed,
    NoHallucination { forbidden_phrases: Vec<String> },
}

pub struct AgentTestHarness {
    runtime: AgentRuntime,
    mock_providers: HashMap<String, MockProvider>,
    mock_mcp: MockMCPRegistry,
    mock_sandbox: MockSandbox,
}

impl AgentTestHarness {
    pub async fn run_test(&mut self, case: AgentTestCase) -> TestResult {
        // 1. Setup mocks
        // 2. Run agent with test case
        // 3. Capture all events
        // 4. Verify assertions
        // 5. Return pass/fail with evidence
    }
}
```

---

## 3. Golden Master Tests (Prompt Regression)

```rust
pub struct GoldenMasterTest {
    pub prompt_name: String,
    pub model_id: ULID,
    pub inputs: HashMap<String, Value>,
    pub expected_output: String,
    pub tolerance: f32, // 0.0 - 1.0 semantic similarity
}

impl GoldenMasterTest {
    pub async fn run(&self, runtime: &AgentRuntime) -> TestResult {
        let output = runtime.run_prompt(&self.prompt_name, self.inputs.clone()).await?;
        let similarity = semantic_similarity(&output, &self.expected_output);
        TestResult {
            passed: similarity >= self.tolerance,
            similarity,
            output,
            expected: self.expected_output.clone(),
        }
    }
}
```

---

## 4. CI Pipeline (GitHub Actions)

```yaml
# .github/workflows/ci.yml
name: CI
on: [push, pull_request]

jobs:
  rust:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-toolchain@stable
      - run: cargo test --workspace --all-targets
      - run: cargo clippy --workspace -- -D warnings
      - run: cargo fmt --check
  
  typescript:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v2
      - run: pnpm install && pnpm test && pnpm lint && pnpm typecheck
  
  integration:
    runs-on: ubuntu-latest
    needs: [rust, typescript]
    steps:
      - run: pnpm tauri build && pnpm test:e2e
  
  benchmarks:
    runs-on: ubuntu-latest
    needs: rust
    steps:
      - run: cargo bench --bench agent_loop -- --save-baseline main
      - run: cargo bench --bench agent_loop -- --baseline main
```

---

> **Accepted as Canonical.** Implementation proceeds in `tests/`, `.github/workflows/`.