# Session 037: Contributor Guide & Governance
**Project:** AgentOS | **Component:** `governance/` (Markdown + Automation)
**Date:** 2026-08-21
**Status:** Spec Complete — Ready for Implementation

---

## 1. CONTRIBUTING.md

```markdown
# Contributing to AgentOS

## Quick Start
```bash
git clone https://github.com/agentos/agentos
cd agentos
./scripts/bootstrap.sh
pnpm install
pnpm tauri dev
```

## Architecture Rules
1. Local-First — No feature requires cloud
2. Privacy by Default — Opt-in for any data leaving machine
3. MCP-Native — All tools via MCP, no custom plugins
4. Type-Safe — Rust <-> TS via specta, no `any`
5. Streaming First — No blocking IPC calls

## Code Style
- Rust: `cargo fmt`, `cargo clippy -D warnings`
- TypeScript: `pnpm lint`, `pnpm typecheck`
- Commits: Conventional Commits (`feat:`, `fix:`, `docs:`)

## Adding a Provider
1. Implement `Provider` trait in `src/providers/`
2. Add to `ProviderRegistry::new()`
3. Add seed data to `migrations/`
4. Add to `registry_builtin.json` if verified
5. Tests: `tests/providers/<name>.rs`

## Release Process
1. `cargo release --workspace minor --execute`
2. GitHub Actions builds all platforms
3. Sign artifacts (macOS/Windows)
4. Publish to GitHub Releases + updater endpoint
5. Announce in Discord + changelog
```

---

> **Accepted as Canonical.** Implementation proceeds in repo root and CI/CD.