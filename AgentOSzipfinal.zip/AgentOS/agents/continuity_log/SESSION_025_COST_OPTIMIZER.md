# Session 025: Cost Optimizer (One-Click Savings)
**Project:** AgentOS | **Component:** `optimizer/cost` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Analysis Engine

```rust
// src/optimizer/cost_optimizer.rs
pub struct SavingsOpportunity {
    pub id: String,
    pub title: String,
    pub description: String,
    pub monthly_savings_usd: f64,
    pub quality_impact_pct: f32,
    pub action: OptimizerAction,
    pub confidence: f32,
}

pub enum OptimizerAction {
    SwitchModel { from: ULID, to: ULID, for_task: TaskType },
    EnableLocalModel { model: ULID, for_task: TaskType },
    AdjustRoutingRule { rule_id: ULID, new_priority: i32 },
    EnableReferralRouting { provider: ULID },
    ReduceContextWindow { project_id: ULID, new_limit: u32 },
    EnablePromptCaching { provider: ULID },
}

impl CostOptimizer {
    pub async fn analyze(&self, usage: &[UsageEvent], registry: &Registry, router: &Router) -> Vec<SavingsOpportunity> {
        let mut opportunities = Vec::new();
        
        // 1. Expensive coding model → Groq/Local
        if let Some(coding_cost) = self.cost_by_task(usage, TaskType::Coding) {
            if coding_cost.avg_cost_per_1k > 0.01 {
                opportunities.push(SavingsOpportunity {
                    title: "Switch Coding to Groq Llama 3.1 70B".into(),
                    description: "Save ~$0.008/1k tokens (94% quality)".into(),
                    monthly_savings_usd: coding_cost.monthly * 0.8,
                    quality_impact_pct: 6.0,
                    action: OptimizerAction::SwitchModel { from: coding_cost.current_model, to: "groq_llama31_70b".into(), for_task: TaskType::Coding },
                    confidence: 0.9,
                });
            }
        }
        
        // 2. Unused referral programs
        for provider in registry.providers_with_referral() {
            if !router.user_prefs.referral_consent.get(&provider.id).copied().unwrap_or(false) {
                opportunities.push(SavingsOpportunity {
                    title: format!("Enable {} Referral Routing", provider.name),
                    description: "Earn credits on every request".into(),
                    monthly_savings_usd: self.estimate_referral_value(&provider, usage),
                    quality_impact_pct: 0.0,
                    action: OptimizerAction::EnableReferralRouting { provider: provider.id },
                    confidence: 1.0,
                });
            }
        }
        
        // 3. Prompt caching (Anthropic)
        if usage.iter().any(|u| u.provider_id == "anthropic" && u.cache_write_tokens == 0) {
            opportunities.push(SavingsOpportunity {
                title: "Enable Anthropic Prompt Caching".into(),
                description: "90% cost reduction on repeated context".into(),
                monthly_savings_usd: self.estimate_caching_savings(usage),
                quality_impact_pct: 0.0,
                action: OptimizerAction::EnablePromptCaching { provider: "anthropic".into() },
                confidence: 0.95,
            });
        }
        
        opportunities.sort_by(|a,b| b.monthly_savings_usd.partial_cmp(&a.monthly_savings_usd).unwrap());
        opportunities
    }
}
```

---

## 2. One-Click Apply

```svelte
<!-- CostOptimizer.svelte -->
<script>
  let opportunities = $state<SavingsOpportunity[]>([]);
  async function apply(op: SavingsOpportunity) {
    await invoke('apply_optimization', { action: op.action });
    opportunities = opportunities.filter(o => o.id !== op.id);
    notify(`Applied: ${op.title} — est. $${op.monthly_savings_usd.toFixed(2)}/mo saved`);
  }
</script>

<div class="optimizer">
  <h3>💰 Savings Opportunities</h3>
  <div class="total-savings">Potential: ${opportunities.reduce((sum, o) => sum + o.monthly_savings_usd, 0).toFixed(2)}/mo</div>
  {#each opportunities as op}
    <div class="opportunity-card">
      <h4>{op.title}</h4>
      <p>{op.description}</p>
      <div class="meta"><span class="savings">${op.monthly_savings_usd.toFixed(2)}/mo</span><span class="quality">Quality impact: -{op.quality_impact_pct}%</span><span class="confidence">Confidence: {op.confidence * 100}%</span></div>
      <button onclick={() => apply(op)} class="btn-primary">Apply Automatically</button>
    </div>
  {/each}
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/optimizer/`.