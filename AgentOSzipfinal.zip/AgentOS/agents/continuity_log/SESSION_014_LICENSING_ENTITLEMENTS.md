# Session 014: Licensing & Entitlements System
**Project:** AgentOS | **Component:** `billing/entitlements` (Rust Sidecar + Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. License Model

```rust
// src/billing/license.rs
use serde::{Serialize, Deserialize};
use specta::Type;

#[derive(Debug, Clone, Serialize, Deserialize, Type, PartialEq, Eq)]
pub enum LicenseTier {
    Free,
    Pro,
    ProLifetime,
    Team,
    Enterprise,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct License {
    pub tier: LicenseTier,
    pub email: Option<String>,
    pub issued_at: i64,
    pub expires_at: Option<i64>,
    pub trial_ends_at: Option<i64>,
    pub referral_months_granted: u32,
    pub features: Entitlements,
    pub signature: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct Entitlements {
    pub max_projects: u32,
    pub max_context_tokens: u32,
    pub max_rag_mb: u32,
    pub max_mcp_servers: u32,
    pub agent_loops_enabled: bool,
    pub agent_loop_steps_per_month: u32,
    pub cloud_sync_enabled: bool,
    pub custom_routing_rules: bool,
    pub advanced_analytics: bool,
    pub team_workspaces: bool,
    pub sso_enabled: bool,
}

impl Entitlements {
    pub fn free() -> Self {
        Self {
            max_projects: 3,
            max_context_tokens: 8_000,
            max_rag_mb: 100,
            max_mcp_servers: 3,
            agent_loops_enabled: false,
            agent_loop_steps_per_month: 0,
            cloud_sync_enabled: false,
            custom_routing_rules: false,
            advanced_analytics: false,
            team_workspaces: false,
            sso_enabled: false,
        }
    }
    
    pub fn pro() -> Self {
        Self {
            max_projects: 0,
            max_context_tokens: 0,
            max_rag_mb: 5_000,
            max_mcp_servers: 0,
            agent_loops_enabled: true,
            agent_loop_steps_per_month: 50,
            cloud_sync_enabled: true,
            custom_routing_rules: true,
            advanced_analytics: true,
            team_workspaces: false,
            sso_enabled: false,
        }
    }
    
    pub fn team() -> Self {
        let mut e = Self::pro();
        e.team_workspaces = true;
        e.sso_enabled = true;
        e
    }
}
```

---

## 2. License Validation

```rust
// src/billing/validator.rs
use ed25519_dalek::{VerifyingKey, Signature, Verifier};

pub struct LicenseValidator {
    public_key: VerifyingKey,
    license: Option<License>,
    trial_start: Option<i64>,
}

impl LicenseValidator {
    pub fn new() -> Self {
        let pk_bytes = include_bytes!("../keys/license_pubkey.bin");
        let public_key = VerifyingKey::from_bytes(pk_bytes).expect("Invalid pubkey");
        Self { public_key, license: None, trial_start: None }
    }
    
    pub fn load_license(&mut self, license_json: &str) -> Result<(), LicenseError> {
        let license: License = serde_json::from_str(license_json)?;
        
        // 1. Verify signature
        let payload = &license_json[..license_json.rfind("signature").unwrap()];
        let sig_bytes = base64::decode(&license.signature)?;
        let signature = Signature::from_bytes(&sig_bytes)?;
        self.public_key.verify(payload.as_bytes(), &signature)?;
        
        // 2. Check expiry
        if let Some(exp) = license.expires_at {
            if exp < now_ms() { return Err(LicenseError::Expired); }
        }
        
        self.license = Some(license);
        Ok(())
    }
    
    pub fn check(&self, feature: Feature) -> Result<(), LimitError> {
        let entitlements = self.current_entitlements();
        
        match feature {
            Feature::CreateProject => {
                let current = self.db.count_projects()?;
                if entitlements.max_projects > 0 && current >= entitlements.max_projects {
                    return Err(LimitError::ProjectLimit { current, max: entitlements.max_projects });
                }
            }
            Feature::ContextTokens(tokens) => {
                if entitlements.max_context_tokens > 0 && tokens > entitlements.max_context_tokens {
                    return Err(LimitError::ContextLimit { requested: tokens, max: entitlements.max_context_tokens });
                }
            }
            Feature::AgentLoop => {
                if !entitlements.agent_loops_enabled {
                    return Err(LimitError::ProRequired { feature: "Agent Loops" });
                }
            }
            // ... other features
        }
        Ok(())
    }
}
```

---

## 3. Trial State Machine

```rust
#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum TrialState {
    NotStarted,
    Active { ends_at: i64 },
    GracePeriod { ends_at: i64 },
    Expired,
    Converted,
}

impl TrialState {
    pub fn advance(&mut self) {
        *self = match self {
            TrialState::NotStarted => TrialState::Active { ends_at: now_ms() + 14.days() },
            TrialState::Active { ends_at } if *ends_at < now_ms() => TrialState::GracePeriod { ends_at: now_ms() + 7.days() },
            TrialState::GracePeriod { ends_at } if *ends_at < now_ms() => TrialState::Expired,
            _ => self.clone(),
        };
    }
    
    pub fn is_pro_features_unlocked(&self) -> bool {
        matches!(self, TrialState::Active { .. } | TrialState::GracePeriod { .. })
    }
}
```

---

## 4. Referral Reward Granting

```rust
impl LicenseValidator {
    pub fn grant_referral_reward(&mut self, new_count: u32) -> Option<RewardGranted> {
        let license = self.license.as_mut()?;
        let reward = match new_count {
            1 if license.referral_months_granted < 3 => Reward::OneMonthPro,
            3 if license.referral_months_granted < 9 => Reward::ThreeMonthsPro,
            10 if license.referral_months_granted < 999 => Reward::LifetimePro,
            25 if license.referral_months_granted < 999 => Reward::Ambassador,
            _ => return None,
        };
        
        license.referral_months_granted = match reward {
            Reward::OneMonthPro => 3,
            Reward::ThreeMonthsPro => 9,
            Reward::LifetimePro | Reward::Ambassador => 999,
        };
        
        if !matches!(reward, Reward::LifetimePro | Reward::Ambassador) {
            let current_expiry = license.expires_at.unwrap_or(now_ms());
            license.expires_at = Some(current_expiry.max(now_ms()) + reward.months());
        } else {
            license.expires_at = None;
            license.tier = LicenseTier::ProLifetime;
        }
        
        self.resign_license(license)?;
        Some(RewardGranted { reward, new_tier: license.tier })
    }
}
```

---

## 5. IPC Commands

```rust
#[command]
pub async fn get_entitlements(state: State<'_, AppState>) -> Result<Entitlements, AppError> {
    Ok(state.license_validator.current_entitlements())
}

#[command]
pub async fn apply_license(state: State<'_, AppState>, license_json: String) -> Result<License, AppError> {
    state.license_validator.load_license(&license_json)?;
    Ok(state.license_validator.license.clone().unwrap())
}

#[command]
pub async fn start_trial(state: State<'_, AppState>) -> Result<TrialState, AppError> {
    state.license_validator.start_trial();
    Ok(state.license_validator.trial_state())
}

#[command]
pub async fn check_feature_limit(state: State<'_, AppState>, feature: Feature) -> Result<(), AppError> {
    state.license_validator.check(feature).map_err(AppError::Limit)
}

#[command]
pub async fn get_referral_status(state: State<'_, AppState>) -> Result<ReferralStatus, AppError> {
    let count = state.db.get_user_referral_count()?;
    let license = state.license_validator.license.as_ref();
    Ok(ReferralStatus {
        referrals: count,
        months_granted: license.map(|l| l.referral_months_granted).unwrap_or(0),
        next_reward: next_reward_for(count),
        referral_link: format!("https://agentos.local/ref/{}", state.user_id()),
    })
}
```

---

## 6. Frontend: Upgrade Prompts

```svelte
<!-- UpgradeGate.svelte -->
<script>
  import { invoke } from '@tauri-apps/api/core';
  
  export let feature: Feature;
  export let children: Snippet;
  
  let entitlements = $state<Entitlements>();
  let trial = $state<TrialState>();
  
  onMount(async () => {
    entitlements = await invoke('get_entitlements');
    trial = await invoke('get_trial_state');
  });
  
  const canAccess = entitlements?.check(feature) ?? trial.is_pro_features_unlocked();
  
  function handleUpgradeClick() {
    invoke('open_external_url', { url: 'https://agentos.local/pricing' });
  }
</script>

{#if canAccess}
  {@render children()}
{:else}
  <div class="upgrade-gate">
    <div class="icon">🔒</div>
    <h4>Pro Feature</h4>
    <p>{feature.description}</p>
    {#if trial.is_pro_features_unlocked()}
      <p class="trial-badge">Trial active — {trial.ui_message()}</p>
    {/if}
    <button onclick={handleUpgradeClick} class="btn-primary">Upgrade to Pro ($15/mo)</button>
    <p class="hint">Or refer 1 friend → 1 month free</p>
  </div>
{/if}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/billing/`.