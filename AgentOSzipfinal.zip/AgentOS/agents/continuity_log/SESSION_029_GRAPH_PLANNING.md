# Session 029: Advanced Planning (Graph-Based, Not Linear)
**Project:** AgentOS | **Component:** `agent/plan_graph` (Rust Sidecar)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Plan Graph (DAG of Steps)

```rust
use petgraph::graph::{DiGraph, NodeIndex};
use petgraph::algo::topo_sort;

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct PlanGraph {
    pub graph: DiGraph<PlanNode, PlanEdge>,
    pub entry_nodes: Vec<NodeIndex>,
    pub exit_nodes: Vec<NodeIndex>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct PlanNode {
    pub id: String,
    pub action: AgentAction,
    pub dependencies: Vec<String>,
    pub parallel_group: Option<String>,
    pub retry_policy: RetryPolicy,
    pub timeout_secs: u64,
    pub checkpoint: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct PlanEdge {
    pub from: String,
    pub to: String,
    pub condition: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum RetryPolicy {
    None, Fixed { max_retries: u32, delay_secs: u64 },
    Exponential { max_retries: u32, base_delay_secs: u64 },
    UntilSuccess { max_duration_secs: u64 },
}
```

---

## 2. Parallel Execution with Dependency Resolution

```rust
impl PlanGraph {
    pub fn get_executable_nodes(&self, completed: &HashSet<String>) -> Vec<NodeIndex> {
        self.graph.node_indices()
            .filter(|n| {
                let node = self.graph[*n];
                node.dependencies.iter().all(|d| completed.contains(d)) && !completed.contains(&node.id)
            }).collect()
    }
    
    pub fn get_parallel_groups(&self, executable: &[NodeIndex]) -> HashMap<String, Vec<NodeIndex>> {
        let mut groups = HashMap::new();
        for n in executable {
            let node = self.graph[*n];
            if let Some(group) = node.parallel_group {
                groups.entry(group).or_default().push(*n);
            } else {
                groups.entry(format!("single_{}", node.id)).or_default().push(*n);
            }
        }
        groups
    }
}
```

---

## 3. Dynamic Replanning

```rust
pub struct AdaptivePlanner {
    base_planner: Planner,
    graph_executor: PlanGraphExecutor,
}

impl AdaptivePlanner {
    pub async fn execute_with_adaptation(&mut self, task: AgentTask) -> Result<AgentRunResult> {
        let mut graph = self.base_planner.create_graph(&task).await?;
        let mut completed = HashSet::new();
        let mut context = task.context.clone();
        
        loop {
            let executable = graph.get_executable_nodes(&completed);
            if executable.is_empty() { break; }
            
            let groups = graph.get_parallel_groups(&executable);
            for (group_name, nodes) in groups {
                let results = self.execute_parallel_group(nodes, &mut context).await?;
                
                for (node_idx, result) in nodes.into_iter().zip(results) {
                    completed.insert(graph[node_idx].id.clone());
                    context.previous_results.push(result);
                    
                    if self.should_replan(&result, &graph, &completed) {
                        graph = self.replan(&graph, &completed, &context, &task.objective).await?;
                    }
                }
            }
        }
        Ok(self.collect_results(&completed, &context))
    }
    
    fn should_replan(&self, result: &StepResult, graph: &PlanGraph, completed: &HashSet<String>) -> bool {
        !result.success || result.verification.as_ref().map(|v| !v.passed).unwrap_or(false)
    }
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/agent/plan_graph.rs`.