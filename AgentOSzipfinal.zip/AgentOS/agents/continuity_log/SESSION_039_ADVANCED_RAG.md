# Session 039: Advanced RAG (Graph + Hybrid + Multi-Modal)
**Project:** AgentOS | **Component:** `rag/advanced` (Rust)
**Date:** 2026-08-21
**Status:** Spec Complete — Ready for Implementation

---

## 1. Graph RAG (Knowledge Graph + Vector)

Knowledge graph with entity extraction, relation extraction, and graph traversal for multi-hop reasoning.

## 2. Hybrid Search (Vector + Keyword + Graph)

Reciprocal Rank Fusion (RRF) combining vector, keyword (Tantivy/FTS5), and graph search with cross-encoder reranking.

## 3. Multi-Modal RAG

PDF processing with text extraction, OCR, table detection, image captioning, and unified embeddings.

---

> **Accepted as Canonical.** Implementation proceeds in `src/rag/`.