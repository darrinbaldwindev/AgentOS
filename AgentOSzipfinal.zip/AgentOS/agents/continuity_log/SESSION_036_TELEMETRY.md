# Session 036: Telemetry & Privacy-First Analytics
**Project:** AgentOS | **Component:** `telemetry/` (Rust)
**Date:** 2026-08-21
**Status:** Spec Complete — Ready for Implementation

---

## 1. Opt-In Telemetry

Rust implementation with anonymization, batching, and opt-in consent.

## 2. Events Tracked (Only If Opted In)

| Event | Properties |
|-------|------------|
| app_started | version, os, arch, startup_time_ms |
| chat_started | model, project_type, thread_length |
| agent_run | agent_type, steps, duration_ms, success, cost_usd |
| mcp_connected | server_id, transport_type |
| sandbox_executed | language, duration_ms, success |
| referral_applied | provider, program_type |
| error_occurred | error_type, component, hashed_message |

---

> **Accepted as Canonical.** Implementation proceeds in `src/telemetry/`.