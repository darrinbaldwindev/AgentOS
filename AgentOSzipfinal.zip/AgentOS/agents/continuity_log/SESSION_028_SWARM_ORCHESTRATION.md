# Session 028: Multi-Agent Orchestration (Swarm Intelligence)
**Project:** AgentOS | **Component:** `agent/swarm` (Rust Sidecar)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Architecture: Hierarchical Agent Teams

```rust
#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct SwarmConfig {
    pub strategy: SwarmStrategy,
    pub max_agents: u32,
    pub communication_protocol: CommunicationProtocol,
    pub consensus_mechanism: ConsensusMechanism,
    pub timeout_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum SwarmStrategy {
    Hierarchical { coordinator: AgentRole, workers: Vec<AgentRole> },
    PeerToPeer { roles: Vec<AgentRole> },
    Pipeline { stages: Vec<SwarmStage> },
    Debate { rounds: u32, judge: AgentRole },
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub struct AgentRole {
    pub name: String,
    pub model_id: ULID,
    pub prompt: String,
    pub tools: Vec<String>,
    pub sandbox_profile: Option<String>,
    pub can_spawn: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum CommunicationProtocol {
    SharedContext, MessagePassing, Blackboard, EventStream,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum ConsensusMechanism {
    Unanimous, Majority, Weighted { weights: HashMap<String, f32> },
    JudgeDecides { judge_role: String },
}
```

### Built-in Swarm Templates

| Template | Strategy | Use Case |
|----------|----------|----------|
| Code Review Team | Hierarchical | Coordinator → [Security, Performance, Style, Tests] → Consensus |
| Feature Squad | Pipeline | Planner → Architect → Implementer → Reviewer → Documenter |
| Research Panel | Debate | 3 researchers debate → Judge synthesizes |
| Debug Squad | Peer-to-Peer | Hypothesis generator → Verifier → Fixer → Validator |
| Content Pipeline | Pipeline | Researcher → Writer → Editor → SEO Optimizer → Publisher |

---

## 2. Swarm Execution Engine

```rust
pub struct SwarmRuntime {
    agents: HashMap<String, AgentRuntime>,
    shared_context: Arc<RwLock<SharedContext>>,
    event_bus: broadcast::Sender<SwarmEvent>,
    config: SwarmConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize, Type)]
pub enum SwarmEvent {
    AgentSpawned { role: String, agent_id: ULID },
    MessageSent { from: String, to: String, content: String },
    ArtifactCreated { by: String, artifact: Artifact },
    ConsensusReached { decision: String, votes: HashMap<String, Vote> },
    AgentCompleted { role: String, output: AgentOutput },
    SwarmCompleted { result: SwarmResult },
}

impl SwarmRuntime {
    pub async fn execute(&mut self, objective: String) -> Result<SwarmResult, SwarmError> {
        match self.config.strategy {
            SwarmStrategy::Hierarchical { coordinator, workers } => self.run_hierarchical(coordinator, workers, objective).await,
            SwarmStrategy::Pipeline { stages } => self.run_pipeline(stages, objective).await,
            SwarmStrategy::Debate { rounds, judge } => self.run_debate(rounds, judge, objective).await,
            SwarmStrategy::PeerToPeer { roles } => self.run_peer_to_peer(roles, objective).await,
        }
    }
}
```

---

## 3. Frontend: Swarm Visualizer

```svelte
<!-- SwarmVisualizer.svelte -->
<script>
  let swarm = $state<SwarmState>();
  let selectedAgent = $state<string | null>(null);
</script>

<div class="swarm-canvas">
  {#each swarm.agents as agent}
    <AgentNode agent={agent} class:active={selectedAgent === agent.id} onclick={() => selectedAgent = agent.id} />
  {/each}
  {#each swarm.messages as msg}
    <MessageArrow from={msg.from} to={msg.to} content={msg.content} animated={msg.recent} />
  {/each}
</div>
<div class="swarm-timeline">
  {#each swarm.events as event} <TimelineEvent event={event} /> {/each}
</div>
{#if selectedAgent} <AgentDetailPanel agent={swarm.agents.find(a => a.id === selectedAgent)} /> {/if}
</div>
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/agent/swarm.rs`.