# Session 030: AgentOS SDK (TypeScript + Python + Rust)
**Project:** AgentOS | **Component:** `sdk/` (Multi-language)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. TypeScript SDK (Primary)

```typescript
// packages/sdk/src/index.ts
export class AgentOS {
  private client: IPCClient;
  
  constructor(options?: { workspacePath?: string; autoConnect?: boolean }) {}
  
  async openWorkspace(path: string): Promise<Workspace>;
  async createWorkspace(name: string, path: string): Promise<Workspace>;
  
  projects: ProjectAPI;
  threads: ThreadAPI;
  messages: MessageAPI;
  
  async chat(options: ChatOptions): Promise<AsyncIterable<StreamChunk>>;
  async sendMessage(threadId: string, content: MessageContent): Promise<Message>;
  
  agents: AgentAPI;
  async runAgent(agentId: string, inputs: Record<string, any>): Promise<AgentRunResult>;
  async createAgent(config: AgentConfig): Promise<Agent>;
  
  mcp: MCPAPI;
  async callTool(serverId: string, toolName: string, args: any): Promise<ToolResult>;
  
  sandbox: SandboxAPI;
  async executeCode(language: Language, code: string): Promise<ExecutionResult>;
  
  rag: RAGAPI;
  async indexPath(path: string): Promise<IndexResult>;
  async query(query: string, options?: QueryOptions): Promise<RAGResult>;
  
  router: RouterAPI;
  async getRoutingDecision(context: RoutingContext): Promise<RoutingDecision>;
  
  on(event: 'message' | 'agent_step' | 'cost_update' | 'sync', handler: Function): void;
}
```

---

## 2. Python SDK

```python
# agentos_sdk/client.py
from agentos_sdk import AgentOS
from agentos_sdk.models import AgentConfig, SandboxLanguage

agentos = AgentOS(workspace_path="/home/user/my-project")

result = await agentos.agents.run(
    agent_id="code-reviewer",
    inputs={"pr_number": 42, "focus": "security"}
)

result = await agentos.sandbox.execute(
    language=SandboxLanguage.PYTHON,
    code="import requests; print(requests.get('https://api.github.com').json())",
    files=[{"name": "requirements.txt", "content": "requests"}]
)

results = await agentos.rag.query(
    "How does auth work in this codebase?",
    top_k=5,
    project_id="my-project"
)
```

---

## 3. Rust SDK

```rust
// agentos-sdk/src/lib.rs
pub struct AgentOS {
    workspace: Workspace,
    runtime: AgentRuntime,
    registry: RegistryManager,
    sandbox: SandboxManager,
}

impl AgentOS {
    pub fn new(workspace_path: &Path) -> Result<Self> { ... }
    pub async fn chat(&self, request: ChatRequest) -> Result<ChatStream> { ... }
    pub async fn run_agent(&self, agent_id: &str, inputs: HashMap<String, Value>) -> Result<AgentRunResult> { ... }
    pub fn sandbox(&self) -> &SandboxManager { ... }
    pub fn registry(&self) -> &RegistryManager { ... }
    pub fn router(&self) -> &Router { ... }
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `packages/sdk/`, `agentos_sdk/`, `crates/agentos-sdk/`.