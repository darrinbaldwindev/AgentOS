# Session 022: Context Health Monitor (Hallucination Risk Detection)
**Project:** AgentOS | **Component:** `context/health` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Health Signals

| Signal | Measurement | Risk Threshold |
|--------|-------------|----------------|
| **Context Age** | Oldest message timestamp | > 50 messages without summary |
| **RAG Hit Rate** | Queries with score > 0.7 | < 30% |
| **Token Pressure** | Used / Available context | > 85% |
| **Model Uncertainty** | Entropy of logprobs (if available) | High entropy on key tokens |
| **Contradiction Detection** | Embedding similarity of recent claims | High similarity + contradictory |
| **Citation Coverage** | % of factual claims with RAG source | < 50% for factual queries |

---

## 2. Risk Score & UI

```rust
pub struct ContextHealth {
    pub risk_score: f32,
    pub risk_level: RiskLevel,
    pub signals: Vec<HealthSignal>,
    pub recommendations: Vec<Action>,
}

pub enum RiskLevel { Low, Medium, High, Critical }

pub enum Action {
    SummarizeThread,
    ReindexRag,
    PruneContext,
    SwitchToHigherContextModel,
    EnableRag,
    AddCitations,
}
```

```svelte
<!-- ContextHealthIndicator.svelte -->
<script>
  export let health: ContextHealth;
</script>

<div class="health-indicator {health.risk_level.toLowerCase()}">
  <div class="risk-bar" style="width: {health.risk_score * 100}%"></div>
  <span class="label">{health.risk_level}</span>
  {#if health.risk_level !== 'Low'}
    <div class="recommendations">
      {#each health.recommendations as action}
        <button onclick={() => executeAction(action)}>{action.label}</button>
      {/each}
    </div>
  {/if}
</div>
```

---

## 3. Auto-Mitigation (Opt-In)

```rust
pub async fn auto_mitigate(&self, health: &ContextHealth) {
    for action in &health.recommendations {
        match action {
            Action::SummarizeThread => self.summarizer.summarize_thread().await,
            Action::ReindexRag => self.rag_reindexer.reindex().await,
            Action::PruneContext => self.context_assembler.prune_aggressive().await,
            _ => {}
        }
    }
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/context/health.rs`.