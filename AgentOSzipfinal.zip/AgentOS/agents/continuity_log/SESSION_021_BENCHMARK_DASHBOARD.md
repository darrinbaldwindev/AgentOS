# Session 021: Model Benchmark Dashboard (Personal Leaderboard)
**Project:** AgentOS | **Component:** `benchmark/dashboard` (Rust Sidecar + Svelte 5 Frontend)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Benchmark Suite

| Benchmark | What It Tests | Local Runner |
|-----------|---------------|--------------|
| **HumanEval** | Python code generation | `bigcode-eval-harness` |
| **MBPP** | Basic programming problems | `bigcode-eval-harness` |
| **MMLU** | Multi-task language understanding | `lm-eval-harness` |
| **GPQA** | Graduate-level reasoning | `lm-eval-harness` |
| **Custom Repo Test** | "Fix tests in MY codebase" | AgentOS agent loop |
| **Latency Profile** | TTFT, throughput, VRAM | Ollama/LLAMA.cpp benchmark |

---

## 2. Personal Leaderboard UI

```svelte
<!-- BenchmarkLeaderboard.svelte -->
<script lang="ts">
  import { invoke } from '@tauri-apps/api/core';
  
  let results = $state<BenchmarkResult[]>([]);
  let running = $state(false);
  let hardware = $state<HardwareProfile>();
  let selectedModels = $state<string[]>([]);
  let availableModels = $state<string[]>([]);
  
  async function load() {
    hardware = await invoke('get_hardware_profile', {});
    availableModels = await invoke('get_available_models', {});
    results = await invoke('get_benchmark_results', {});
  }
  
  async function runBenchmarks() {
    if (selectedModels.length === 0) return;
    running = true;
    for (const model of selectedModels) {
      const result = await invoke('run_benchmark', { model, suite: 'coding' });
      results = [...results, result];
    }
    running = false;
  }
  
  onMount(load);
</script>

<table class="leaderboard">
  <thead>
    <tr>
      <th>Model</th>
      <th>HumanEval %</th>
      <th>MBPP %</th>
      <th>Your Repo Fix %</th>
      <th>TTFT (ms)</th>
      <th>Tokens/s</th>
      <th>VRAM (GB)</th>
      <th>Cost/1k</th>
      <th>Score</th>
    </tr>
  </thead>
  <tbody>
    {#each results.sort((a,b) => b.score - a.score) as r}
      <tr class={r.is_local ? 'local' : 'cloud'}>
        <td>{r.model}</td>
        <td>{r.humaneval}%</td>
        <td>{r.mbpp}%</td>
        <td>{r.custom_repo}%</td>
        <td>{r.ttft_ms}ms</td>
        <td>{r.tokens_per_sec}/s</td>
        <td>{r.vram_gb}GB</td>
        <td>${r.cost_per_1k}</td>
        <td class="score">{r.score.toFixed(1)}</td>
      </tr>
    {/each}
  </tbody>
</table>

<div class="controls">
  <select multiple bind:value={selectedModels}>
    {#each availableModels as m}
      <option value={m}>{m}</option>
    {/each}
  </select>
  <button onclick={runBenchmarks} disabled={running || selectedModels.length === 0}>
    {running ? 'Benchmarking...' : 'Run Benchmarks'}
  </button>
</div>
```

---

## 3. Auto-Router Integration

```rust
// Router uses personal benchmarks > generic scores
pub fn update_model_scores(&mut self, benchmarks: &[BenchmarkResult]) {
    for b in benchmarks {
        if let Some(model) = self.models.get_mut(&b.model_id) {
            model.coding_score = (model.coding_score * 0.7) + (b.humaneval as f32 / 10.0 * 0.3);
            model.speed_score = (model.speed_score * 0.7) + ((1000.0 / b.ttft_ms.max(1) as f32).min(10.0) * 0.3);
            model.quality_score = (model.quality_score * 0.7) + (b.mmlu as f32 / 10.0 * 0.3);
            model.benchmark_updated_at = Some(now_ms());
        }
    }
}
```

---

> **Accepted as Canonical.** Implementation proceeds in `src/benchmark/`.