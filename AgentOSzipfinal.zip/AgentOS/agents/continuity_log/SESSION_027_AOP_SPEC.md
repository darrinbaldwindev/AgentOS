# Session 027: AgentOS Protocol (AOP) — Open Spec
**Project:** AgentOS | **Component:** `protocol/aop` (Rust Library + Spec)
**Date:** 2026-08-21
**Status:** ✅ Spec Complete — Ready for Implementation

---

## 1. Vision

> **"OpenDocument for AI Workspaces"** — `.agentos` workspace format that any tool can read/write.

---

## 2. Spec Outline

```yaml
# AOP v1.0 Spec
format: "agentos-workspace"
version: "1.0"
spec_url: "https://github.com/agentos/aop-spec"

core_entities:
  - workspace
  - project
  - thread
  - message
  - artifact
  - embedding_pointer
  - routing_rule
  - mcp_server_config
  - sandbox_state
  - license

storage_backends:
  - sqlite (primary)
  - git (sync)
  - s3-compatible (optional)
  - memory (ephemeral)

encryption:
  - age (x25519) for git sync
  - sqlcipher for local DB (optional)

interop:
  - import/export JSON
  - MCP server discovery
  - LSP-like language server for prompts
```

---

## 3. Reference Implementation

```rust
// crate: agentos-core (headless library)
pub struct Workspace {
    pub db: SqliteConnection,
    pub git: Option<GitRepo>,
    pub encryption: Option<EncryptionKey>,
}

impl Workspace {
    pub fn open(path: &Path) -> Result<Self> { ... }
    pub fn export_json(&self) -> Result<serde_json::Value> { ... }
    pub fn import_json(&mut self, data: serde_json::Value) -> Result<()> { ... }
    pub fn sync_git(&mut self) -> Result<()> { ... }
}
```

---

## 4. Use Cases

| Consumer | Use Case |
|----------|----------|
| VS Code Extension | Read workspace, show context in sidebar |
| CLI Tool | `agentos-cli query "summarize project"` |
| Obsidian Plugin | Sync notes -> AgentOS RAG |
| Raycast/Alfred | Trigger agent loops from launcher |
| CI/CD | `agentos-ci run-tests --workspace .agentos` |

---

> **Accepted as Canonical.** Implementation proceeds in `crates/agentos-core/`.