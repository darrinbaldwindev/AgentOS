# Session 045: Plugin System (Frontend Extensions)
**Project:** AgentOS | **Component:** `plugins/` (TypeScript + Rust)
**Date:** 2026-08-21
**Status:** Spec Complete - Ready for Implementation

---

## 1. Plugin Architecture

WebAssembly-sandboxed plugins with manifest, permissions, and contribution points for commands, views, themes, agents, and MCP servers.

## 2. Example Plugin: AgentOS-GitLab

GitLab MCP server integration with CI/CD views and merge request commands.

---

> **Accepted as Canonical.** Implementation proceeds in `src/plugins/`, `packages/sdk/src/plugin.ts`.